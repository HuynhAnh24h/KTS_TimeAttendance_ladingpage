# KTS TimeAttendance - Hệ Thống Quản Lý & Tính Công Máy Chấm Công IP

> **Hệ thống Desktop App thương mại chuyên nghiệp** dành cho doanh nghiệp: Kết nối trực tiếp máy chấm công IP (ZKTeco, Ronald Jack), tự động lọc trùng quẹt thẻ Anti-Passback, tính toán giờ làm - tăng ca (OT), xem bảng công ma trận (Timesheet Grid) và xuất/nhập Excel chuẩn kế toán Việt Nam.

---

## 1. Kiến Trúc Tổng Thể & Công Nghệ

```
kts-cham-cong/
├── backend/
│   ├── app/
│   │   ├── api/               # Router RESTful API (Devices, Employees, Shifts, Attendance, Dashboard)
│   │   ├── core/              # Config (SQLite/PostgreSQL switchable), SQLAlchemy Database engine
│   │   ├── models/            # Schema CSDL (Device, Employee, Shift, RawAttendanceLog, DailyAttendance)
│   │   ├── schemas/           # Pydantic Schemas validation
│   │   ├── services/
│   │   │   ├── zk_sync_service.py     # Giao tiếp máy chấm công IP qua pyzk (UDP Port 4370)
│   │   │   ├── calculation_engine.py  # Thuật toán tính công, đi trễ, về sớm & OT
│   │   │   └── excel_service.py       # Engine xuất ma trận Excel freeze pane & nhập nhân viên
│   │   ├── seed_data.py       # Nạp dữ liệu mẫu ban đầu (ca, máy, 12 nhân viên, logs)
│   │   └── main.py            # FastAPI Entry Point (CORS, SPA Static Server)
│   ├── requirements.txt
│   └── run.py                 # Runner backend
├── frontend/                  # Giao diện React SPA phong cách SaaS (Base/1Office)
│   ├── src/
│   │   ├── api/client.js      # Axios client
│   │   ├── components/        # Matrix Grid, Modals, Badges, Metrics
│   │   └── pages/             # Dashboard, Timesheet Matrix, Employees, Shifts, Devices
│   ├── dist/                  # Bản build tĩnh sẵn sàng phục vụ
│   ├── vite.config.js
│   └── package.json
├── desktop/
│   └── run_app.py             # Desktop Runner 1-Click (mở native window qua pywebview/WebView2)
├── tests/
│   └── test_core.py           # Bộ kiểm thử logic tự động
└── mau_danh_sach_nhan_vien.xlsx # File Excel mẫu nhập nhân sự
```

### Công nghệ sử dụng:
- **Backend**: Python 3.10+ / FastAPI, SQLAlchemy ORM.
- **Cơ sở dữ liệu**: SQLite (mặc định cục bộ zero-config cho Desktop) hoặc PostgreSQL (cấu hình qua `.env`).
- **Giao thức máy chấm công**: `pyzk` (giao thức ZKTeco / Ronald Jack qua cổng UDP 4370 trong mạng LAN).
- **Xử lý Excel**: `openpyxl` (tối ưu định dạng kế toán, freeze pane, tô màu badge, công thức `=SUM()`).
- **Frontend**: React 19 + Tailwind CSS + Lucide Icons + TanStack Table Architecture.
- **Desktop Wrapper**: Hỗ trợ chạy trực tiếp qua `pywebview` (sử dụng Microsoft Edge WebView2) hoặc bọc qua Tauri/PyInstaller.

---

## 2. Chi Tiết Các Module Nghiệp Vụ Cốt Lõi

### Module 1: Database Schema (SQLAlchemy)
1. **`Device`**: Quản lý IP máy chấm công, port (4370), trạng thái kết nối (`ONLINE`/`OFFLINE`), số vân tay và log trên máy.
2. **`Shift`**: Cấu hình ca làm việc: giờ vào (`08:00`), giờ ra (`17:30`), nghỉ trưa (`12:00` - `13:30`), phút ân hạn đi trễ (`grace_period_minutes`), mốc bắt đầu tính OT.
3. **`Employee`**: Mã nhân viên (`NV001`), mã chấm công trên máy (`zk_user_id`), họ tên, phòng ban, chức vụ, ca làm việc áp dụng.
4. **`RawAttendanceLog`**: Lưu trữ log quẹt thẻ thô từ máy. Khóa Unique `(zk_user_id, check_time)` đảm bảo không bao giờ bị trùng lặp.
5. **`DailyAttendance`**: Kết quả tính công theo ngày: giờ vào đầu tiên, giờ ra cuối cùng, số phút trễ, số phút về sớm, số giờ công chuẩn, giờ OT ngày thường (1.5x), OT chủ nhật (2.0x), trạng thái công (`FULL_DAY`, `HALF_DAY`, `LATE_EARLY`, `OVERTIME`, `ABSENT`).

### Module 2: Device Sync Service (`zk_sync_service.py`)
- Mở socket UDP tới thiết bị ZKTeco/Ronald Jack qua IP và cổng 4370.
- Khóa thiết bị tạm thời (`disable_device`) để đọc toàn bộ log chấm công một cách an toàn.
- Lọc trùng lặp thông minh: So sánh trong bộ nhớ với các bản ghi đã có trong CSDL để chỉ insert các log mới (`bulk_save_objects`).
- Xử lý timeout kết nối mạng an toàn (không làm đơ ứng dụng), cập nhật trạng thái `ONLINE`/`ERROR` rõ ràng.
- Hỗ trợ chế độ **Mô phỏng dữ liệu quẹt thẻ** để kiểm thử ngay lập tức khi chưa cắm máy chấm công thật.

### Module 3: Calculation Engine (`calculation_engine.py`)
- **Anti-Passback Debounce**: Lọc bỏ các lần quẹt thẻ liên tiếp cách nhau dưới 5 phút (300 giây).
- **Bắt cặp Vào / Ra**: Lấy lần quẹt hợp lệ đầu tiên trong ca làm `first_check_in` và lần quẹt hợp lệ cuối cùng `last_check_out`.
- **Tính trễ / sớm**: So sánh với `start_time` và `end_time` của ca làm việc, áp dụng khoảng ân hạn `grace_period_minutes` (mặc định 15 phút).
- **Trừ thời gian nghỉ trưa**: Tự động nhận diện khoảng giao thoa với giờ nghỉ trưa (`break_start` - `break_end`) và khấu trừ khỏi giờ công tiêu chuẩn.
- **Tính toán Overtime (OT)**: Tự động tính sau mốc tan ca + `ot_start_after_minutes`. Tách riêng OT ngày thường (hệ số 1.5) và OT ngày nghỉ/chủ nhật (hệ số 2.0).

### Module 4: Excel Engine (`excel_service.py`)
- **Xuất bảng công Ma Trận**:
  - Dòng tiêu đề và thông tin doanh nghiệp chuẩn chỉ.
  - Cố định cột thông tin nhân viên (`Freeze Panes E6`) giúp cuộn xem ngày 1 đến 31 cực kỳ mượt mà.
  - Tô màu trực quan cho từng ngày: Đủ công (Xanh), Trễ/Sớm (Vàng), Tăng ca (Tím), Vắng (Đỏ), Chủ nhật (Xám).
  - Tích hợp công thức Excel tự động: `=SUM(G6:AK6)` cho tổng ngày công, tổng giờ OT, và số lần đi trễ.
- **Nhập nhân sự từ Excel**: Đọc danh sách nhân viên, tự động nhận diện cột (Mã NV, Mã ZK, Họ tên, Phòng ban...), kiểm tra trùng lặp và lưu vào DB.

### Module 5: Frontend UI (React + Tailwind CSS)
- **Dashboard**: Thống kê số người đi làm, đi trễ, vắng mặt hôm nay, trạng thái các máy IP và nhật ký quẹt thẻ thời gian thực.
- **Bảng Công Ma Trận (Timesheet Matrix)**:
  - Hiển thị lưới bảng công tháng phong cách SaaS hiện đại (Base/1Office).
  - Cố định header và 4 cột nhân viên bên trái khi cuộn.
  - Nhấp vào bất kỳ ô ngày nào sẽ mở **Modal Chi Tiết**: Xem toàn bộ lịch sử quẹt thẻ trong ngày của nhân viên từ máy chấm công và cho phép người quản lý **Hiệu chỉnh công thủ công** (Manual Override) khi có giải trình quên quẹt thẻ.

---

## 3. Hướng Dẫn Cài Đặt & Chạy Ứng Dụng

### Bước 1: Khởi chạy chế độ Desktop App 1-Click (Khuyên dùng)
Ứng dụng đã được tích hợp sẵn bản build giao diện. Chỉ cần 1 lệnh duy nhất:
```powershell
# Chạy launcher Desktop
.\.venv\Scripts\python desktop\run_app.py
```
Cửa sổ ứng dụng Desktop sẽ tự động mở lên với đầy đủ tính năng!

### Bước 2: Hoặc chạy chế độ Phát Triển (Dev Mode)
Nếu muốn chỉnh sửa code và hot-reload:

**Terminal 1 - Backend FastAPI:**
```powershell
.\.venv\Scripts\python -m uvicorn backend.app.main:app --reload --port 8000
```
Swagger UI API Docs xem tại: `http://127.0.0.1:8000/docs`

**Terminal 2 - Frontend Vite React:**
```powershell
cd frontend
npm run dev
```
Truy cập: `http://localhost:5173`

---

## 4. Hướng Dẫn Đóng Gói Thành File `.EXE` Thương Mại

### Cách 1: Đóng gói bằng PyInstaller (Đơn giản nhất)
1. Cài đặt PyInstaller trong môi trường ảo:
   ```powershell
   .\.venv\Scripts\pip install pyinstaller
   ```
2. Build frontend trước:
   ```powershell
   cd frontend
   npm run build
   cd ..
   ```
3. Tạo file thực thi `.exe`:
   ```powershell
   .\.venv\Scripts\pyinstaller --noconfirm --onedir --windowed --name "KTS_TimeAttendance" `
     --add-data "frontend/dist;frontend/dist" `
     --add-data "backend;backend" `
     desktop/run_app.py
   ```
File thực thi độc lập sẽ nằm trong thư mục `dist\KTS_TimeAttendance\KTS_TimeAttendance.exe`.

### Cách 2: Đóng gói bằng Tauri
- Sử dụng Tauri CLI (`npm install -D @tauri-apps/cli`) bọc thư mục `frontend/dist` và gọi background service Python, giúp dung lượng file cài đặt siêu nhẹ (dưới 15MB).

---

## 5. Chạy Kiểm Thử Tự Động (Automated Testing)
Để kiểm tra tính toàn vẹn của CSDL, Calculation Engine và Excel Export:
```powershell
.\.venv\Scripts\python -m tests.test_core
```
Kết quả mong đợi: `Tất cả bài kiểm thử logic cốt lõi đã vượt qua thành công!`
