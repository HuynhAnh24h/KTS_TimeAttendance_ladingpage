from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class ShiftBase(BaseModel):
    code: str = Field(..., example="HC_8H")
    name: str = Field(..., example="Ca Hành Chính Chuẩn (8:00 - 17:30)")
    start_time: str = Field(..., example="08:00")
    end_time: str = Field(..., example="17:30")
    break_start: Optional[str] = Field("12:00", example="12:00")
    break_end: Optional[str] = Field("13:30", example="13:30")
    grace_period_minutes: int = Field(15, example=15)
    ot_start_after_minutes: int = Field(30, example=30)
    standard_work_hours: float = Field(8.0, example=8.0)
    work_units: float = Field(1.0, example=1.0)
    is_default: bool = False

class ShiftCreate(ShiftBase):
    pass

class ShiftUpdate(BaseModel):
    code: Optional[str] = None
    name: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    break_start: Optional[str] = None
    break_end: Optional[str] = None
    grace_period_minutes: Optional[int] = None
    ot_start_after_minutes: Optional[int] = None
    standard_work_hours: Optional[float] = None
    work_units: Optional[float] = None
    is_default: Optional[bool] = None

class ShiftOut(ShiftBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
