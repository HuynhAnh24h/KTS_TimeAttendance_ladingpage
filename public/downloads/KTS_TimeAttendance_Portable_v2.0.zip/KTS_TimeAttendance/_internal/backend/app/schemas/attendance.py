from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime, date

class RawAttendanceLogOut(BaseModel):
    id: int
    zk_user_id: str
    check_time: datetime
    punch_state: int
    verify_type: int
    device_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True

class DailyAttendanceOut(BaseModel):
    id: int
    attendance_date: date
    employee_id: int
    shift_id: Optional[int] = None
    first_check_in: Optional[datetime] = None
    last_check_out: Optional[datetime] = None
    late_minutes: int = 0
    early_leave_minutes: int = 0
    standard_hours: float = 0.0
    ot_15_hours: float = 0.0
    ot_20_hours: float = 0.0
    ot_30_hours: float = 0.0
    work_units: float = 0.0
    status: str
    leave_type: Optional[str] = None
    is_manual_override: bool = False
    notes: Optional[str] = None

    class Config:
        from_attributes = True

class DailyAttendanceUpdate(BaseModel):
    first_check_in: Optional[datetime] = None
    last_check_out: Optional[datetime] = None
    work_units: Optional[float] = None
    ot_15_hours: Optional[float] = None
    ot_20_hours: Optional[float] = None
    ot_30_hours: Optional[float] = None
    status: Optional[str] = None
    leave_type: Optional[str] = None
    notes: Optional[str] = None

class MatrixCell(BaseModel):
    day: int
    date_str: str
    status: str # FULL_DAY, HALF_DAY, LATE_EARLY, OVERTIME, ABSENT, HOLIDAY, HOLIDAY_WORK, LEAVE_PAID, LEAVE_UNPAID, LEAVE_INSURANCE, BUSINESS_TRIP, WEEKEND, NO_DATA
    leave_type: Optional[str] = None
    symbol: Optional[str] = None # 1.0, 0.5, P, L, L*, Ro, Ô, TS, VR, CT, V, -
    work_units: float
    late_minutes: int
    early_leave_minutes: int
    ot_hours: float
    ot_30_hours: float = 0.0
    first_check_in_str: Optional[str] = None
    last_check_out_str: Optional[str] = None
    is_weekend: bool = False
    is_manual_override: bool = False
    daily_attendance_id: Optional[int] = None
    notes: Optional[str] = None

class AttendanceRegularizeRequest(BaseModel):
    employee_id: int
    attendance_date: date
    compensation_type: str = "FULL_DAY" # FULL_DAY, HALF_DAY_MORNING, HALF_DAY_AFTERNOON, MISSING_IN, MISSING_OUT, CUSTOM
    check_in_time: Optional[str] = None # "07:30"
    check_out_time: Optional[str] = None # "16:30"
    work_units: Optional[float] = 1.0
    ot_hours: Optional[float] = 0.0
    notes: str # Bắt buộc ghi rõ lý do chấm bù

class DailyReportSummary(BaseModel):
    total_employees: int
    present_count: int
    absent_count: int
    late_count: int
    early_count: int
    ot_count: int
    leave_count: int
    manual_count: int

class DailyReportRecord(BaseModel):
    daily_attendance_id: Optional[int] = None
    employee_id: int
    employee_code: str
    full_name: str
    department: str
    position: Optional[str] = None
    shift_name: str
    first_check_in_str: Optional[str] = None
    last_check_out_str: Optional[str] = None
    late_minutes: int = 0
    early_leave_minutes: int = 0
    ot_hours: float = 0.0
    work_units: float = 0.0
    status: str
    symbol: Optional[str] = None
    is_manual_override: bool = False
    notes: Optional[str] = None

class DailyReportResponse(BaseModel):
    date: str
    summary: DailyReportSummary
    records: List[DailyReportRecord]

class TimesheetRow(BaseModel):
    employee_id: int
    employee_code: str
    full_name: str
    department: str
    position: Optional[str] = None
    zk_user_id: str
    days: Dict[int, MatrixCell]
    total_work_units: float
    total_late_minutes: int
    total_ot_hours: float
    total_ot_30_hours: float = 0.0
    total_paid_leave_days: float = 0.0
    total_holiday_days: float = 0.0
    total_unpaid_leave_days: float = 0.0
    total_actual_work_units: float = 0.0

class TimesheetMatrixResponse(BaseModel):
    month: int
    year: int
    days_in_month: int
    total_employees: int
    rows: List[TimesheetRow]

class SyncRequest(BaseModel):
    device_id: Optional[int] = None # None = sync all active devices
    simulate_mode: bool = False     # Cho phép sinh log thử nghiệm nếu không có máy thực tế

class SyncResponse(BaseModel):
    success: bool
    total_synced_logs: int
    new_logs_saved: int
    devices_contacted: int
    errors: List[str] = []

class CalculationRequest(BaseModel):
    month: int
    year: int
    employee_id: Optional[int] = None

class CalculationResponse(BaseModel):
    success: bool
    message: str
    total_records_calculated: int
