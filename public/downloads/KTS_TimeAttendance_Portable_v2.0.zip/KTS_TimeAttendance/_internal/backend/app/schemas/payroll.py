from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field

class SalaryConfigOut(BaseModel):
    id: int
    employee_id: int
    base_salary: float
    allowance_diligence: float
    allowance_meal: float
    allowance_transport: float
    allowance_hazardous: float
    allowance_position: float
    insurance_rate: float
    total_allowance: float

    class Config:
        from_attributes = True

class SalaryConfigUpdate(BaseModel):
    base_salary: Optional[float] = None
    allowance_diligence: Optional[float] = None
    allowance_meal: Optional[float] = None
    allowance_transport: Optional[float] = None
    allowance_hazardous: Optional[float] = None
    allowance_position: Optional[float] = None
    insurance_rate: Optional[float] = None

class PayrollRecordOut(BaseModel):
    id: int
    employee_id: int
    employee_code: str
    employee_name: str
    department: str
    position: Optional[str] = None
    year: int
    month: int
    standard_days: float
    actual_work_days: float
    paid_leave_days: float
    holiday_days: float
    total_paid_days: float
    ot_normal_hours: float
    ot_sunday_hours: float
    ot_holiday_hours: float
    night_shift_hours: float
    base_salary: float
    day_rate: float
    hour_rate: float
    salary_by_work_days: float
    salary_ot_normal: float
    salary_ot_sunday: float
    salary_ot_holiday: float
    salary_night_bonus: float
    total_ot_salary: float
    allowance_diligence: float
    allowance_meal: float
    allowance_transport: float
    allowance_hazardous: float
    allowance_position: float
    total_allowance: float
    gross_salary: float
    advance_amount: float
    insurance_deduction: float
    other_deduction: float
    total_deductions: float
    net_salary: float
    notes: Optional[str] = None
    status: str
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class PayrollRecordUpdate(BaseModel):
    advance_amount: Optional[float] = None
    other_deduction: Optional[float] = None
    notes: Optional[str] = None
    status: Optional[str] = None

class PayrollSummaryResponse(BaseModel):
    year: int
    month: int
    department: str
    total_employees: int
    total_gross_payroll: float
    total_net_payroll: float
    total_ot_hours: float
    total_ot_salary: float
    total_advance_amount: float
    total_insurance_deduction: float
    records: List[PayrollRecordOut]

class PayrollCalculateRequest(BaseModel):
    year: int
    month: int
    department: Optional[str] = None
