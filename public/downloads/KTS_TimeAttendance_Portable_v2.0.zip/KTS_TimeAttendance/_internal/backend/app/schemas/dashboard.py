from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class RecentPunchItem(BaseModel):
    id: int
    zk_user_id: str
    employee_name: str
    department: str
    check_time: datetime
    device_name: str
    punch_type_desc: str

class DashboardSummary(BaseModel):
    today_date: str
    total_employees: int
    active_employees: int
    working_today: int
    late_today: int
    absent_today: int
    ot_count_today: int
    devices_online: int
    devices_total: int
    recent_punches: List[RecentPunchItem]
