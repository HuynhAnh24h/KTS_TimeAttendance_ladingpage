from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, date
from backend.app.schemas.shift import ShiftOut

class EmployeeBase(BaseModel):
    zk_user_id: str = Field(..., example="1001", description="Mã chấm công trên máy ZK")
    employee_code: str = Field(..., example="KDB000001", description="Mã nhân viên nội bộ")
    full_name: str = Field(..., example="HỒ TRIỀU DƯƠNG")
    chinese_name: Optional[str] = None
    
    # Thông tin cá nhân
    gender: Optional[str] = "Nam"
    birth_date: Optional[date] = None
    age: Optional[int] = None
    birth_place: Optional[str] = None
    nationality: Optional[str] = "Việt Nam"
    education: Optional[str] = None
    
    # Địa chỉ
    permanent_address: Optional[str] = None
    original_address: Optional[str] = None
    current_address: Optional[str] = None
    
    # Giấy tờ tùy thân & Chuyên gia
    id_card_no: Optional[str] = None
    id_card_date: Optional[date] = None
    id_card_place: Optional[str] = None
    old_id_card_no: Optional[str] = None
    passport_no: Optional[str] = None
    passport_date: Optional[date] = None
    visa_date: Optional[date] = None
    work_permit_no: Optional[str] = None
    work_permit_date: Optional[date] = None
    work_permit_place: Optional[str] = None
    hospital: Optional[str] = None
    
    # Liên hệ
    phone: Optional[str] = None
    email: Optional[str] = None
    emergency_contact: Optional[str] = None
    
    # Vị trí & Phân bổ
    department: str = Field("Sản xuất", example="Kế Toán")
    position: Optional[str] = Field("Công nhân", example="Nhân viên")
    workshop: Optional[str] = None
    hire_date: Optional[date] = None
    card_number: Optional[str] = None
    shift_id: Optional[int] = None
    
    # Trạng thái công việc
    is_active: bool = True
    status: Optional[str] = "active"
    
    # Hợp đồng
    contract_code: Optional[str] = None
    contract_type: Optional[str] = None
    contract_type_cn: Optional[str] = None
    contract_start_date: Optional[date] = None
    contract_end_date: Optional[date] = None
    contract_term_years: Optional[str] = None
    
    # Tiền lương & BHXH
    base_salary: Optional[float] = 5315000.0
    allowance_position: Optional[float] = 0.0
    probation_salary: Optional[float] = None
    official_salary: Optional[float] = None
    insurance_salary: Optional[float] = 5315000.0
    social_insurance_no: Optional[str] = None
    insurance_increase_month: Optional[str] = None
    insurance_decrease_month: Optional[str] = None
    union_fee: Optional[float] = 26575.0
    union_join_date: Optional[date] = None
    
    # Ngân hàng
    bank_techcombank: Optional[str] = None
    bank_acb: Optional[str] = None
    bank_vietcombank: Optional[str] = None
    bank_sacombank: Optional[str] = None
    
    # Hậu cần & Trang phục
    uniform_status: Optional[str] = None
    shirt_size: Optional[str] = None
    shirt_color: Optional[str] = None
    referrer: Optional[str] = None
    
    # Thai sản & Con nhỏ
    maternity_leave_start: Optional[date] = None
    maternity_leave_end: Optional[date] = None
    maternity_off_month: Optional[str] = None
    maternity_on_month: Optional[str] = None
    child_birth_date: Optional[date] = None
    childcare_end_date: Optional[date] = None
    is_pregnant: Optional[bool] = False
    pregnancy_start_date: Optional[date] = None
    
    # Thôi việc
    resignation_date: Optional[date] = None
    resignation_reason: Optional[str] = None
    medical_fee_collected: Optional[float] = 0.0
    contract_deduction: Optional[float] = 0.0
    
    notes: Optional[str] = None

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeUpdate(BaseModel):
    zk_user_id: Optional[str] = None
    employee_code: Optional[str] = None
    full_name: Optional[str] = None
    chinese_name: Optional[str] = None
    gender: Optional[str] = None
    birth_date: Optional[date] = None
    age: Optional[int] = None
    birth_place: Optional[str] = None
    nationality: Optional[str] = None
    education: Optional[str] = None
    permanent_address: Optional[str] = None
    original_address: Optional[str] = None
    current_address: Optional[str] = None
    id_card_no: Optional[str] = None
    id_card_date: Optional[date] = None
    id_card_place: Optional[str] = None
    old_id_card_no: Optional[str] = None
    passport_no: Optional[str] = None
    passport_date: Optional[date] = None
    visa_date: Optional[date] = None
    work_permit_no: Optional[str] = None
    work_permit_date: Optional[date] = None
    work_permit_place: Optional[str] = None
    hospital: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    emergency_contact: Optional[str] = None
    department: Optional[str] = None
    position: Optional[str] = None
    workshop: Optional[str] = None
    hire_date: Optional[date] = None
    card_number: Optional[str] = None
    shift_id: Optional[int] = None
    is_active: Optional[bool] = None
    status: Optional[str] = None
    contract_code: Optional[str] = None
    contract_type: Optional[str] = None
    contract_type_cn: Optional[str] = None
    contract_start_date: Optional[date] = None
    contract_end_date: Optional[date] = None
    contract_term_years: Optional[str] = None
    base_salary: Optional[float] = None
    allowance_position: Optional[float] = None
    probation_salary: Optional[float] = None
    official_salary: Optional[float] = None
    insurance_salary: Optional[float] = None
    social_insurance_no: Optional[str] = None
    insurance_increase_month: Optional[str] = None
    insurance_decrease_month: Optional[str] = None
    union_fee: Optional[float] = None
    union_join_date: Optional[date] = None
    bank_techcombank: Optional[str] = None
    bank_acb: Optional[str] = None
    bank_vietcombank: Optional[str] = None
    bank_sacombank: Optional[str] = None
    uniform_status: Optional[str] = None
    shirt_size: Optional[str] = None
    shirt_color: Optional[str] = None
    referrer: Optional[str] = None
    maternity_leave_start: Optional[date] = None
    maternity_leave_end: Optional[date] = None
    maternity_off_month: Optional[str] = None
    maternity_on_month: Optional[str] = None
    child_birth_date: Optional[date] = None
    childcare_end_date: Optional[date] = None
    is_pregnant: Optional[bool] = None
    pregnancy_start_date: Optional[date] = None
    resignation_date: Optional[date] = None
    resignation_reason: Optional[str] = None
    medical_fee_collected: Optional[float] = None
    contract_deduction: Optional[float] = None
    notes: Optional[str] = None

class EmployeeOut(EmployeeBase):
    id: int
    created_at: datetime
    shift: Optional[ShiftOut] = None

    class Config:
        from_attributes = True

class EmployeeStatsSummary(BaseModel):
    total_employees: int
    active_employees: int
    probation_employees: int
    resigned_employees: int
    maternity_childcare_count: int
    foreign_expert_count: int
    department_counts: dict
    workshop_counts: dict

class EmployeeImportResult(BaseModel):
    total_processed: int
    success_count: int
    failed_count: int
    errors: list[str] = []
