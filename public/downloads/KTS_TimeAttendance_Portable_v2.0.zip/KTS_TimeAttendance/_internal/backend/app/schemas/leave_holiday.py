from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field

# ================= HOLIDAY SCHEMAS =================
class HolidayBase(BaseModel):
    name: str = Field(..., max_length=100, description="Tên ngày lễ")
    start_date: date = Field(..., description="Ngày bắt đầu")
    end_date: date = Field(..., description="Ngày kết thúc")
    ot_rate: float = Field(default=3.0, description="Hệ số làm thêm ngày lễ")
    description: Optional[str] = Field(None, max_length=255, description="Ghi chú")

class HolidayCreate(HolidayBase):
    pass

class HolidayUpdate(BaseModel):
    name: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    ot_rate: Optional[float] = None
    description: Optional[str] = None

class HolidayOut(HolidayBase):
    id: int
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# ================= LEAVE REQUEST SCHEMAS =================
class LeaveRequestBase(BaseModel):
    employee_id: int
    leave_type: str = Field(..., description="ANNUAL, SICK, MATERNITY, MARRIAGE, UNPAID, BUSINESS_TRIP")
    start_date: date
    end_date: date
    half_day_type: str = Field(default="FULL", description="FULL, MORNING, AFTERNOON")
    reason: Optional[str] = None
    status: str = Field(default="APPROVED", description="APPROVED, PENDING, REJECTED")
    approved_by: Optional[str] = None

class LeaveRequestCreate(LeaveRequestBase):
    pass

class LeaveRequestUpdate(BaseModel):
    leave_type: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    half_day_type: Optional[str] = None
    reason: Optional[str] = None
    status: Optional[str] = None
    approved_by: Optional[str] = None

class LeaveRequestOut(LeaveRequestBase):
    id: int
    created_at: Optional[datetime] = None
    employee_code: Optional[str] = None
    employee_name: Optional[str] = None
    department: Optional[str] = None

    class Config:
        from_attributes = True
