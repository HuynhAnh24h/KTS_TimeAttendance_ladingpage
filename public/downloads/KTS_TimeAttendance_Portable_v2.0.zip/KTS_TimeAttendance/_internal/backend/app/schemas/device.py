from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class DeviceBase(BaseModel):
    name: str = Field(..., example="Máy Ronald Jack 879C Cửa Chính")
    brand: str = Field(default="ZKTECO", example="ZKTECO", description="ZKTECO, RONALD_JACK, HIKVISION, DAHUA, ANVIZ, OTHER")
    protocol_type: str = Field(default="ZK_UDP", example="ZK_UDP", description="ZK_UDP (4370), HIK_ISAPI, DAHUA_CGI, ANVIZ_TCP, CLOUD_PUSH")
    ip_address: str = Field(..., example="192.168.1.201")
    port: int = Field(default=4370, example=4370)
    comm_password: Optional[str] = Field(None, example="0", description="Mật khẩu máy / Comm key")
    username: Optional[str] = Field(None, example="admin", description="Tài khoản nếu là Hikvision/Dahua")
    location: Optional[str] = Field(None, example="Tầng 1 - Cửa chính")
    is_active: bool = True

class DeviceCreate(DeviceBase):
    pass

class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    brand: Optional[str] = None
    protocol_type: Optional[str] = None
    ip_address: Optional[str] = None
    port: Optional[int] = None
    comm_password: Optional[str] = None
    username: Optional[str] = None
    location: Optional[str] = None
    is_active: Optional[bool] = None

class DeviceOut(DeviceBase):
    id: int
    status: str
    last_synced_at: Optional[datetime] = None
    serial_number: Optional[str] = None
    device_name_hw: Optional[str] = None
    firmware_version: Optional[str] = None
    user_count: int = 0
    log_count: int = 0
    created_at: datetime

    class Config:
        from_attributes = True

class DeviceTestResult(BaseModel):
    success: bool
    message: str
    device_name: Optional[str] = None
    serial_number: Optional[str] = None
    user_count: Optional[int] = None
    log_count: Optional[int] = None
