import logging
from datetime import date
from sqlalchemy.orm import Session
from backend.app.models.shift import Shift
from backend.app.models.device import Device
from backend.app.models.employee import Employee
from backend.app.models.holiday import Holiday
from backend.app.models.user import User
from backend.app.core.security import hash_password

logger = logging.getLogger("seed_data")

def init_seed_data(db: Session):
    """
    Khởi tạo Ca làm việc chuẩn, Ngày Lễ Việt Nam và Tài khoản Super Admin Tối Cao:
    Tài khoản: superadmin / superadmin123 (Có toàn quyền quản trị, cài đặt và phân quyền nhân sự/kế toán)
    """
    # Dọn dẹp tài khoản superadmin cũ nếu có
    super_user = db.query(User).filter(User.username == "superadmin").first()
    if super_user:
        db.delete(super_user)
        db.commit()
        logger.info("Đã dọn dẹp tài khoản superadmin.")

    # Đảm bảo tài khoản Quản trị viên (admin) mặc định luôn tồn tại
    has_admin = db.query(User).filter(User.username == "admin").first()
    if not has_admin:
        admin_pw, admin_salt = hash_password("Admin@123")
        admin_user = User(
            username="admin",
            hashed_password=admin_pw,
            salt=admin_salt,
            full_name="Quản Trị Viên Hệ Thống",
            email="admin@kts.vn",
            role="admin",
            is_active=True
        )
        db.add(admin_user)
        db.commit()
        logger.info("Đã khởi tạo tài khoản Quản trị viên: admin / Admin@123")

    # Ngày lễ Việt Nam
    if db.query(Holiday).count() == 0:
        vn_holidays = [
            Holiday(
                name="Tết Dương Lịch 2026",
                start_date=date(2026, 1, 1),
                end_date=date(2026, 1, 1),
                ot_rate=3.0,
                description="Nghỉ 01 ngày hưởng nguyên lương theo BLLĐ"
            ),
            Holiday(
                name="Tết Nguyên Đán Bính Ngọ 2026",
                start_date=date(2026, 2, 15),
                end_date=date(2026, 2, 21),
                ot_rate=3.0,
                description="Nghỉ Tết Âm lịch theo thông báo của Bộ LĐ-TB&XH"
            ),
            Holiday(
                name="Giỗ Tổ Hùng Vương 2026",
                start_date=date(2026, 4, 26),
                end_date=date(2026, 4, 26),
                ot_rate=3.0,
                description="Mùng 10 tháng 3 Âm lịch"
            ),
            Holiday(
                name="Ngày Chiến Thắng (30/4) & Quốc Tế Lao Động (1/5) 2026",
                start_date=date(2026, 4, 30),
                end_date=date(2026, 5, 1),
                ot_rate=3.0,
                description="Nghỉ 02 ngày hưởng nguyên lương"
            ),
            Holiday(
                name="Quốc Khánh 2026 (2/9)",
                start_date=date(2026, 9, 1),
                end_date=date(2026, 9, 2),
                ot_rate=3.0,
                description="Nghỉ 02 ngày hưởng nguyên lương theo Luật Lao Động"
            )
        ]
        db.add_all(vn_holidays)
        db.commit()

    # Ca làm việc
    if db.query(Shift).count() == 0:
        default_shifts = [
            Shift(
                code="HC_8H",
                name="Ca Hành Chính Chuẩn (08:00 - 17:30)",
                start_time="08:00",
                end_time="17:30",
                break_start="12:00",
                break_end="13:30",
                grace_period_minutes=15,
                ot_start_after_minutes=30,
                standard_work_hours=8.0,
                work_units=1.0,
                is_default=True
            ),
            Shift(
                code="CA_SANG",
                name="Ca Sáng Nhà Máy (06:00 - 14:00)",
                start_time="06:00",
                end_time="14:00",
                break_start="10:00",
                break_end="10:30",
                grace_period_minutes=10,
                ot_start_after_minutes=15,
                standard_work_hours=7.5,
                work_units=1.0,
                is_default=False
            ),
            Shift(
                code="CA_CHIEU",
                name="Ca Chiều Nhà Máy (14:00 - 22:00)",
                start_time="14:00",
                end_time="22:00",
                break_start="18:00",
                break_end="18:30",
                grace_period_minutes=10,
                ot_start_after_minutes=15,
                standard_work_hours=7.5,
                work_units=1.0,
                is_default=False
            )
        ]
        db.add_all(default_shifts)
        db.commit()
