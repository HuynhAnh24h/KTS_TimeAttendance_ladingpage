from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Float, ForeignKey, Text
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class Employee(Base):
    """
    Thông tin hồ sơ nhân viên toàn diện (Enterprise HR Management):
    Bao gồm nhân sự Việt Nam, Chuyên gia nước ngoài, Hợp đồng, Lương, BHXH, Chế độ Thai sản & Con nhỏ, Nghỉ việc.
    """
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True, index=True)
    zk_user_id = Column(String(50), unique=True, index=True, nullable=False, comment="ID đăng ký trên máy chấm công")
    employee_code = Column(String(50), unique=True, index=True, nullable=False, comment="Mã nhân viên (KDB000001,...)")
    full_name = Column(String(150), nullable=False, index=True, comment="Họ và tên tiếng Việt")
    chinese_name = Column(String(100), nullable=True, index=True, comment="Tên tiếng Hoa (名字)")
    
    # Thông tin cá nhân
    gender = Column(String(10), nullable=True, default="Nam", comment="Giới tính: Nam/Nữ")
    birth_date = Column(Date, nullable=True, comment="Ngày sinh")
    age = Column(Integer, nullable=True, comment="Tuổi")
    birth_place = Column(String(100), nullable=True, comment="Nơi sinh / Tỉnh thành quê quán")
    nationality = Column(String(100), nullable=True, default="Việt Nam", comment="Quốc tịch")
    education = Column(String(50), nullable=True, comment="Trình độ học vấn (9/12, 12/12, Cao đẳng, Đại học...)")
    
    # Địa chỉ
    permanent_address = Column(String(255), nullable=True, comment="Địa chỉ thường trú (sau sáp nhập tỉnh)")
    original_address = Column(String(255), nullable=True, comment="Địa chỉ trước sáp nhập tỉnh")
    current_address = Column(String(255), nullable=True, comment="Nơi cư trú hiện tại")
    
    # Giấy tờ tùy thân & Chuyên gia
    id_card_no = Column(String(30), nullable=True, index=True, comment="Số CCCD / CMND")
    id_card_date = Column(Date, nullable=True, comment="Ngày cấp CCCD")
    id_card_place = Column(String(100), nullable=True, comment="Nơi cấp CCCD")
    old_id_card_no = Column(String(30), nullable=True, comment="Số CMND cũ 9 số")
    passport_no = Column(String(50), nullable=True, comment="Số hộ chiếu (Chuyên gia/TQ)")
    passport_date = Column(Date, nullable=True, comment="Ngày cấp hộ chiếu")
    visa_date = Column(Date, nullable=True, comment="Ngày cấp VISA")
    work_permit_no = Column(String(50), nullable=True, comment="Số giấy phép lao động (GPLĐ)")
    work_permit_date = Column(Date, nullable=True, comment="Ngày cấp GPLĐ")
    work_permit_place = Column(String(150), nullable=True, comment="Nơi cấp GPLĐ")
    hospital = Column(String(150), nullable=True, comment="Bệnh viện đăng ký khám chữa bệnh (BV)")
    
    # Liên hệ
    phone = Column(String(50), nullable=True, comment="Số điện thoại cá nhân")
    email = Column(String(100), nullable=True, comment="Email")
    emergency_contact = Column(String(255), nullable=True, comment="Số ĐT người thân & quan hệ (098...-vợ)")
    
    # Vị trí & Phân bổ
    department = Column(String(100), nullable=False, default="Sản xuất", index=True, comment="Bộ phận / Phòng ban")
    position = Column(String(100), nullable=True, default="Công nhân", comment="Chức vụ")
    workshop = Column(String(100), nullable=True, comment="Xưởng làm việc (VPC, VPX, Xưởng 5, Chế Gỗ...)")
    hire_date = Column(Date, nullable=True, comment="Ngày vào làm")
    card_number = Column(String(50), nullable=True, comment="Mã thẻ từ RFID")
    shift_id = Column(Integer, ForeignKey("shifts.id"), nullable=True, comment="Ca làm việc áp dụng")
    
    # Trạng thái công việc
    is_active = Column(Boolean, default=True, index=True, comment="Còn làm việc hay không")
    status = Column(String(50), default="active", index=True, comment="active, probation, resigned, maternity, childcare, pregnant, partner_support, foreign_expert")
    
    # Hợp đồng lao động
    contract_code = Column(String(50), nullable=True, comment="Mã HĐ (HDCT1Y, HDCT2Y, HDVTH, HDTV1M...)")
    contract_type = Column(String(100), nullable=True, comment="Loại HĐ tiếng Việt (Có thời hạn 12 tháng, Vô thời hạn...)")
    contract_type_cn = Column(String(100), nullable=True, comment="Loại HĐ tiếng Hoa (有期限勞動合同12个月, 无期限...)")
    contract_start_date = Column(Date, nullable=True, comment="HĐ từ ngày")
    contract_end_date = Column(Date, nullable=True, comment="HĐ đến ngày")
    contract_term_years = Column(String(20), nullable=True, comment="Thời hạn hợp đồng (năm/tháng)")
    
    # Tiền lương & Phúc lợi & Bảo hiểm
    base_salary = Column(Float, default=5315000.0, nullable=True, comment="Mức lương cơ bản (VND)")
    allowance_position = Column(Float, default=0.0, nullable=True, comment="Phụ cấp chức vụ (崗位工資)")
    probation_salary = Column(Float, nullable=True, comment="Lương thử việc")
    official_salary = Column(Float, nullable=True, comment="Tổng lương chính thức")
    insurance_salary = Column(Float, default=5315000.0, nullable=True, comment="Mức lương đóng BHXH")
    social_insurance_no = Column(String(50), nullable=True, comment="Mã số sổ BHXH")
    insurance_increase_month = Column(String(20), nullable=True, comment="Tháng báo tăng BHXH (01/2025...)")
    insurance_decrease_month = Column(String(20), nullable=True, comment="Tháng báo giảm BHXH")
    union_fee = Column(Float, default=26575.0, nullable=True, comment="Mức đóng công đoàn")
    union_join_date = Column(Date, nullable=True, comment="Ngày vào công đoàn")
    
    # Ngân hàng
    bank_techcombank = Column(String(50), nullable=True, comment="STK Techcombank")
    bank_acb = Column(String(50), nullable=True, comment="STK ACB")
    bank_vietcombank = Column(String(50), nullable=True, comment="STK Vietcombank")
    bank_sacombank = Column(String(50), nullable=True, comment="STK Sacombank")
    
    # Hậu cần & Trang bị
    uniform_status = Column(String(50), nullable=True, comment="Cấp đồng phục (Lần 1, Lần 2...)")
    shirt_size = Column(String(20), nullable=True, comment="Size áo (S, M, L, XL, 2XL, 3XL, 4XL)")
    shirt_color = Column(String(20), nullable=True, comment="Màu áo (cam, xanh)")
    referrer = Column(String(150), nullable=True, comment="Người giới thiệu / Chi tiền giới thiệu")
    
    # Chế độ Thai sản & Nuôi con nhỏ
    maternity_leave_start = Column(Date, nullable=True, comment="Ngày nghỉ sinh")
    maternity_leave_end = Column(Date, nullable=True, comment="Ngày vào làm lại sau sinh")
    maternity_off_month = Column(String(20), nullable=True, comment="Tháng báo giảm thai sản (OF)")
    maternity_on_month = Column(String(20), nullable=True, comment="Tháng báo tăng đi làm lại (ON)")
    child_birth_date = Column(Date, nullable=True, comment="Ngày sinh con")
    childcare_end_date = Column(Date, nullable=True, comment="Ngày hết nuôi con nhỏ (đủ 12 tháng - về sớm 1h)")
    is_pregnant = Column(Boolean, default=False, comment="Đang mang thai")
    pregnancy_start_date = Column(Date, nullable=True, comment="Ngày bắt đầu mang thai / Tuần thai")
    
    # Thôi việc & Kỷ luật
    resignation_date = Column(Date, nullable=True, comment="Ngày thôi việc / nghỉ việc")
    resignation_reason = Column(String(255), nullable=True, comment="Lý do nghỉ việc")
    medical_fee_collected = Column(Float, default=0.0, nullable=True, comment="Thu tiền y tế BHYT (VND)")
    contract_deduction = Column(Float, default=0.0, nullable=True, comment="Trừ hợp đồng / bồi thường")
    
    # Ghi chú
    notes = Column(Text, nullable=True, comment="Ghi chú tổng hợp / Ký tên")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    shift = relationship("Shift", back_populates="employees")
    daily_attendances = relationship("DailyAttendance", back_populates="employee", cascade="all, delete-orphan")
