from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Date, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class DailyAttendance(Base):
    """
    Bảng kết quả tính công tổng hợp theo ngày của nhân viên.
    Được sinh ra bởi Calculation Engine sau khi phân tích các log quẹt thẻ thô.
    """
    __tablename__ = "daily_attendances"

    id = Column(Integer, primary_key=True, index=True)
    attendance_date = Column(Date, nullable=False, index=True, comment="Ngày làm việc YYYY-MM-DD")
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    shift_id = Column(Integer, ForeignKey("shifts.id", ondelete="SET NULL"), nullable=True)

    # Giờ vào/ra thực tế
    first_check_in = Column(DateTime, nullable=True, comment="Giờ vào hợp lệ đầu tiên trong ca")
    last_check_out = Column(DateTime, nullable=True, comment="Giờ ra hợp lệ cuối cùng trong ca")

    # Chỉ số trễ / sớm
    late_minutes = Column(Integer, default=0, comment="Số phút đi trễ (đã trừ grace period)")
    early_leave_minutes = Column(Integer, default=0, comment="Số phút về sớm (đã trừ grace period)")

    # Giờ công và giờ làm thêm
    standard_hours = Column(Float, default=0.0, comment="Số giờ công chuẩn thực tế (đã trừ nghỉ trưa)")
    ot_15_hours = Column(Float, default=0.0, comment="Số giờ làm thêm ngày thường (hệ số 1.5)")
    ot_20_hours = Column(Float, default=0.0, comment="Số giờ làm thêm ngày nghỉ/chủ nhật (hệ số 2.0)")
    ot_30_hours = Column(Float, default=0.0, comment="Số giờ làm thêm ngày Lễ/Tết (hệ số 3.0)")
    
    # Quy đổi công (1.0 = Đủ công, 0.5 = Nửa công, 0 = Không công)
    work_units = Column(Float, default=0.0, comment="Hệ số công ngày (1.0, 0.5, 0.0)")

    # Phân loại nghỉ phép nếu có
    leave_type = Column(String(30), nullable=True, comment="ANNUAL, SICK, MATERNITY, MARRIAGE, UNPAID, BUSINESS_TRIP, HOLIDAY")

    # Trạng thái tổng hợp:
    # FULL_DAY: Đủ công
    # HALF_DAY: Nửa ngày công
    # LATE_EARLY: Có đi trễ hoặc về sớm
    # OVERTIME: Có làm thêm giờ
    # ABSENT: Vắng không phép
    # ON_LEAVE: Nghỉ phép có lương
    # MANUAL: Đã can thiệp sửa tay
    status = Column(String(30), default="ABSENT", index=True)

    is_manual_override = Column(Boolean, default=False, comment="Đánh dấu bản ghi được chỉnh sửa thủ công")
    notes = Column(String(255), nullable=True, comment="Ghi chú (Lý do quên bấm vân tay, đi công tác...)")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employee = relationship("Employee", back_populates="daily_attendances")
    shift = relationship("Shift", back_populates="daily_attendances")

    __table_args__ = (
        UniqueConstraint("employee_id", "attendance_date", name="uq_emp_attendance_date"),
    )
