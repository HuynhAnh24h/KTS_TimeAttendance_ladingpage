from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class BiometricTemplate(Base):
    """
    Bảng lưu trữ mẫu vân tay sinh trắc học (Fingerprint Biometric Templates) từ máy ZKTeco.
    Cho phép:
    1. Sao lưu toàn bộ vân tay của nhân viên vào CSDL nội bộ.
    2. Đẩy ngược mẫu vân tay lên máy chấm công mới khi thay thế hoặc mở rộng xưởng
       mà KHÔNG cần công nhân phải đi lấy lại vân tay.
    """
    __tablename__ = "biometric_templates"

    id = Column(Integer, primary_key=True, index=True)
    zk_user_id = Column(String(50), nullable=False, index=True, comment="Mã chấm công của nhân viên trên máy")
    finger_index = Column(Integer, nullable=False, default=0, comment="Chỉ số ngón tay (0 đến 9)")
    template_data = Column(Text, nullable=False, comment="Dữ liệu mẫu vân tay nhị phân (mã hóa Base64)")
    template_size = Column(Integer, default=0, comment="Độ dài byte của mẫu vân tay")
    valid_flag = Column(Integer, default=1, comment="Cờ hợp lệ (1: hợp lệ)")
    
    device_id = Column(Integer, ForeignKey("devices.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    device = relationship("Device")

    __table_args__ = (
        UniqueConstraint("zk_user_id", "finger_index", name="uq_user_finger"),
    )
