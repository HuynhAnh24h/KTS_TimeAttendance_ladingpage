from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class LeaveRequest(Base):
    """
    Bảng quản lý Đơn xin nghỉ phép / Nghỉ chế độ của nhân viên:
    - ANNUAL (P): Nghỉ phép năm (Hưởng 100% lương)
    - SICK (Ô): Nghỉ ốm đau hưởng chế độ BHXH
    - MATERNITY (TS): Nghỉ thai sản BHXH
    - MARRIAGE (VR): Việc riêng có lương (Cưới hỏi, tang chế)
    - UNPAID (Ro): Nghỉ không hưởng lương
    - BUSINESS_TRIP (CT): Đi công tác bên ngoài (Hưởng 100% công)
    """
    __tablename__ = "leave_requests"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    leave_type = Column(String(30), nullable=False, comment="ANNUAL, SICK, MATERNITY, MARRIAGE, UNPAID, BUSINESS_TRIP")
    start_date = Column(Date, nullable=False, index=True, comment="Từ ngày")
    end_date = Column(Date, nullable=False, index=True, comment="Đến ngày")
    half_day_type = Column(String(20), default="FULL", comment="FULL (Cả ngày), MORNING (Sáng), AFTERNOON (Chiều)")
    reason = Column(String(255), nullable=True, comment="Lý do nghỉ phép")
    status = Column(String(20), default="APPROVED", comment="APPROVED, PENDING, REJECTED")
    approved_by = Column(String(100), nullable=True, comment="Người duyệt đơn")
    created_at = Column(DateTime, default=datetime.utcnow)

    # Quan hệ
    employee = relationship("Employee", backref="leave_requests")
