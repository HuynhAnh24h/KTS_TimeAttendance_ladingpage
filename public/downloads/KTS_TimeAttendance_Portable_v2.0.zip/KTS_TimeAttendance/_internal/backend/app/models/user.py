from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from backend.app.core.database import Base

class User(Base):
    """
    Bảng quản lý tài khoản người dùng và phân quyền (RBAC):
    - admin: Quản trị hệ thống (Toàn quyền quản lý user, kết nối máy IP, ca kíp, công, lương)
    - hr: Nhân sự (Quản lý hồ sơ nhân viên, máy chấm công, ca làm việc, chấm bù công, nghỉ phép & ngày lễ, báo cáo điểm danh)
    - accountant: Kế toán (Bảng công ma trận, báo cáo điểm danh, tính lương & phiếu lương, xuất Excel)
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False, comment="Tên đăng nhập")
    hashed_password = Column(String(255), nullable=False, comment="Mật khẩu mã hóa")
    salt = Column(String(64), nullable=False, comment="Chuỗi muối bảo mật")
    full_name = Column(String(100), nullable=False, comment="Họ và tên")
    email = Column(String(100), nullable=True, comment="Email liên hệ")
    role = Column(String(20), nullable=False, default="accountant", comment="admin, hr, accountant")
    is_active = Column(Boolean, default=True, comment="Trạng thái kích hoạt")
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True, comment="Thời gian đăng nhập gần nhất")

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "full_name": self.full_name,
            "email": self.email,
            "role": self.role,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None
        }
