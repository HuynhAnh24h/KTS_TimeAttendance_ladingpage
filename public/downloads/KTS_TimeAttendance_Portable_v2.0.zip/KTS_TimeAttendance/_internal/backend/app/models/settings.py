from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime
from backend.app.core.database import Base

class SystemSetting(Base):
    """
    Bảng lưu cấu hình doanh nghiệp và quy chế tính công, tính lương.
    Duy trì 1 dòng cấu hình chính (id=1).
    """
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True, default=1)
    
    # Thông tin Doanh nghiệp / Nhà xưởng
    company_name = Column(String(255), default="CÔNG TY TNHH KỸ THUẬT SỐ KTS", comment="Tên doanh nghiệp")
    company_address = Column(String(500), default="Khu Công Nghiệp, TP. Hồ Chí Minh", comment="Địa chỉ doanh nghiệp")
    company_phone = Column(String(50), default="0908 123 456", comment="Hotline / Số điện thoại")
    company_tax_id = Column(String(50), default="0312345678", comment="Mã số thuế")
    
    # Quy chế tính công & đi trễ
    standard_working_days = Column(Float, default=26.0, comment="Số ngày công chuẩn trong tháng (26 hoặc 24)")
    daily_working_hours = Column(Float, default=8.0, comment="Số giờ làm việc tiêu chuẩn 1 ca")
    late_grace_minutes = Column(Integer, default=5, comment="Số phút miễn trừ đi trễ (không bị phạt)")
    early_grace_minutes = Column(Integer, default=5, comment="Số phút miễn trừ về sớm")
    
    # Hệ số tăng ca & phụ cấp
    ot_normal_rate = Column(Float, default=1.5, comment="Hệ số tăng ca ngày thường (1.5x)")
    ot_sunday_rate = Column(Float, default=2.0, comment="Hệ số tăng ca ngày nghỉ hàng tuần/chủ nhật (2.0x)")
    ot_holiday_rate = Column(Float, default=3.0, comment="Hệ số tăng ca ngày lễ/tết (3.0x)")
    night_shift_bonus_rate = Column(Float, default=0.3, comment="Phụ cấp ca đêm (30%)")
    
    # Tự động hóa
    auto_calculate_on_sync = Column(Boolean, default=True, comment="Tự động tính công sau khi đồng bộ máy chấm công")
    
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
