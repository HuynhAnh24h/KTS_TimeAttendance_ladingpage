from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Float, Date, DateTime
from backend.app.core.database import Base

class Holiday(Base):
    """
    Bảng quản lý Ngày Lễ / Tết theo Luật Lao Động Việt Nam.
    Nhân viên nghỉ vào ngày này được hưởng 100% lương (1.0 công).
    Nếu đi làm vào ngày này sẽ được tính tăng ca hệ số OT 3.0 (300%).
    """
    __tablename__ = "holidays"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, comment="Tên ngày lễ (VD: Tết Dương Lịch, Quốc Khánh 2/9)")
    start_date = Column(Date, nullable=False, index=True, comment="Ngày bắt đầu")
    end_date = Column(Date, nullable=False, index=True, comment="Ngày kết thúc")
    ot_rate = Column(Float, default=3.0, comment="Hệ số làm thêm ngày lễ (mặc định 3.0 = 300%)")
    description = Column(String(255), nullable=True, comment="Mô tả / ghi chú")
    created_at = Column(DateTime, default=datetime.utcnow)
