from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class Device(Base):
    """
    Quản lý thông tin thiết bị máy chấm công IP (ZKTeco / Ronald Jack).
    Giao tiếp qua giao thức UDP port 4370 trong mạng LAN.
    """
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, comment="Tên gợi nhớ thiết bị (VD: Máy cửa chính)")
    brand = Column(String(50), default="ZKTECO", comment="Hãng: ZKTECO, RONALD_JACK, HIKVISION, DAHUA, ANVIZ")
    protocol_type = Column(String(30), default="ZK_UDP", comment="Giao thức: ZK_UDP (4370), HIK_ISAPI, DAHUA_CGI, ANVIZ_TCP, CLOUD_PUSH")
    ip_address = Column(String(45), nullable=False, unique=True, index=True, comment="Địa chỉ IP LAN của máy")
    port = Column(Integer, default=4370, nullable=False, comment="Cổng kết nối mặc định 4370 hoặc 80/8000")
    comm_password = Column(String(50), nullable=True, comment="Mật khẩu kết nối / Comm key")
    username = Column(String(50), nullable=True, comment="Tài khoản đăng nhập nếu là Hikvision/Dahua")
    location = Column(String(200), nullable=True, comment="Vị trí lắp đặt (Tầng 1, Kho, Xưởng)")
    
    is_active = Column(Boolean, default=True, comment="Trạng thái kích hoạt đồng bộ")
    status = Column(String(20), default="OFFLINE", comment="ONLINE, OFFLINE, ERROR, SYNCING")
    last_synced_at = Column(DateTime, nullable=True, comment="Thời điểm đồng bộ log thành công gần nhất")
    
    # Thông tin phần cứng lấy từ thiết bị
    serial_number = Column(String(100), nullable=True)
    device_name_hw = Column(String(100), nullable=True)
    firmware_version = Column(String(100), nullable=True)
    user_count = Column(Integer, default=0, comment="Số lượng vân tay/khuôn mặt trên máy")
    log_count = Column(Integer, default=0, comment="Tổng số bản ghi log đang lưu trong bộ nhớ máy")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    logs = relationship("RawAttendanceLog", back_populates="device", cascade="all, delete-orphan")
