from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class RawAttendanceLog(Base):
    """
    Log chấm công thô được kéo trực tiếp từ máy chấm công ZKTeco qua giao thức IP.
    Ràng buộc UniqueConstraint(zk_user_id, check_time) để đảm bảo không bao giờ bị nhân đôi bản ghi.
    """
    __tablename__ = "raw_attendance_logs"

    id = Column(Integer, primary_key=True, index=True)
    zk_user_id = Column(String(50), nullable=False, index=True, comment="Mã máy chấm công của nhân viên")
    check_time = Column(DateTime, nullable=False, index=True, comment="Thời gian quẹt vân tay/thẻ/khuôn mặt")
    
    # 0: Check-in, 1: Check-out, 2: Break-out, 3: Break-in, 4: OT-in, 5: OT-out, 255: Auto
    punch_state = Column(Integer, default=0, comment="Trạng thái quẹt máy trả về")
    
    # 1: Vân tay, 2: Khuôn mặt, 3: Mật mã, 4: Thẻ từ
    verify_type = Column(Integer, default=1, comment="Phương thức xác thực")
    
    device_id = Column(Integer, ForeignKey("devices.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    device = relationship("Device", back_populates="logs")

    __table_args__ = (
        UniqueConstraint("zk_user_id", "check_time", name="uq_user_check_time"),
    )
