from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class Shift(Base):
    """
    Ca làm việc của doanh nghiệp (Ca hành chính, ca xoay, ca tăng ca).
    Chứa các quy chuẩn về giờ vào, giờ ra, nghỉ trưa, mốc tính OT và ân hạn đi trễ.
    """
    __tablename__ = "shifts"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, index=True, nullable=False, comment="Mã ca: HC_8H, SANG, CHIEU")
    name = Column(String(100), nullable=False, comment="Tên ca: Ca hành chính (08:00 - 17:30)")
    
    # Định dạng "HH:MM" (VD: "08:00", "17:30")
    start_time = Column(String(5), nullable=False, default="08:00", comment="Giờ bắt đầu làm việc")
    end_time = Column(String(5), nullable=False, default="17:30", comment="Giờ kết thúc làm việc")
    
    break_start = Column(String(5), nullable=True, default="12:00", comment="Bắt đầu nghỉ trưa")
    break_end = Column(String(5), nullable=True, default="13:30", comment="Kết thúc nghỉ trưa")
    
    grace_period_minutes = Column(Integer, default=15, comment="Số phút cho phép đi trễ/về sớm mà không bị phạt")
    ot_start_after_minutes = Column(Integer, default=30, comment="Số phút làm thêm sau giờ ca mới bắt đầu tính OT")
    
    standard_work_hours = Column(Float, default=8.0, comment="Số giờ làm việc tiêu chuẩn trong ca")
    work_units = Column(Float, default=1.0, comment="Quy đổi ngày công chuẩn (thường là 1.0 công)")
    
    is_default = Column(Boolean, default=False, comment="Ca mặc định khi tạo mới nhân viên")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employees = relationship("Employee", back_populates="shift")
    daily_attendances = relationship("DailyAttendance", back_populates="shift")
