from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class SalaryConfig(Base):
    """
    Cấu hình mức lương cơ bản và các khoản phụ cấp hàng tháng của nhân viên:
    - base_salary: Lương cơ bản làm căn cứ đóng BHXH và tính đơn giá ngày công / giờ tăng ca.
    - allowance_diligence: Phụ cấp chuyên cần (thưởng đi làm đủ công, không trễ).
    - allowance_meal: Tiền cơm trưa nhà máy.
    - allowance_transport: Tiền xăng xe hỗ trợ đi lại.
    - allowance_hazardous: Phụ cấp độc hại / nặng nhọc nghề chế biến gỗ.
    - allowance_position: Phụ cấp chức vụ / tổ trưởng / quản đốc xưởng.
    - insurance_rate: Tỷ lệ trích đóng BHXH của người lao động (chuẩn Việt Nam: 8% BHXH + 1.5% BHYT + 1% BHTN = 10.5%).
    """
    __tablename__ = "salary_configs"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    base_salary = Column(Float, default=6500000.0, nullable=False, comment="Lương cơ bản (VND)")
    allowance_diligence = Column(Float, default=300000.0, nullable=False, comment="Phụ cấp chuyên cần")
    allowance_meal = Column(Float, default=650000.0, nullable=False, comment="Phụ cấp cơm trưa")
    allowance_transport = Column(Float, default=300000.0, nullable=False, comment="Phụ cấp xăng xe")
    allowance_hazardous = Column(Float, default=200000.0, nullable=False, comment="Phụ cấp độc hại gỗ")
    allowance_position = Column(Float, default=0.0, nullable=False, comment="Phụ cấp chức vụ / trách nhiệm")
    insurance_rate = Column(Float, default=10.5, nullable=False, comment="Tỷ lệ trích nộp BHXH cá nhân (%)")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Quan hệ
    employee = relationship("Employee", backref="salary_config", uselist=False)

    def to_dict(self):
        return {
            "id": self.id,
            "employee_id": self.employee_id,
            "base_salary": self.base_salary,
            "allowance_diligence": self.allowance_diligence,
            "allowance_meal": self.allowance_meal,
            "allowance_transport": self.allowance_transport,
            "allowance_hazardous": self.allowance_hazardous,
            "allowance_position": self.allowance_position,
            "insurance_rate": self.insurance_rate,
            "total_allowance": (
                self.allowance_diligence + self.allowance_meal + 
                self.allowance_transport + self.allowance_hazardous + 
                self.allowance_position
            )
        }

class PayrollRecord(Base):
    """
    Bảng thanh toán tiền lương hàng tháng chi tiết cho từng người lao động:
    Tuân thủ tuyệt đối quy định Bộ Luật Lao Động 2019:
    - Tăng ca ngày thường: 150% (1.5x)
    - Tăng ca ngày nghỉ hàng tuần (Chủ nhật): 200% (2.0x)
    - Tăng ca ngày lễ, tết: 300% (3.0x)
    - Phụ cấp ca đêm (22:00 - 06:00): Trả thêm ít nhất 30% tiền lương giờ thực trả
    """
    __tablename__ = "payroll_records"
    __table_args__ = (
        UniqueConstraint('employee_id', 'year', 'month', name='uix_emp_year_month'),
    )

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    year = Column(Integer, nullable=False, index=True)
    month = Column(Integer, nullable=False, index=True)

    # Ngày công & Tăng ca
    standard_days = Column(Float, default=26.0, comment="Ngày công chuẩn tháng")
    actual_work_days = Column(Float, default=0.0, comment="Số công làm thực tế")
    paid_leave_days = Column(Float, default=0.0, comment="Công phép năm / việc riêng có lương (P, VR, CT)")
    holiday_days = Column(Float, default=0.0, comment="Công ngày lễ tết hưởng nguyên lương")
    total_paid_days = Column(Float, default=0.0, comment="Tổng ngày công hưởng lương = actual + leave + holiday")

    # Giờ tăng ca & ca đêm
    ot_normal_hours = Column(Float, default=0.0, comment="Giờ làm thêm ngày thường (1.5x)")
    ot_sunday_hours = Column(Float, default=0.0, comment="Giờ làm thêm chủ nhật (2.0x)")
    ot_holiday_hours = Column(Float, default=0.0, comment="Giờ làm thêm ngày lễ (3.0x)")
    night_shift_hours = Column(Float, default=0.0, comment="Giờ làm ca đêm (+30%)")

    # Đơn giá
    base_salary = Column(Float, default=0.0, comment="Mức lương cơ bản áp dụng")
    day_rate = Column(Float, default=0.0, comment="Đơn giá 1 ngày công (base_salary / standard_days)")
    hour_rate = Column(Float, default=0.0, comment="Đơn giá 1 giờ công (day_rate / 8.0)")

    # Các khoản thu nhập
    salary_by_work_days = Column(Float, default=0.0, comment="Tiền lương ngày công thực nhận")
    salary_ot_normal = Column(Float, default=0.0, comment="Tiền tăng ca thường (1.5x)")
    salary_ot_sunday = Column(Float, default=0.0, comment="Tiền tăng ca chủ nhật (2.0x)")
    salary_ot_holiday = Column(Float, default=0.0, comment="Tiền tăng ca lễ tết (3.0x)")
    salary_night_bonus = Column(Float, default=0.0, comment="Phụ cấp làm thêm ca đêm (30%)")
    total_ot_salary = Column(Float, default=0.0, comment="Tổng tiền tăng ca và ca đêm")

    # Phụ cấp chi tiết
    allowance_diligence = Column(Float, default=0.0)
    allowance_meal = Column(Float, default=0.0)
    allowance_transport = Column(Float, default=0.0)
    allowance_hazardous = Column(Float, default=0.0)
    allowance_position = Column(Float, default=0.0)
    total_allowance = Column(Float, default=0.0, comment="Tổng phụ cấp")

    # Tổng thu nhập trước giảm trừ (Gross)
    gross_salary = Column(Float, default=0.0, comment="Tổng thu nhập = Lương công + Tổng OT + Tổng phụ cấp")

    # Các khoản giảm trừ
    advance_amount = Column(Float, default=0.0, comment="Tạm ứng tiền lương trong tháng")
    insurance_deduction = Column(Float, default=0.0, comment="Trừ BHXH bắt buộc cá nhân (10.5%)")
    other_deduction = Column(Float, default=0.0, comment="Khấu trừ khác / vi phạm nếu có")
    total_deductions = Column(Float, default=0.0, comment="Tổng các khoản giảm trừ")

    # Lương thực lĩnh (Net Take-home Pay)
    net_salary = Column(Float, default=0.0, comment="LƯƠNG THỰC LĨNH = Gross - Total Deductions")

    notes = Column(String(255), nullable=True, comment="Ghi chú kế toán")
    status = Column(String(20), default="CALCULATED", comment="DRAFT, CALCULATED, CONFIRMED, PAID")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Quan hệ
    employee = relationship("Employee", backref="payroll_records")
