import os
import sys
import uuid
import json
import zlib
import hmac
import base64
import hashlib
import winreg
from datetime import datetime, date, timedelta
from typing import Dict, Any, Optional

MASTER_SECRET = "KTS-ENTERPRISE-FACTORY-SECURE-KEY-2026-HUYNHANH-KORNBEST-AI"
LICENSE_FILE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "license.lic"))
TRIAL_FILE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", ".trial_info"))

class LicenseService:
    """
    Dịch vụ bảo mật bản quyền phần mềm (Hardware-Locked License Key System).
    Khóa bản quyền theo mã phần cứng máy tính (Machine ID) của khách hàng.
    """

    @staticmethod
    def get_machine_id() -> str:
        """
        Tạo mã định danh phần cứng máy tính (Machine ID) duy nhất và ổn định trên Windows.
        Kết hợp Windows Cryptography MachineGuid + MAC Address + Computer Name.
        """
        guid = "DEFAULT-WINDOWS-MACHINE-GUID"
        if sys.platform == "win32":
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
                guid = winreg.QueryValueEx(key, "MachineGuid")[0]
                winreg.CloseKey(key)
            except Exception:
                pass

        try:
            mac = hex(uuid.getnode())
        except Exception:
            mac = "0x000000000000"

        comp_name = os.getenv("COMPUTERNAME", "PC")
        raw = f"{guid}:{mac}:{comp_name}"
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
        return f"KTS-{h[:4]}-{h[4:8]}-{h[8:12]}-{h[12:16]}"

    @classmethod
    def generate_license_key(
        cls,
        customer_name: str,
        machine_id: str,
        expire_date: Optional[str] = "PERPETUAL",
        max_employees: int = 0,
        max_devices: int = 0,
        edition: str = "Enterprise Edition"
    ) -> str:
        """
        Tạo mã bản quyền (Dành riêng cho tác giả / nhà phân phối).
        """
        payload = {
            "customer": customer_name.strip(),
            "machine_id": machine_id.strip().upper(),
            "issue_date": date.today().isoformat(),
            "expire_date": expire_date.strip().upper() if expire_date else "PERPETUAL",
            "max_employees": max_employees,
            "max_devices": max_devices,
            "edition": edition,
            "salt": uuid.uuid4().hex[:8]
        }

        # Nén JSON và Base64
        payload_bytes = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        compressed = zlib.compress(payload_bytes, level=9)
        payload_b64 = base64.urlsafe_b64encode(compressed).decode("utf-8").rstrip("=")

        # Ký HMAC-SHA256
        sig = hmac.new(MASTER_SECRET.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()
        
        # Định dạng key thương mại: KTS-LIC.<payload_b64>.<sig[:32]>
        return f"KTS-LIC.{payload_b64}.{sig[:32]}"

    @classmethod
    def verify_license_string(cls, license_key: str, current_machine_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Xác thực tính hợp lệ của chuỗi License Key.
        """
        if not license_key or not isinstance(license_key, str):
            return {"valid": False, "message": "Mã bản quyền rỗng hoặc không hợp lệ"}

        key_clean = license_key.strip()
        parts = key_clean.split(".")
        if len(parts) != 3 or parts[0] != "KTS-LIC":
            return {"valid": False, "message": "Định dạng mã bản quyền không đúng (phải bắt đầu bằng KTS-LIC)"}

        payload_b64, provided_sig = parts[1], parts[2]

        # Kiểm tra chữ ký HMAC
        expected_sig = hmac.new(MASTER_SECRET.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()[:32]
        if not hmac.compare_digest(provided_sig, expected_sig):
            return {"valid": False, "message": "Chữ ký mã bản quyền không hợp lệ hoặc đã bị chỉnh sửa!"}

        # Giải mã dữ liệu
        try:
            rem = len(payload_b64) % 4
            if rem > 0:
                payload_b64 += "=" * (4 - rem)
            decompressed = zlib.decompress(base64.urlsafe_b64decode(payload_b64.encode("utf-8")))
            payload = json.loads(decompressed.decode("utf-8"))
        except Exception as e:
            return {"valid": False, "message": f"Không thể giải mã dữ liệu bản quyền: {e}"}

        # Kiểm tra Machine ID
        machine_in_key = payload.get("machine_id", "").upper()
        if not current_machine_id:
            current_machine_id = cls.get_machine_id()

        # Cho phép Master Key dành cho nhà phát triển demo
        is_master = (machine_in_key == "DEVELOPER-MASTER-ALL-MACHINES" or machine_in_key == "*")
        if not is_master and machine_in_key != current_machine_id.upper():
            return {
                "valid": False,
                "message": f"Mã bản quyền này cấp cho máy {machine_in_key}, không khớp với máy hiện tại ({current_machine_id})!",
                "payload": payload
            }

        # Kiểm tra hạn sử dụng
        expire_str = payload.get("expire_date", "PERPETUAL").upper()
        today = date.today()
        is_perpetual = (expire_str == "PERPETUAL" or expire_str == "VINH_VIEN")
        days_left = 99999

        if not is_perpetual:
            try:
                exp_date = datetime.strptime(expire_str, "%Y-%m-%d").date()
                days_left = (exp_date - today).days
                if days_left < 0:
                    return {
                        "valid": False,
                        "status": "EXPIRED",
                        "message": f"Bản quyền đã hết hạn vào ngày {exp_date.strftime('%d/%m/%Y')}. Vui lòng gia hạn!",
                        "payload": payload,
                        "days_remaining": days_left
                    }
            except Exception:
                return {"valid": False, "message": f"Định dạng ngày hết hạn {expire_str} không hợp lệ"}

        return {
            "valid": True,
            "status": "ACTIVE",
            "message": "Bản quyền hợp lệ",
            "customer": payload.get("customer"),
            "machine_id": machine_in_key,
            "edition": payload.get("edition", "Enterprise Edition"),
            "is_perpetual": is_perpetual,
            "expire_date": "Vĩnh viễn" if is_perpetual else expire_str,
            "days_remaining": days_left,
            "payload": payload
        }

    @classmethod
    def get_license_status(cls) -> Dict[str, Any]:
        """
        Kiểm tra trạng thái bản quyền hiện tại của hệ thống.
        Ưu tiên: License Key chính thức -> Nếu chưa có: Tính toán Dùng thử 30 ngày (Trial).
        """
        machine_id = cls.get_machine_id()

        # 1. Kiểm tra file license chính thức
        if os.path.exists(LICENSE_FILE_PATH):
            try:
                with open(LICENSE_FILE_PATH, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                res = cls.verify_license_string(content, machine_id)
                if res.get("valid"):
                    return {
                        "is_activated": True,
                        "is_trial": False,
                        "status": "ACTIVE",
                        "status_badge": "BẢN QUYỀN CHÍNH THỨC",
                        "customer": res.get("customer"),
                        "machine_id": machine_id,
                        "edition": res.get("edition"),
                        "is_perpetual": res.get("is_perpetual"),
                        "expire_date": res.get("expire_date"),
                        "days_remaining": res.get("days_remaining"),
                        "message": f"Bản quyền kích hoạt thành công cho {res.get('customer')} ({res.get('expire_date')})"
                    }
                else:
                    return {
                        "is_activated": False,
                        "is_trial": False,
                        "status": res.get("status", "INVALID"),
                        "status_badge": "BẢN QUYỀN HẾT HẠN HOẶC KHÔNG HỢP LỆ",
                        "customer": res.get("customer", "Chưa kích hoạt"),
                        "machine_id": machine_id,
                        "days_remaining": res.get("days_remaining", 0),
                        "message": res.get("message")
                    }
            except Exception as e:
                pass

        # 2. Quản lý dùng thử (30 ngày Trial)
        os.makedirs(os.path.dirname(TRIAL_FILE_PATH), exist_ok=True)
        trial_start = None
        if os.path.exists(TRIAL_FILE_PATH):
            try:
                with open(TRIAL_FILE_PATH, "r", encoding="utf-8") as f:
                    trial_start = datetime.strptime(f.read().strip(), "%Y-%m-%d").date()
            except Exception:
                pass

        if not trial_start:
            trial_start = date.today()
            try:
                with open(TRIAL_FILE_PATH, "w", encoding="utf-8") as f:
                    f.write(trial_start.isoformat())
            except Exception:
                pass

        TRIAL_DAYS = 30
        trial_end = trial_start + timedelta(days=TRIAL_DAYS)
        days_left = (trial_end - date.today()).days

        if days_left >= 0:
            return {
                "is_activated": False,
                "is_trial": True,
                "status": "TRIAL",
                "status_badge": f"DÙNG THỬ (CÒN {days_left} NGÀY)",
                "customer": "Bản Dùng Thử Trải Nghiệm",
                "machine_id": machine_id,
                "edition": "Enterprise Trial",
                "is_perpetual": False,
                "expire_date": trial_end.strftime("%d/%m/%Y"),
                "days_remaining": days_left,
                "message": f"Bạn đang sử dụng phiên bản dùng thử thương mại. Còn lại {days_left} ngày trải nghiệm."
            }
        else:
            return {
                "is_activated": False,
                "is_trial": True,
                "status": "EXPIRED",
                "status_badge": "HẾT HẠN DÙNG THỬ",
                "customer": "Hết hạn dùng thử",
                "machine_id": machine_id,
                "edition": "Enterprise Trial",
                "is_perpetual": False,
                "expire_date": trial_end.strftime("%d/%m/%Y"),
                "days_remaining": 0,
                "message": "Thời hạn 30 ngày dùng thử đã kết thúc. Vui lòng kích hoạt bản quyền để tiếp tục sử dụng!"
            }

    @classmethod
    def activate_key(cls, license_key: str) -> Dict[str, Any]:
        """
        Kích hoạt mã bản quyền và lưu vào file license.lic.
        """
        machine_id = cls.get_machine_id()
        res = cls.verify_license_string(license_key, machine_id)
        if not res.get("valid"):
            return {
                "success": False,
                "message": res.get("message", "Mã kích hoạt không hợp lệ")
            }

        os.makedirs(os.path.dirname(LICENSE_FILE_PATH), exist_ok=True)
        with open(LICENSE_FILE_PATH, "w", encoding="utf-8") as f:
            f.write(license_key.strip())

        return {
            "success": True,
            "message": f"Kích hoạt thành công cho {res.get('customer')}!",
            "details": res
        }
