import io
import calendar
from datetime import date, datetime
from typing import Optional, List, Dict
from sqlalchemy.orm import Session
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from backend.app.models.employee import Employee
from backend.app.models.daily_attendance import DailyAttendance
from backend.app.models.holiday import Holiday
from backend.app.models.payroll import SalaryConfig, PayrollRecord
from backend.app.models.settings import SystemSetting

class PayrollService:
    """
    Dịch vụ tính lương tự động và xuất báo cáo bảng lương chuẩn Doanh Nghiệp Việt Nam.
    """

    @staticmethod
    def _build_default_salary_config(employee: Employee) -> SalaryConfig:
        pos_lower = (employee.position or "").lower()
        dept_lower = (employee.department or "").lower()
        
        if any(k in pos_lower for k in ["giám đốc", "chủ tịch", "tổng giám đốc", "manager"]):
            base = 18000000.0
            pos_allowance = 3000000.0
        elif any(k in pos_lower for k in ["trưởng phòng", "quản đốc", "chuyên gia"]):
            base = 12000000.0
            pos_allowance = 1500000.0
        elif any(k in pos_lower for k in ["tổ trưởng", "phó phòng", "kế toán"]):
            base = 8500000.0
            pos_allowance = 800000.0
        else:
            base = 6500000.0
            pos_allowance = 0.0

        hazardous = 300000.0 if any(k in dept_lower for k in ["xẻ", "cưa", "bào", "sấy", "lò hơi", "chỉnh lý"]) else 150000.0

        return SalaryConfig(
            employee_id=employee.id,
            base_salary=base,
            allowance_diligence=300000.0,
            allowance_meal=650000.0,
            allowance_transport=300000.0,
            allowance_hazardous=hazardous,
            allowance_position=pos_allowance,
            insurance_rate=10.5
        )

    @classmethod
    def get_or_create_salary_config(cls, db: Session, employee: Employee) -> SalaryConfig:
        """
        Lấy hoặc khởi tạo cấu hình mức lương theo chức vụ/bộ phận nhân viên.
        """
        cfg = db.query(SalaryConfig).filter(SalaryConfig.employee_id == employee.id).first()
        if not cfg:
            cfg = cls._build_default_salary_config(employee)
            db.add(cfg)
            db.commit()
            db.refresh(cfg)
        return cfg

    @classmethod
    def calculate_monthly_payroll(
        cls,
        db: Session,
        year: int,
        month: int,
        department: Optional[str] = None
    ) -> List[PayrollRecord]:
        """
        Tự động tính toán bảng lương tháng cho toàn bộ nhân viên hoặc theo bộ phận:
        1. Quét dữ liệu DailyAttendance để bóc tách ngày công và giờ OT theo loại (1.5x, 2.0x, 3.0x).
        2. Bóc tách số ngày lễ hưởng lương và ngày nghỉ phép có lương (P, VR, CT).
        3. Áp dụng mức lương và phụ cấp theo cấu hình SalaryConfig.
        4. Tính giảm trừ BHXH (10.5%) và tạm ứng để ra Lương Thực Lĩnh (Net).
        """
        num_days = calendar.monthrange(year, month)[1]
        start_date = date(year, month, 1)
        end_date = date(year, month, num_days)

        emp_query = db.query(Employee).filter(Employee.is_active == True)
        if department and department != "Tất cả":
            emp_query = emp_query.filter(Employee.department == department)
        employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

        emp_ids = [e.id for e in employees]

        # Kéo toàn bộ DailyAttendance của tháng
        attendances = db.query(DailyAttendance).filter(
            DailyAttendance.employee_id.in_(emp_ids),
            DailyAttendance.attendance_date >= start_date,
            DailyAttendance.attendance_date <= end_date
        ).all()

        att_by_emp: Dict[int, List[DailyAttendance]] = {}
        for att in attendances:
            att_by_emp.setdefault(att.employee_id, []).append(att)

        # Lấy danh sách ngày Lễ trong tháng để phân loại OT 3.0x
        holidays = db.query(Holiday).filter(
            Holiday.start_date <= end_date,
            Holiday.end_date >= start_date
        ).all()
        holiday_dates = set()
        for h in holidays:
            curr = max(h.start_date, start_date)
            h_end = min(h.end_date, end_date)
            while curr <= h_end:
                holiday_dates.add(curr)
                curr = curr.fromordinal(curr.toordinal() + 1)

        # Lấy các bản ghi PayrollRecord hiện có (nếu đã có tạm ứng / ghi chú thủ công thì giữ nguyên)
        existing_records = db.query(PayrollRecord).filter(
            PayrollRecord.employee_id.in_(emp_ids),
            PayrollRecord.year == year,
            PayrollRecord.month == month
        ).all()
        record_by_emp = {r.employee_id: r for r in existing_records}

        # Nạp trước toàn bộ cấu hình lương theo nhân viên trong 1 query duy nhất
        existing_configs = db.query(SalaryConfig).filter(SalaryConfig.employee_id.in_(emp_ids)).all()
        config_by_emp = {c.employee_id: c for c in existing_configs}

        # Tạo hàng loạt nếu nhân viên nào chưa có
        new_configs = []
        for emp in employees:
            if emp.id not in config_by_emp:
                cfg = cls._build_default_salary_config(emp)
                new_configs.append(cfg)
                config_by_emp[emp.id] = cfg
        if new_configs:
            db.add_all(new_configs)
            db.commit()

        calculated_records = []

        for emp in employees:
            cfg = config_by_emp.get(emp.id) or cls._build_default_salary_config(emp)
            emp_atts = att_by_emp.get(emp.id, [])

            actual_work_days = 0.0
            paid_leave_days = 0.0
            holiday_days = 0.0
            ot_normal_hours = 0.0
            ot_sunday_hours = 0.0
            ot_holiday_hours = 0.0
            night_shift_hours = 0.0

            for att in emp_atts:
                # 1. Phân loại ngày công
                if att.status == "HOLIDAY":
                    holiday_days += (att.work_units or 1.0)
                elif att.leave_type in ["ANNUAL", "MARRIAGE", "BUSINESS_TRIP"]:
                    paid_leave_days += (att.work_units or 1.0)
                else:
                    actual_work_days += (att.work_units or 0.0)

                # 2. Phân loại giờ tăng ca (OT) đã được calculation_engine bóc tách chính xác
                ot_normal_hours += (att.ot_15_hours or 0.0)
                ot_sunday_hours += (att.ot_20_hours or 0.0)
                ot_holiday_hours += (att.ot_30_hours or 0.0)

                # Ca đêm (nếu ca là CA_DEM hoặc giờ làm ban đêm)
                if att.shift and "dem" in (att.shift.name or "").lower():
                    night_shift_hours += 8.0

            standard_days = 26.0
            total_paid_days = actual_work_days + paid_leave_days + holiday_days

            # Đơn giá ngày công & giờ
            day_rate = cfg.base_salary / standard_days
            hour_rate = day_rate / 8.0

            salary_by_work_days = round(day_rate * total_paid_days, 0)
            salary_ot_normal = round(hour_rate * 1.5 * ot_normal_hours, 0)
            salary_ot_sunday = round(hour_rate * 2.0 * ot_sunday_hours, 0)
            salary_ot_holiday = round(hour_rate * 3.0 * ot_holiday_hours, 0)
            salary_night_bonus = round(hour_rate * 0.3 * night_shift_hours, 0)
            total_ot_salary = salary_ot_normal + salary_ot_sunday + salary_ot_holiday + salary_night_bonus

            # Phụ cấp chuyên cần: Đạt từ 24 ngày công trở lên hưởng 100%
            diligence = cfg.allowance_diligence if (actual_work_days + paid_leave_days + holiday_days) >= 24.0 else 0.0
            # Phụ cấp cơm trưa theo số ngày thực tế đi làm
            meal = round(cfg.allowance_meal * (actual_work_days / standard_days), 0) if standard_days > 0 else 0.0
            transport = cfg.allowance_transport
            hazardous = cfg.allowance_hazardous
            position = cfg.allowance_position
            total_allowance = diligence + meal + transport + hazardous + position

            gross_salary = salary_by_work_days + total_ot_salary + total_allowance

            # Giảm trừ
            insurance_deduction = round(cfg.base_salary * (cfg.insurance_rate / 100.0), 0)

            # Lấy tạm ứng cũ nếu có
            existing = record_by_emp.get(emp.id)
            advance_amount = existing.advance_amount if existing else 0.0
            other_deduction = existing.other_deduction if existing else 0.0
            notes = existing.notes if existing else None

            total_deductions = advance_amount + insurance_deduction + other_deduction
            net_salary = max(0.0, round(gross_salary - total_deductions, 0))

            if existing:
                rec = existing
                rec.standard_days = standard_days
                rec.actual_work_days = round(actual_work_days, 1)
                rec.paid_leave_days = round(paid_leave_days, 1)
                rec.holiday_days = round(holiday_days, 1)
                rec.total_paid_days = round(total_paid_days, 1)
                rec.ot_normal_hours = round(ot_normal_hours, 1)
                rec.ot_sunday_hours = round(ot_sunday_hours, 1)
                rec.ot_holiday_hours = round(ot_holiday_hours, 1)
                rec.night_shift_hours = round(night_shift_hours, 1)
                rec.base_salary = cfg.base_salary
                rec.day_rate = round(day_rate, 0)
                rec.hour_rate = round(hour_rate, 0)
                rec.salary_by_work_days = salary_by_work_days
                rec.salary_ot_normal = salary_ot_normal
                rec.salary_ot_sunday = salary_ot_sunday
                rec.salary_ot_holiday = salary_ot_holiday
                rec.salary_night_bonus = salary_night_bonus
                rec.total_ot_salary = total_ot_salary
                rec.allowance_diligence = diligence
                rec.allowance_meal = meal
                rec.allowance_transport = transport
                rec.allowance_hazardous = hazardous
                rec.allowance_position = position
                rec.total_allowance = total_allowance
                rec.gross_salary = gross_salary
                rec.insurance_deduction = insurance_deduction
                rec.total_deductions = total_deductions
                rec.net_salary = net_salary
                rec.updated_at = datetime.utcnow()
            else:
                rec = PayrollRecord(
                    employee_id=emp.id,
                    year=year,
                    month=month,
                    standard_days=standard_days,
                    actual_work_days=round(actual_work_days, 1),
                    paid_leave_days=round(paid_leave_days, 1),
                    holiday_days=round(holiday_days, 1),
                    total_paid_days=round(total_paid_days, 1),
                    ot_normal_hours=round(ot_normal_hours, 1),
                    ot_sunday_hours=round(ot_sunday_hours, 1),
                    ot_holiday_hours=round(ot_holiday_hours, 1),
                    night_shift_hours=round(night_shift_hours, 1),
                    base_salary=cfg.base_salary,
                    day_rate=round(day_rate, 0),
                    hour_rate=round(hour_rate, 0),
                    salary_by_work_days=salary_by_work_days,
                    salary_ot_normal=salary_ot_normal,
                    salary_ot_sunday=salary_ot_sunday,
                    salary_ot_holiday=salary_ot_holiday,
                    salary_night_bonus=salary_night_bonus,
                    total_ot_salary=total_ot_salary,
                    allowance_diligence=diligence,
                    allowance_meal=meal,
                    allowance_transport=transport,
                    allowance_hazardous=hazardous,
                    allowance_position=position,
                    total_allowance=total_allowance,
                    gross_salary=gross_salary,
                    advance_amount=advance_amount,
                    insurance_deduction=insurance_deduction,
                    other_deduction=other_deduction,
                    total_deductions=total_deductions,
                    net_salary=net_salary,
                    notes=notes,
                    status="CALCULATED"
                )
                db.add(rec)
            calculated_records.append(rec)

        db.commit()
        for r in calculated_records:
            db.refresh(r)

        return calculated_records

    @classmethod
    def export_payroll_excel(
        cls,
        db: Session,
        year: int,
        month: int,
        department: Optional[str] = None
    ) -> io.BytesIO:
        """
        Tạo file Excel Bảng Thanh Toán Tiền Lương định dạng chuẩn Bộ Lao Động & Kế toán Doanh Nghiệp.
        """
        # Nếu chưa có bản ghi thì tính toán trước
        records = db.query(PayrollRecord).join(Employee).filter(
            PayrollRecord.year == year,
            PayrollRecord.month == month
        )
        if department and department != "Tất cả":
            records = records.filter(Employee.department == department)
        payroll_list = records.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

        if not payroll_list:
            payroll_list = cls.calculate_monthly_payroll(db, year, month, department)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"Luong_Thang_{month}_{year}"
        ws.views.sheetView[0].showGridLines = True

        # Styles
        font_title = Font(name="Times New Roman", size=16, bold=True, color="1E3A8A")
        font_sub = Font(name="Times New Roman", size=11, italic=True)
        font_header = Font(name="Times New Roman", size=10, bold=True, color="FFFFFF")
        font_group = Font(name="Times New Roman", size=10, bold=True, color="FFFFFF")
        font_data = Font(name="Times New Roman", size=10)
        font_bold = Font(name="Times New Roman", size=10, bold=True)
        font_net = Font(name="Times New Roman", size=11, bold=True, color="B91C1C")

        fill_header = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        fill_sub_header = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
        fill_zebra = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
        fill_net = PatternFill(start_color="FEF2F2", end_color="FEF2F2", fill_type="solid")
        fill_total = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")

        thin = Side(border_style="thin", color="CBD5E1")
        border_cell = Border(left=thin, right=thin, top=thin, bottom=thin)

        # Title Block
        comp_setting = db.query(SystemSetting).filter(SystemSetting.id == 1).first()
        company_name = comp_setting.company_name if comp_setting and comp_setting.company_name else "DOANH NGHIỆP CỦA BẠN"

        ws.merge_cells("A1:V1")
        ws["A1"] = company_name.upper()
        ws["A1"].font = Font(name="Times New Roman", size=12, bold=True, color="0F172A")
        ws["A1"].alignment = Alignment(horizontal="left")

        ws.merge_cells("A2:V2")
        dept_text = f" - BỘ PHẬN: {department.upper()}" if (department and department != "Tất cả") else " - TOÀN CÔNG TY"
        ws["A2"] = f"BẢNG THANH TOÁN TIỀN LƯƠNG & LÀM THÊM GIỜ{dept_text}"
        ws["A2"].font = font_title
        ws["A2"].alignment = Alignment(horizontal="center")

        ws.merge_cells("A3:V3")
        ws["A3"] = f"Tháng {month:02d} năm {year} | Đơn vị tính: Việt Nam Đồng (VND)"
        ws["A3"].font = font_sub
        ws["A3"].alignment = Alignment(horizontal="center")

        # Row 5 & 6: Two-level Header
        # Level 1 Groups:
        # A5:E5: THÔNG TIN NHÂN SỰ
        # F5:J5: NGÀY CÔNG & LƯƠNG CÔNG
        # K5:N5: TĂNG CA (LÀM THÊM GIỜ)
        # O5:R5: PHỤ CẤP
        # S5: TỔNG THU NHẬP
        # T5:V5: CÁC KHOẢN GIẢM TRỪ
        # W5: THỰC LĨNH
        # X5: KÝ NHẬN
        groups = [
            ("A5:E5", "THÔNG TIN NHÂN SỰ", "1E3A8A"),
            ("F5:J5", "NGÀY CÔNG & LƯƠNG CÔNG", "1E40AF"),
            ("K5:N5", "LÀM THÊM GIỜ (TĂNG CA)", "1D4ED8"),
            ("O5:R5", "CÁC KHOẢN PHỤ CẤP", "2563EB"),
            ("S5:S6", "TỔNG THU NHẬP\n(GROSS)", "047857"),
            ("T5:V5", "CÁC KHOẢN GIẢM TRỪ", "B91C1C"),
            ("W5:W6", "LƯƠNG THỰC LĨNH\n(NET)", "DC2626"),
            ("X5:X6", "KÝ NHẬN", "475569")
        ]

        for rng, txt, bg_color in groups:
            ws.merge_cells(rng)
            top_left = rng.split(":")[0]
            ws[top_left] = txt
            fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")
            for row in ws[rng]:
                for cell in row:
                    cell.fill = fill
                    cell.font = font_group
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                    cell.border = border_cell

        # Level 2 Sub-headers
        sub_headers = [
            ("A6", "STT"),
            ("B6", "Mã NV"),
            ("C6", "Họ và Tên"),
            ("D6", "Chức Vụ"),
            ("E6", "Bộ Phận"),
            ("F6", "Lương CB"),
            ("G6", "Công TT"),
            ("H6", "Lễ/Phép"),
            ("I6", "Tổng Công"),
            ("J6", "Tiền Công"),
            ("K6", "OT 1.5x (h)"),
            ("L6", "OT CN 2.0x (h)"),
            ("M6", "OT Lễ 3.0x (h)"),
            ("N6", "Tiền OT"),
            ("O6", "Chuyên Cần"),
            ("P6", "Cơm Trưa"),
            ("Q6", "Xăng & Độc Hại"),
            ("R6", "Tổng Phụ Cấp"),
            ("T6", "Tạm Ứng"),
            ("U6", "BHXH (10.5%)"),
            ("V6", "Tổng Trừ")
        ]

        for col, title in sub_headers:
            ws[col] = title
            ws[col].fill = fill_sub_header
            ws[col].font = font_header
            ws[col].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws[col].border = border_cell

        # Data Rows
        current_row = 7
        stt = 1
        for rec in payroll_list:
            emp = rec.employee
            is_zebra = (stt % 2 == 0)
            row_fill = fill_zebra if is_zebra else None

            ws.cell(row=current_row, column=1, value=stt).alignment = Alignment(horizontal="center")
            ws.cell(row=current_row, column=2, value=emp.employee_code if emp else "").alignment = Alignment(horizontal="center")
            ws.cell(row=current_row, column=3, value=emp.full_name if emp else "").alignment = Alignment(horizontal="left")
            ws.cell(row=current_row, column=4, value=emp.position or "-").alignment = Alignment(horizontal="left")
            ws.cell(row=current_row, column=5, value=emp.department or "-").alignment = Alignment(horizontal="left")

            # Mức lương & công
            ws.cell(row=current_row, column=6, value=rec.base_salary).number_format = "#,##0"
            ws.cell(row=current_row, column=7, value=rec.actual_work_days).number_format = "0.0"
            ws.cell(row=current_row, column=8, value=(rec.paid_leave_days + rec.holiday_days)).number_format = "0.0"
            ws.cell(row=current_row, column=9, value=rec.total_paid_days).number_format = "0.0"
            ws.cell(row=current_row, column=10, value=rec.salary_by_work_days).number_format = "#,##0"

            # OT
            ws.cell(row=current_row, column=11, value=rec.ot_normal_hours).number_format = "0.0"
            ws.cell(row=current_row, column=12, value=rec.ot_sunday_hours).number_format = "0.0"
            ws.cell(row=current_row, column=13, value=rec.ot_holiday_hours).number_format = "0.0"
            ws.cell(row=current_row, column=14, value=rec.total_ot_salary).number_format = "#,##0"

            # Phụ cấp
            ws.cell(row=current_row, column=15, value=rec.allowance_diligence).number_format = "#,##0"
            ws.cell(row=current_row, column=16, value=rec.allowance_meal).number_format = "#,##0"
            ws.cell(row=current_row, column=17, value=(rec.allowance_transport + rec.allowance_hazardous)).number_format = "#,##0"
            ws.cell(row=current_row, column=18, value=rec.total_allowance).number_format = "#,##0"

            # Tổng thu nhập Gross
            ws.cell(row=current_row, column=19, value=rec.gross_salary).number_format = "#,##0"

            # Giảm trừ
            ws.cell(row=current_row, column=20, value=rec.advance_amount).number_format = "#,##0"
            ws.cell(row=current_row, column=21, value=rec.insurance_deduction).number_format = "#,##0"
            ws.cell(row=current_row, column=22, value=rec.total_deductions).number_format = "#,##0"

            # Thực lĩnh Net
            cell_net = ws.cell(row=current_row, column=23, value=rec.net_salary)
            cell_net.number_format = "#,##0"
            cell_net.font = font_net
            cell_net.fill = fill_net

            # Ký nhận
            ws.cell(row=current_row, column=24, value="")

            # Styling Borders and fills
            for col_idx in range(1, 25):
                c = ws.cell(row=current_row, column=col_idx)
                c.border = border_cell
                if col_idx not in [2, 3, 4, 5, 23] and row_fill:
                    c.fill = row_fill
                if col_idx in [1, 2, 7, 8, 9, 11, 12, 13]:
                    c.alignment = Alignment(horizontal="center", vertical="center")
                elif col_idx in [6, 10, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]:
                    c.alignment = Alignment(horizontal="right", vertical="center")

            current_row += 1
            stt += 1

        # Summary Row (TỔNG CỘNG)
        ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=5)
        ws.cell(row=current_row, column=1, value="TỔNG CỘNG").alignment = Alignment(horizontal="center")
        ws.cell(row=current_row, column=1).font = font_bold

        sum_cols = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
        for col_idx in sum_cols:
            col_letter = get_column_letter(col_idx)
            cell = ws.cell(row=current_row, column=col_idx, value=f"=SUM({col_letter}7:{col_letter}{current_row-1})")
            cell.font = font_bold
            cell.alignment = Alignment(horizontal="right" if col_idx not in [7, 8, 9, 11, 12, 13] else "center")
            cell.number_format = "0.0" if col_idx in [7, 8, 9, 11, 12, 13] else "#,##0"

        for col_idx in range(1, 25):
            c = ws.cell(row=current_row, column=col_idx)
            c.border = border_cell
            c.fill = fill_total

        # Footer Signatures
        sig_row = current_row + 3
        ws.cell(row=sig_row, column=3, value="NGƯỜI LẬP BIỂU").font = font_bold
        ws.cell(row=sig_row, column=3).alignment = Alignment(horizontal="center")
        ws.cell(row=sig_row+1, column=3, value="(Ký, ghi rõ họ tên)").font = font_sub
        ws.cell(row=sig_row+1, column=3).alignment = Alignment(horizontal="center")

        ws.cell(row=sig_row, column=10, value="KẾ TOÁN TRƯỞNG").font = font_bold
        ws.cell(row=sig_row, column=10).alignment = Alignment(horizontal="center")
        ws.cell(row=sig_row+1, column=10, value="(Ký, ghi rõ họ tên)").font = font_sub
        ws.cell(row=sig_row+1, column=10).alignment = Alignment(horizontal="center")

        ws.cell(row=sig_row, column=19, value="GIÁM ĐỐC DUYỆT").font = font_bold
        ws.cell(row=sig_row, column=19).alignment = Alignment(horizontal="center")
        ws.cell(row=sig_row+1, column=19, value="(Ký, đóng dấu)").font = font_sub
        ws.cell(row=sig_row+1, column=19).alignment = Alignment(horizontal="center")

        # Auto Column Widths
        col_widths = {
            1: 6,   # STT
            2: 12,  # Mã NV
            3: 24,  # Họ và Tên
            4: 16,  # Chức vụ
            5: 18,  # Bộ phận
            6: 14,  # Lương CB
            7: 9,   # Công TT
            8: 9,   # Lễ/Phép
            9: 10,  # Tổng công
            10: 15, # Tiền công
            11: 10, # OT 1.5x
            12: 10, # OT 2.0x
            13: 10, # OT 3.0x
            14: 14, # Tiền OT
            15: 12, # Chuyên cần
            16: 12, # Cơm trưa
            17: 14, # Xăng xe & độc hại
            18: 14, # Tổng phụ cấp
            19: 16, # Gross
            20: 12, # Tạm ứng
            21: 14, # BHXH
            22: 14, # Tổng trừ
            23: 18, # Net Pay
            24: 15  # Ký nhận
        }
        for col_idx, width in col_widths.items():
            col_letter = get_column_letter(col_idx)
            ws.column_dimensions[col_letter].width = width

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output
