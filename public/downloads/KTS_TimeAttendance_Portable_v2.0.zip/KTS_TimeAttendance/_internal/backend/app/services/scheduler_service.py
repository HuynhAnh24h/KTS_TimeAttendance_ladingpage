import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any

from backend.app.core.database import SessionLocal
from backend.app.models.device import Device
from backend.app.services.zk_sync_service import ZkSyncService
from backend.app.services.calculation_engine import AttendanceCalculationEngine

logger = logging.getLogger("auto_sync_scheduler")

class AutoSyncScheduler:
    """
    Dịch vụ quản trị tiến trình chạy ngầm tự động đồng bộ máy chấm công IP
    với phần mềm quản lý chấm công & tính lương.
    """
    _instance = None
    
    def __init__(self):
        self.is_enabled: bool = True
        self.interval_minutes: int = 15  # Mặc định quét định kỳ mỗi 15 phút
        self.is_running: bool = False
        self.last_run_at: Optional[datetime] = None
        self.last_status: str = "Chưa chạy"
        self.last_summary: str = "Hệ thống đang sẵn sàng tự động đồng bộ định kỳ"
        self._task: Optional[asyncio.Task] = None

    @classmethod
    def get_instance(cls) -> "AutoSyncScheduler":
        if cls._instance is None:
            cls._instance = AutoSyncScheduler()
        return cls._instance

    def get_status(self) -> Dict[str, Any]:
        return {
            "enabled": self.is_enabled,
            "interval_minutes": self.interval_minutes,
            "is_running": self.is_running,
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "last_status": self.last_status,
            "last_summary": self.last_summary,
        }

    def update_config(self, enabled: Optional[bool] = None, interval_minutes: Optional[int] = None):
        if enabled is not None:
            self.is_enabled = enabled
        if interval_minutes is not None and interval_minutes >= 1:
            self.interval_minutes = interval_minutes
        logger.info(f"Đã cập nhật cấu hình Tự động đồng bộ: enabled={self.is_enabled}, interval={self.interval_minutes}m")
        return self.get_status()

    def start(self):
        """Khởi động worker chạy ngầm trong event loop của FastAPI."""
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._worker_loop())
            logger.info(f"Đã kích hoạt Background Auto-Sync Worker (Chu kỳ: {self.interval_minutes} phút/lần).")

    def stop(self):
        """Dừng worker chạy ngầm khi tắt server."""
        if self._task and not self._task.done():
            self._task.cancel()
            logger.info("Đã dừng Background Auto-Sync Worker.")

    async def _worker_loop(self):
        # Chờ 10 giây đầu sau khi server khởi động để hệ thống ổn định trước khi quét lần 1
        await asyncio.sleep(10)
        
        while True:
            try:
                if self.is_enabled:
                    logger.info("AutoSync: Bắt đầu chu kỳ đồng bộ máy chấm công ngầm...")
                    await self.trigger_sync_job()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"AutoSync: Lỗi trong tiến trình quét ngầm: {e}", exc_info=True)
                self.last_status = "Lỗi"
                self.last_summary = f"Lỗi quét ngầm: {e}"

            # Ngủ theo chu kỳ phút đã cấu hình
            try:
                sleep_seconds = max(self.interval_minutes * 60, 60)
                await asyncio.sleep(sleep_seconds)
            except asyncio.CancelledError:
                break

    async def trigger_sync_job(self) -> Dict[str, Any]:
        """Thực thi đồng bộ tất cả máy đang active (chạy trong thread pool riêng để không chặn async loop)."""
        if self.is_running:
            return {"message": "Một tác vụ đồng bộ khác đang chạy, bỏ qua chu kỳ này"}

        self.is_running = True
        self.last_status = "Đang đồng bộ..."
        
        try:
            result = await asyncio.to_thread(self._sync_devices_blocking)
            self.last_run_at = datetime.now()
            self.last_status = "Thành công" if result.get("success") else "Có cảnh báo"
            self.last_summary = result.get("summary", "")
            return result
        except Exception as e:
            self.last_run_at = datetime.now()
            self.last_status = "Lỗi"
            self.last_summary = f"Lỗi: {e}"
            return {"success": False, "error": str(e)}
        finally:
            self.is_running = False

    def _sync_devices_blocking(self) -> Dict[str, Any]:
        """Hàm đồng bộ đồng bộ socket ZKTeco qua thread."""
        db = SessionLocal()
        try:
            active_devices = db.query(Device).filter(Device.is_active == True).all()
            if not active_devices:
                return {"success": True, "summary": "Không có máy chấm công nào đang kích hoạt"}

            total_synced = 0
            total_saved = 0
            device_summaries = []
            affected_months = set()

            for dev in active_devices:
                try:
                    synced, saved, err = ZkSyncService.sync_device_logs(
                        db=db,
                        device=dev,
                        simulate_if_offline=False,
                        sync_users=True
                    )
                    total_synced += synced
                    total_saved += saved
                    if err:
                        device_summaries.append(f"{dev.name}: {err}")
                    else:
                        device_summaries.append(f"{dev.name}: +{saved} mới")
                except Exception as ex:
                    device_summaries.append(f"{dev.name}: Lỗi {ex}")

            # Nếu có dữ liệu quẹt thẻ mới, tự động tính toán lại bảng công cho tháng hiện tại
            now = datetime.now()
            if total_saved > 0:
                try:
                    AttendanceCalculationEngine.calculate_month_for_all(db=db, year=now.year, month=now.month)
                    logger.info(f"AutoSync: Đã tự động cập nhật bảng công tháng {now.month}/{now.year} sau khi có {total_saved} log mới.")
                except Exception as e_calc:
                    logger.warning(f"AutoSync: Lỗi khi tự tính lại công tháng: {e_calc}")

            summary_text = f"Đã quét {len(active_devices)} máy: Lưu {total_saved} lượt quẹt mới. ({', '.join(device_summaries)})"
            return {
                "success": True,
                "total_synced": total_synced,
                "total_saved": total_saved,
                "summary": summary_text
            }
        finally:
            db.close()
