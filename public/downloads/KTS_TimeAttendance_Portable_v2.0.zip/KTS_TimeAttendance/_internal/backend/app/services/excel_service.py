import io
import calendar
from datetime import date, datetime
from typing import List, Tuple, Dict, Any, Optional
from sqlalchemy.orm import Session
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from backend.app.models.employee import Employee
from backend.app.models.shift import Shift
from backend.app.models.daily_attendance import DailyAttendance

class ExcelService:
    """
    Module xử lý Xuất và Nhập Excel chuẩn format kế toán - nhân sự Việt Nam.
    Tối ưu hóa hiệu năng cao cho hàng nghìn nhân sự với OpenPyXL.
    - Cố định cột thông tin nhân viên (Freeze Pane).
    - Tô màu trực quan cho từng loại ngày công (Đủ công, Nửa công, Tăng ca, Vắng, Cuối tuần).
    - Công thức Excel tự động: SUM ngày công, SUM giờ OT, COUNT trễ và Dòng TỔNG CỘNG cuối bảng.
    """

    @classmethod
    def export_monthly_timesheet(
        cls,
        db: Session,
        year: int,
        month: int,
        department: Optional[str] = None
    ) -> io.BytesIO:
        """
        Xuất file Excel bảng chấm công tổng hợp tháng dạng Ma Trận.
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"Bang_Cong_T{month}_{year}"
        ws.views.sheetView[0].showGridLines = True

        # Phong cách định dạng chuyên nghiệp chuẩn kế toán
        font_title = Font(name="Segoe UI", size=15, bold=True, color="1E3A8A")
        font_meta = Font(name="Segoe UI", size=9.5, color="475569")
        font_header = Font(name="Segoe UI", size=9.5, bold=True, color="FFFFFF")
        font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
        font_summary = Font(name="Segoe UI", size=9.5, bold=True, color="0F172A")
        font_total_row = Font(name="Segoe UI", size=10, bold=True, color="1E3A8A")

        fill_header_main = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid") # Xanh Navy
        fill_header_weekend = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
        fill_header_sum = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid") # Teal đậm
        fill_weekend = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")    # Xám nhạt
        fill_summary = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
        fill_total_row = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")

        # Màu sắc badge công
        fill_full = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")    # Xanh lá (Đủ công)
        fill_half = PatternFill(start_color="FEF08A", end_color="FEF08A", fill_type="solid")    # Vàng (Nửa công/Trễ)
        fill_ot = PatternFill(start_color="EDE9FE", end_color="EDE9FE", fill_type="solid")      # Tím nhạt (Tăng ca)
        fill_absent = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")  # Đỏ nhạt (Vắng)
        fill_leave = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")   # Xanh dương (Phép P / VR)
        fill_holiday = PatternFill(start_color="F3E8FF", end_color="F3E8FF", fill_type="solid") # Tím hồng nhạt (Lễ L)
        fill_ro = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")      # Xám (Không lương Ro)
        fill_ins = PatternFill(start_color="FFEDD5", end_color="FFEDD5", fill_type="solid")     # Cam nhạt (BHXH Ốm/TS)

        align_center = Alignment(horizontal="center", vertical="center")
        align_left = Alignment(horizontal="left", vertical="center")
        align_right = Alignment(horizontal="right", vertical="center")

        thin_side = Side(style="thin", color="CBD5E1")
        border_all = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
        double_bottom_border = Border(left=thin_side, right=thin_side, top=thin_side, bottom=Side(style="double", color="1E3A8A"))

        num_days = calendar.monthrange(year, month)[1]

        # Khối tiêu đề đầu bảng
        dept_text = f"Bộ phận: {department}" if (department and department != "Tất cả") else "Toàn thể cán bộ công nhân viên"
        ws.merge_cells("A1:G1")
        ws["A1"] = "BẢNG CHẤM CÔNG VÀ TÍNH CÔNG TỔNG HỢP"
        ws["A1"].font = font_title
        ws["A1"].alignment = align_left

        ws.merge_cells("A2:G2")
        ws["A2"] = f"Tháng {month:02d}/{year}  |  {dept_text}  |  Đơn vị tính: Ngày công (1.0 = Đủ công, 0.5 = Nửa công)"
        ws["A2"].font = font_meta
        ws["A2"].alignment = align_left

        ws.merge_cells("A3:G3")
        ws["A3"] = f"Thời điểm kết xuất: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  |  Nguồn dữ liệu: Máy chấm công IP (SpeedFace / ZKTeco)"
        ws["A3"].font = font_meta
        ws["A3"].alignment = align_left

        # Cột cố định thông tin nhân sự
        fixed_headers = [
            ("STT", 6),
            ("Mã NV", 11),
            ("Mã CC (ZK)", 12),
            ("Họ và Tên", 26),
            ("Phòng Ban / Xưởng", 20),
            ("Chức Vụ", 16)
        ]

        row_header_day = 5
        row_header_weekday = 6

        col_idx = 1
        for h_title, w in fixed_headers:
            ws.merge_cells(start_row=row_header_day, start_column=col_idx, end_row=row_header_weekday, end_column=col_idx)
            cell = ws.cell(row=row_header_day, column=col_idx, value=h_title)
            cell.font = font_header
            cell.fill = fill_header_main
            cell.alignment = align_center
            cell.border = border_all
            ws.cell(row=row_header_weekday, column=col_idx).border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = w
            col_idx += 1

        day_start_col = col_idx

        # Header Ngày 1 đến num_days
        for day in range(1, num_days + 1):
            cur_date = date(year, month, day)
            weekday_idx = cur_date.weekday()
            weekday_vn = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"][weekday_idx]
            is_sunday = (weekday_idx == 6)
            is_saturday = (weekday_idx == 5)

            hdr_fill = fill_header_weekend if is_sunday else fill_header_main

            c_day = ws.cell(row=row_header_day, column=col_idx, value=day)
            c_day.font = font_header
            c_day.fill = hdr_fill
            c_day.alignment = align_center
            c_day.border = border_all

            c_wk = ws.cell(row=row_header_weekday, column=col_idx, value=weekday_vn)
            c_wk.font = Font(name="Segoe UI", size=8.5, bold=True, color="FCA5A5" if is_sunday else ("FDE68A" if is_saturday else "FFFFFF"))
            c_wk.fill = hdr_fill
            c_wk.alignment = align_center
            c_wk.border = border_all

            ws.column_dimensions[get_column_letter(col_idx)].width = 5.2
            col_idx += 1

        day_end_col = col_idx - 1

        # Cột tổng hợp cuối bảng chuẩn kế toán Việt Nam
        summary_headers = [
            ("Công Đi Làm", 12),
            ("Phép (P)", 10),
            ("Nghỉ Lễ (L)", 11),
            ("TỔNG CÔNG", 13),
            ("Không Lương (Ro)", 16),
            ("Vắng (V)", 10),
            ("Giờ OT (h)", 11),
            ("Số Lần Trễ", 11),
            ("Ghi Chú", 18)
        ]

        sum_cols_map = {}
        for s_title, w in summary_headers:
            ws.merge_cells(start_row=row_header_day, start_column=col_idx, end_row=row_header_weekday, end_column=col_idx)
            cell = ws.cell(row=row_header_day, column=col_idx, value=s_title)
            cell.font = font_header
            cell.fill = fill_header_sum
            cell.alignment = align_center
            cell.border = border_all
            ws.cell(row=row_header_weekday, column=col_idx).border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = w
            sum_cols_map[s_title] = col_idx
            col_idx += 1

        # Khóa cố định Freeze Panes: Khóa dòng header (1-6) và 4 cột nhân viên bên trái
        # Cuộn ngang từ cột E (dòng 7)
        ws.freeze_panes = "E7"

        # Lấy danh sách nhân viên theo tiêu chí lọc
        emp_query = db.query(Employee).filter(Employee.is_active == True)
        if department and department != "Tất cả":
            emp_query = emp_query.filter(Employee.department == department)
        employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

        # Đọc dữ liệu DailyAttendance của cả tháng
        emp_ids = [e.id for e in employees]
        start_date = date(year, month, 1)
        end_date = date(year, month, num_days)

        attendances = db.query(DailyAttendance).filter(
            DailyAttendance.employee_id.in_(emp_ids),
            DailyAttendance.attendance_date >= start_date,
            DailyAttendance.attendance_date <= end_date
        ).all()

        # Map nhanh dữ liệu trong RAM: (employee_id, day) -> DailyAttendance
        att_map = {(a.employee_id, a.attendance_date.day): a for a in attendances}

        data_start_row = 7
        current_row = data_start_row

        d_start_letter = get_column_letter(day_start_col)
        d_end_letter = get_column_letter(day_end_col)

        for idx, emp in enumerate(employees, 1):
            ws.cell(row=current_row, column=1, value=idx).alignment = align_center
            ws.cell(row=current_row, column=2, value=emp.employee_code).alignment = align_center
            ws.cell(row=current_row, column=3, value=emp.zk_user_id).alignment = align_center
            ws.cell(row=current_row, column=4, value=emp.full_name).alignment = align_left
            ws.cell(row=current_row, column=5, value=emp.department).alignment = align_left
            ws.cell(row=current_row, column=6, value=emp.position or "").alignment = align_left

            for c in range(1, 7):
                cell = ws.cell(row=current_row, column=c)
                cell.font = font_data
                cell.border = border_all

            emp_actual_work = 0.0
            emp_total_p = 0.0
            emp_total_l = 0.0
            emp_total_ro = 0.0
            emp_total_v = 0.0
            emp_total_ot = 0.0
            emp_total_late = 0

            # Đổ dữ liệu 1 đến num_days
            for day in range(1, num_days + 1):
                col_c = day_start_col + day - 1
                cell = ws.cell(row=current_row, column=col_c)
                cell.font = font_data
                cell.alignment = align_center
                cell.border = border_all

                cur_date = date(year, month, day)
                is_sunday = (cur_date.weekday() >= 6)

                att = att_map.get((emp.id, day))
                if att:
                    st = att.status
                    lt = getattr(att, "leave_type", None)

                    if st == "HOLIDAY":
                        cell.value = "L"
                        cell.fill = fill_holiday
                        emp_total_l += 1.0
                    elif st == "HOLIDAY_WORK":
                        cell.value = "L*"
                        cell.fill = fill_holiday
                        emp_total_l += 1.0
                        emp_actual_work += 1.0
                        emp_total_ot += getattr(att, "ot_30_hours", 0.0) or 0.0
                    elif st == "LEAVE_PAID":
                        cell.value = "VR" if lt == "MARRIAGE" else "P"
                        cell.fill = fill_leave
                        emp_total_p += 1.0
                    elif st == "BUSINESS_TRIP":
                        cell.value = "CT"
                        cell.fill = fill_full
                        emp_actual_work += 1.0
                    elif st == "LEAVE_UNPAID":
                        cell.value = "Ro"
                        cell.fill = fill_ro
                        emp_total_ro += 1.0
                    elif st == "LEAVE_INSURANCE":
                        cell.value = "TS" if lt == "MATERNITY" else "Ô"
                        cell.fill = fill_ins
                    elif st == "ABSENT":
                        cell.value = "V"
                        cell.fill = fill_absent
                        emp_total_v += 1.0
                    elif is_sunday:
                        cell.value = "-"
                        cell.fill = fill_weekend
                    else:
                        if att.work_units > 0:
                            cell.value = att.work_units
                            emp_actual_work += att.work_units
                            ot_h = (att.ot_15_hours or 0) + (att.ot_20_hours or 0)
                            if ot_h > 0:
                                cell.fill = fill_ot
                            elif att.work_units == 1.0:
                                cell.fill = fill_full
                            else:
                                cell.fill = fill_half
                        else:
                            cell.value = "V"
                            cell.fill = fill_absent
                            emp_total_v += 1.0

                    emp_total_ot += ((att.ot_15_hours or 0) + (att.ot_20_hours or 0))
                    if att.late_minutes > 0:
                        emp_total_late += 1
                else:
                    if is_sunday:
                        cell.value = "-"
                        cell.fill = fill_weekend
                    else:
                        cell.value = ""

            # Công thức & Thống kê các cột tổng hợp
            col_work_letter = get_column_letter(sum_cols_map["Công Đi Làm"])
            col_p_letter = get_column_letter(sum_cols_map["Phép (P)"])
            col_l_letter = get_column_letter(sum_cols_map["Nghỉ Lễ (L)"])

            # 1. Công Đi Làm
            c_work = ws.cell(row=current_row, column=sum_cols_map["Công Đi Làm"], value=round(emp_actual_work, 1))
            c_work.font = font_summary
            c_work.fill = fill_summary
            c_work.alignment = align_right
            c_work.number_format = "0.0"
            c_work.border = border_all

            # 2. Phép (P)
            c_p = ws.cell(row=current_row, column=sum_cols_map["Phép (P)"], value=round(emp_total_p, 1))
            c_p.font = font_summary
            c_p.fill = fill_summary
            c_p.alignment = align_right
            c_p.number_format = "0.0"
            c_p.border = border_all

            # 3. Nghỉ Lễ (L)
            c_l = ws.cell(row=current_row, column=sum_cols_map["Nghỉ Lễ (L)"], value=round(emp_total_l, 1))
            c_l.font = font_summary
            c_l.fill = fill_summary
            c_l.alignment = align_right
            c_l.number_format = "0.0"
            c_l.border = border_all

            # 4. TỔNG CÔNG (Lương) = Công Đi Làm + Phép (P) + Lễ (L)
            c_tot_cong = ws.cell(row=current_row, column=sum_cols_map["TỔNG CÔNG"])
            c_tot_cong.value = f"={col_work_letter}{current_row}+{col_p_letter}{current_row}+{col_l_letter}{current_row}"
            c_tot_cong.font = font_total_row
            c_tot_cong.fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid") # Vàng nhạt nổi bật
            c_tot_cong.alignment = align_right
            c_tot_cong.number_format = "0.0"
            c_tot_cong.border = border_all

            # 5. Không Lương (Ro)
            c_ro = ws.cell(row=current_row, column=sum_cols_map["Không Lương (Ro)"], value=round(emp_total_ro, 1))
            c_ro.font = font_summary
            c_ro.fill = fill_summary
            c_ro.alignment = align_right
            c_ro.number_format = "0.0"
            c_ro.border = border_all

            # 6. Vắng (V)
            c_v = ws.cell(row=current_row, column=sum_cols_map["Vắng (V)"], value=round(emp_total_v, 1))
            c_v.font = font_summary
            c_v.fill = fill_summary
            c_v.alignment = align_right
            c_v.number_format = "0"
            c_v.border = border_all

            # 7. Tổng OT (h)
            c_ot = ws.cell(row=current_row, column=sum_cols_map["Giờ OT (h)"], value=round(emp_total_ot, 1))
            c_ot.font = font_summary
            c_ot.fill = fill_summary
            c_ot.alignment = align_right
            c_ot.number_format = "0.0"
            c_ot.border = border_all

            # 8. Lần trễ
            c_late = ws.cell(row=current_row, column=sum_cols_map["Số Lần Trễ"], value=emp_total_late)
            c_late.font = font_summary
            c_late.fill = fill_summary
            c_late.alignment = align_right
            c_late.border = border_all

            # 9. Ghi chú
            c_note = ws.cell(row=current_row, column=sum_cols_map["Ghi Chú"], value="")
            c_note.font = font_data
            c_note.border = border_all

            current_row += 1

        # DÒNG TỔNG CỘNG TOÀN CÔNG TY Ở CUỐI BẢNG
        total_row = current_row
        ws.merge_cells(start_row=total_row, start_column=1, end_row=total_row, end_column=6)
        c_title_tot = ws.cell(row=total_row, column=1, value=f"TỔNG CỘNG ({len(employees)} NHÂN SỰ)")
        c_title_tot.font = font_total_row
        c_title_tot.fill = fill_total_row
        c_title_tot.alignment = align_center
        c_title_tot.border = double_bottom_border

        for c in range(2, 7):
            ws.cell(row=total_row, column=c).border = double_bottom_border
            ws.cell(row=total_row, column=c).fill = fill_total_row

        # Tổng hợp từng ngày trong tháng
        for day in range(1, num_days + 1):
            col_c = day_start_col + day - 1
            col_letter = get_column_letter(col_c)
            cell = ws.cell(row=total_row, column=col_c)
            cell.value = f"=SUM({col_letter}{data_start_row}:{col_letter}{total_row - 1})"
            cell.font = font_total_row
            cell.fill = fill_total_row
            cell.alignment = align_center
            cell.number_format = "0"
            cell.border = double_bottom_border

        # Tổng hợp các cột cuối
        for s_title in ["Công Đi Làm", "Phép (P)", "Nghỉ Lễ (L)", "TỔNG CÔNG", "Không Lương (Ro)", "Vắng (V)", "Giờ OT (h)", "Số Lần Trễ"]:
            s_col = sum_cols_map[s_title]
            s_col_letter = get_column_letter(s_col)
            c_tot = ws.cell(row=total_row, column=s_col)
            c_tot.value = f"=SUM({s_col_letter}{data_start_row}:{s_col_letter}{total_row - 1})"
            c_tot.font = font_total_row
            c_tot.fill = fill_total_row
            c_tot.alignment = align_right
            c_tot.number_format = "#,##0.0" if "Công" in s_title or "OT" in s_title or "P" in s_title or "L" in s_title else "#,##0"
            c_tot.border = double_bottom_border

        ws.cell(row=total_row, column=sum_cols_map["Ghi Chú"]).border = double_bottom_border
        ws.cell(row=total_row, column=sum_cols_map["Ghi Chú"]).fill = fill_total_row

        # Khối Chữ Ký Chuẩn Kế Toán Cuối Bảng
        sign_row = total_row + 3
        ws.cell(row=sign_row, column=4, value="NGƯỜI LẬP BIỂU").font = Font(name="Segoe UI", size=10, bold=True)
        ws.cell(row=sign_row, column=4).alignment = align_center

        ws.cell(row=sign_row, column=sum_cols_map["TỔNG CÔNG"] - 2, value="KẾ TOÁN TRƯỞNG").font = Font(name="Segoe UI", size=10, bold=True)
        ws.cell(row=sign_row, column=sum_cols_map["TỔNG CÔNG"] - 2).alignment = align_center

        ws.cell(row=sign_row, column=sum_cols_map["TỔNG CÔNG"] + 1, value="GIÁM ĐỐC DUYỆT").font = Font(name="Segoe UI", size=10, bold=True)
        ws.cell(row=sign_row, column=sum_cols_map["TỔNG CÔNG"] + 1).alignment = align_center

        ws.cell(row=sign_row + 1, column=4, value="(Ký, ghi rõ họ tên)").font = Font(name="Segoe UI", size=9, italic=True, color="64748B")
        ws.cell(row=sign_row + 1, column=4).alignment = align_center

        ws.cell(row=sign_row + 1, column=sum_cols_map["TỔNG CÔNG"] - 2, value="(Ký, ghi rõ họ tên)").font = Font(name="Segoe UI", size=9, italic=True, color="64748B")
        ws.cell(row=sign_row + 1, column=sum_cols_map["TỔNG CÔNG"] - 2).alignment = align_center

        ws.cell(row=sign_row + 1, column=sum_cols_map["TỔNG CÔNG"] + 1, value="(Ký, đóng dấu)").font = Font(name="Segoe UI", size=9, italic=True, color="64748B")
        ws.cell(row=sign_row + 1, column=sum_cols_map["TỔNG CÔNG"] + 1).alignment = align_center

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output

    @classmethod
    def import_employees_from_excel(cls, db: Session, file_content: bytes) -> Dict[str, Any]:
        """
        Nhập danh sách nhân viên từ file Excel.
        Validate cấu trúc cột, kiểm tra trùng lặp mã chấm công zk_user_id và mã nhân viên.
        """
        wb = openpyxl.load_workbook(filename=io.BytesIO(file_content), data_only=True)
        ws = wb.active

        # Tìm dòng tiêu đề (quét 5 dòng đầu tiên)
        header_row = None
        col_indices = {}

        expected_aliases = {
            "employee_code": ["mã nv", "ma nv", "mã nhân viên", "manv", "code"],
            "zk_user_id": ["mã cc", "ma cc", "mã chấm công", "zk id", "máy cc", "user id", "id cc"],
            "full_name": ["họ và tên", "họ tên", "ho ten", "ten", "name", "full name"],
            "department": ["phòng ban", "bộ phận", "phong ban", "department"],
            "position": ["chức vụ", "vị trí", "chuc vu", "position", "title"],
            "phone": ["số điện thoại", "sđt", "phone", "dien thoai"],
            "email": ["email", "thư điện tử"]
        }

        for r in range(1, 6):
            row_vals = [str(cell.value).strip().lower() if cell.value is not None else "" for cell in ws[r]]
            for field, aliases in expected_aliases.items():
                for idx, val in enumerate(row_vals):
                    if any(alias in val for alias in aliases) and field not in col_indices:
                        col_indices[field] = idx + 1
            
            if "employee_code" in col_indices and "full_name" in col_indices:
                header_row = r
                break

        if not header_row:
            col_indices = {
                "employee_code": 2,
                "zk_user_id": 3,
                "full_name": 4,
                "department": 5,
                "position": 6,
                "phone": 7,
                "email": 8
            }
            header_row = 1

        default_shift = db.query(Shift).filter(Shift.is_default == True).first() or db.query(Shift).first()

        success_count = 0
        failed_count = 0
        errors = []

        total_rows = ws.max_row
        for r in range(header_row + 1, total_rows + 1):
            emp_code = str(ws.cell(row=r, column=col_indices.get("employee_code", 2)).value or "").strip()
            full_name = str(ws.cell(row=r, column=col_indices.get("full_name", 4)).value or "").strip()

            if not emp_code or not full_name:
                continue

            zk_id_raw = ws.cell(row=r, column=col_indices.get("zk_user_id", 3)).value
            zk_id = str(int(zk_id_raw) if isinstance(zk_id_raw, (int, float)) else (zk_id_raw or emp_code)).strip()

            department = str(ws.cell(row=r, column=col_indices.get("department", 5)).value or "Văn phòng").strip()
            position = str(ws.cell(row=r, column=col_indices.get("position", 6)).value or "Nhân viên").strip()
            phone = str(ws.cell(row=r, column=col_indices.get("phone", 7)).value or "").strip()
            email = str(ws.cell(row=r, column=col_indices.get("email", 8)).value or "").strip()

            existing_emp = db.query(Employee).filter(
                (Employee.employee_code == emp_code) | (Employee.zk_user_id == zk_id)
            ).first()

            if existing_emp:
                existing_emp.full_name = full_name
                existing_emp.department = department
                existing_emp.position = position
                if phone:
                    existing_emp.phone = phone
                if email:
                    existing_emp.email = email
                success_count += 1
            else:
                new_emp = Employee(
                    employee_code=emp_code,
                    zk_user_id=zk_id,
                    full_name=full_name,
                    department=department,
                    position=position,
                    phone=phone or None,
                    email=email or None,
                    shift_id=default_shift.id if default_shift else None,
                    is_active=True
                )
                db.add(new_emp)
                success_count += 1

        db.commit()

        return {
            "total_processed": success_count + failed_count,
            "success_count": success_count,
            "failed_count": failed_count,
            "errors": errors
        }

    @classmethod
    def export_daily_report(
        cls,
        db: Session,
        target_date: date,
        department: Optional[str] = None
    ) -> io.BytesIO:
        """
        Xuất file Excel Báo cáo Điểm danh Quân số Hàng Ngày (Daily Attendance Report).
        Báo cáo chi tiết: Có mặt, vắng mặt, đi trễ, về sớm, tăng ca, chấm bù.
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"Diem_Danh_{target_date.strftime('%d_%m_%Y')}"
        ws.views.sheetView[0].showGridLines = True

        font_title = Font(name="Segoe UI", size=15, bold=True, color="1E3A8A")
        font_meta = Font(name="Segoe UI", size=9.5, color="475569")
        font_header = Font(name="Segoe UI", size=9.5, bold=True, color="FFFFFF")
        font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
        font_bold = Font(name="Segoe UI", size=9.5, bold=True, color="0F172A")

        fill_header = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        fill_sub_header = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")
        fill_present = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
        fill_late = PatternFill(start_color="FEF08A", end_color="FEF08A", fill_type="solid")
        fill_absent = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
        fill_manual = PatternFill(start_color="EDE9FE", end_color="EDE9FE", fill_type="solid")

        align_center = Alignment(horizontal="center", vertical="center")
        align_left = Alignment(horizontal="left", vertical="center")
        align_right = Alignment(horizontal="right", vertical="center")

        thin_side = Side(style="thin", color="CBD5E1")
        border_all = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)

        dept_text = f"Bộ phận: {department}" if (department and department != "Tất cả") else "Toàn công ty"
        ws.merge_cells("A1:K1")
        ws["A1"] = f"BÁO CÁO ĐIỂM DANH & QUÂN SỐ NGÀY {target_date.strftime('%d/%m/%Y')}"
        ws["A1"].font = font_title
        ws["A1"].alignment = align_left

        ws.merge_cells("A2:K2")
        ws["A2"] = f"{dept_text}  |  Thời điểm xuất: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
        ws["A2"].font = font_meta
        ws["A2"].alignment = align_left

        headers = [
            ("STT", 6),
            ("Mã NV", 12),
            ("Mã ZK", 10),
            ("Họ và Tên", 25),
            ("Bộ Phận", 18),
            ("Chức Vụ", 16),
            ("Ca Làm Việc", 22),
            ("Giờ Vào", 10),
            ("Giờ Ra", 10),
            ("Đi Trễ (phút)", 13),
            ("Về Sớm (phút)", 13),
            ("Giờ OT (h)", 11),
            ("Công", 9),
            ("Trạng Thái", 14),
            ("Chấm Bù", 11),
            ("Ghi Chú / Lý Do", 25)
        ]

        row_header = 4
        for col_idx, (h_title, width) in enumerate(headers, 1):
            cell = ws.cell(row=row_header, column=col_idx, value=h_title)
            cell.font = font_header
            cell.fill = fill_header
            cell.alignment = align_center
            cell.border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = width

        # Query data
        emp_query = db.query(Employee).filter(Employee.is_active == True)
        if department and department != "Tất cả":
            emp_query = emp_query.filter(Employee.department == department)
        employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

        emp_ids = [e.id for e in employees]
        records = db.query(DailyAttendance).filter(
            DailyAttendance.attendance_date == target_date,
            DailyAttendance.employee_id.in_(emp_ids)
        ).all()
        rec_map = {r.employee_id: r for r in records}

        all_shifts = db.query(Shift).all()
        shift_map = {s.id: s for s in all_shifts}
        default_shift = next((s for s in all_shifts if s.is_default), all_shifts[0] if all_shifts else None)

        current_row = 5
        stt = 1
        present_count = 0
        absent_count = 0
        late_count = 0
        total_ot = 0.0

        for emp in employees:
            att = rec_map.get(emp.id)
            shift = (shift_map.get(att.shift_id) if att and att.shift_id else None) or emp.shift or default_shift
            shift_title = shift.name if shift else "Chưa gán ca"

            in_val = att.first_check_in.strftime("%H:%M") if (att and att.first_check_in) else "-"
            out_val = att.last_check_out.strftime("%H:%M") if (att and att.last_check_out) else "-"
            late_m = att.late_minutes if att else 0
            early_m = att.early_leave_minutes if att else 0
            ot_h = round((att.ot_15_hours or 0) + (att.ot_20_hours or 0) + (getattr(att, "ot_30_hours", 0) or 0), 1) if att else 0.0
            work_u = att.work_units if att else 0.0
            is_manual = bool(att and att.is_manual_override)
            notes_str = att.notes if att else ""

            # Trạng thái văn bản
            if att and att.status == "FULL_DAY":
                status_txt = "Đủ công (1.0)"
                present_count += 1
            elif att and att.status == "HALF_DAY":
                status_txt = "Nửa công (0.5)"
                present_count += 1
            elif att and att.status == "LATE_EARLY":
                status_txt = "Trễ / Sớm"
                present_count += 1
            elif att and att.status == "OVERTIME":
                status_txt = "Tăng ca"
                present_count += 1
            elif att and att.status in ["HOLIDAY", "HOLIDAY_WORK", "LEAVE_PAID", "LEAVE_UNPAID", "LEAVE_INSURANCE", "BUSINESS_TRIP"]:
                status_txt = "Nghỉ phép/Lễ"
            else:
                status_txt = "Vắng"
                absent_count += 1

            if late_m > 0: late_count += 1
            total_ot += ot_h

            ws.cell(row=current_row, column=1, value=stt).alignment = align_center
            ws.cell(row=current_row, column=2, value=emp.employee_code).alignment = align_center
            ws.cell(row=current_row, column=3, value=emp.zk_user_id).alignment = align_center
            ws.cell(row=current_row, column=4, value=emp.full_name).alignment = align_left
            ws.cell(row=current_row, column=5, value=emp.department).alignment = align_left
            ws.cell(row=current_row, column=6, value=emp.position or "Công nhân").alignment = align_left
            ws.cell(row=current_row, column=7, value=shift_title).alignment = align_left
            ws.cell(row=current_row, column=8, value=in_val).alignment = align_center
            ws.cell(row=current_row, column=9, value=out_val).alignment = align_center
            ws.cell(row=current_row, column=10, value=late_m if late_m > 0 else 0).alignment = align_center
            ws.cell(row=current_row, column=11, value=early_m if early_m > 0 else 0).alignment = align_center
            ws.cell(row=current_row, column=12, value=ot_h if ot_h > 0 else 0).alignment = align_center
            ws.cell(row=current_row, column=13, value=work_u).alignment = align_center
            ws.cell(row=current_row, column=14, value=status_txt).alignment = align_center
            ws.cell(row=current_row, column=15, value="Có (Sửa tay)" if is_manual else "").alignment = align_center
            ws.cell(row=current_row, column=16, value=notes_str).alignment = align_left

            # Style row
            for c in range(1, 17):
                cell = ws.cell(row=current_row, column=c)
                cell.font = font_data
                cell.border = border_all
                if c == 14:
                    if "Đủ công" in status_txt: cell.fill = fill_present
                    elif "Trễ" in status_txt: cell.fill = fill_late
                    elif "Vắng" in status_txt: cell.fill = fill_absent
                if c == 15 and is_manual:
                    cell.fill = fill_manual

            current_row += 1
            stt += 1

        # Summary box at row 2
        ws["A3"] = f"Tổng số: {len(employees)} | Có mặt: {present_count} | Vắng: {absent_count} | Đi trễ: {late_count} | Tổng giờ OT: {round(total_ot, 1)} giờ"
        ws["A3"].font = font_bold
        ws["A3"].alignment = align_left

        stream = io.BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream

    @classmethod
    @classmethod
    def export_employees_list(cls, db: Session, department: Optional[str] = None, status_filter: Optional[str] = None) -> io.BytesIO:
        """
        Xuất danh sách hồ sơ nhân sự toàn diện ra file Excel với đầy đủ các trường thông tin Enterprise HR.
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Ho_So_Nhan_Su"
        ws.views.sheetView[0].showGridLines = True

        font_title = Font(name="Segoe UI", size=14, bold=True, color="1E3A8A")
        font_header = Font(name="Segoe UI", size=9.5, bold=True, color="FFFFFF")
        font_data = Font(name="Segoe UI", size=9, color="0F172A")
        fill_header = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        border_all = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )
        align_center = Alignment(horizontal="center", vertical="center")
        align_left = Alignment(horizontal="left", vertical="center")
        align_right = Alignment(horizontal="right", vertical="center")

        ws.merge_cells("A1:K1")
        ws["A1"] = "BẢNG HỒ SƠ QUẢN LÝ NHÂN SỰ & HỢP ĐỒNG LAO ĐỘNG"
        ws["A1"].font = font_title
        ws["A1"].alignment = align_left

        ws["A2"] = f"Thời điểm xuất báo cáo: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  |  Hệ thống Quản lý KTS TimeAttendance"
        ws["A2"].font = Font(name="Segoe UI", size=9, italic=True, color="64748B")

        headers = [
            ("STT", 6),
            ("Mã NV", 12),
            ("Mã Máy ZK", 12),
            ("Họ và Tên", 25),
            ("Tên Tiếng Hoa", 15),
            ("Giới Tính", 10),
            ("Ngày Sinh", 12),
            ("Tuổi", 8),
            ("Nơi Sinh", 15),
            ("Quốc Tịch", 12),
            ("Học Vấn", 12),
            ("Địa Chỉ Thường Trú", 32),
            ("Số CCCD", 16),
            ("Ngày Cấp", 12),
            ("Nơi Cấp", 16),
            ("Số Hộ Chiếu", 15),
            ("Số GPLĐ", 18),
            ("Điện Thoại", 14),
            ("SĐT Người Thân", 20),
            ("Bộ Phận / Phòng Ban", 22),
            ("Chức Vụ", 18),
            ("Xưởng", 15),
            ("Ngày Vào Làm", 13),
            ("Mã HĐ", 12),
            ("Loại HĐ", 22),
            ("Loại HĐ Tiếng Hoa", 22),
            ("HĐ Từ Ngày", 13),
            ("HĐ Đến Ngày", 13),
            ("Lương Cơ Bản", 14),
            ("PC Chức Vụ", 14),
            ("Lương Đóng BH", 14),
            ("Mã Số BHXH", 15),
            ("Báo Tăng BH", 12),
            ("Báo Giảm BH", 12),
            ("Công Đoàn Phí", 13),
            ("STK Techcombank", 18),
            ("STK ACB", 16),
            ("STK Vietcombank", 18),
            ("Đồng Phục", 12),
            ("Size Áo", 10),
            ("Màu Áo", 10),
            ("Người Giới Thiệu", 22),
            ("Nghỉ Thai Sản Từ", 14),
            ("Đi Làm Lại", 13),
            ("Ngày Sinh Con", 13),
            ("Hết Nuôi Con Nhỏ", 14),
            ("Trạng Thái", 16),
            ("Ngày Nghỉ Việc", 13),
            ("Lý Do Nghỉ", 25),
            ("Thu Tiền Y Tế", 13)
        ]

        row_header = 4
        for col_idx, (h_title, width) in enumerate(headers, 1):
            cell = ws.cell(row=row_header, column=col_idx, value=h_title)
            cell.font = font_header
            cell.fill = fill_header
            cell.alignment = align_center
            cell.border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = width

        query = db.query(Employee)
        if department and department != "Tất cả":
            query = query.filter(Employee.department == department)
        if status_filter and status_filter != "all":
            if status_filter == "active":
                query = query.filter(Employee.is_active == True)
            elif status_filter == "probation":
                query = query.filter(Employee.status == "probation")
            elif status_filter == "resigned":
                query = query.filter(Employee.is_active == False)
            elif status_filter == "foreign_expert":
                query = query.filter(Employee.nationality == "Trung Quốc")
            elif status_filter == "maternity_childcare":
                query = query.filter(Employee.status.in_(["maternity", "childcare", "pregnant"]))

        employees = query.order_by(Employee.is_active.desc(), Employee.employee_code.asc()).all()

        current_row = 5
        for idx, emp in enumerate(employees, 1):
            def fmt_date(d):
                return d.strftime("%d/%m/%Y") if d else ""

            status_text = "Đang làm việc"
            if not emp.is_active or emp.status == "resigned":
                status_text = "Đã thôi việc"
            elif emp.status == "childcare":
                status_text = "Nuôi con nhỏ (Về sớm 1h)"
            elif emp.status == "maternity":
                status_text = "Nghỉ thai sản"
            elif emp.status == "foreign_expert":
                status_text = "Chuyên gia TQ"
            elif emp.status == "probation":
                status_text = "Thử việc"

            vals = [
                idx,
                emp.employee_code or "",
                emp.zk_user_id or "",
                emp.full_name or "",
                emp.chinese_name or "",
                emp.gender or "Nam",
                fmt_date(emp.birth_date),
                emp.age or "",
                emp.birth_place or "",
                emp.nationality or "Việt Nam",
                emp.education or "",
                emp.permanent_address or "",
                emp.id_card_no or "",
                fmt_date(emp.id_card_date),
                emp.id_card_place or "",
                emp.passport_no or "",
                emp.work_permit_no or "",
                emp.phone or "",
                emp.emergency_contact or "",
                emp.department or "",
                emp.position or "",
                emp.workshop or "",
                fmt_date(emp.hire_date),
                emp.contract_code or "",
                emp.contract_type or "",
                emp.contract_type_cn or "",
                fmt_date(emp.contract_start_date),
                fmt_date(emp.contract_end_date),
                emp.base_salary or 0,
                emp.allowance_position or 0,
                emp.insurance_salary or 0,
                emp.social_insurance_no or "",
                emp.insurance_increase_month or "",
                emp.insurance_decrease_month or "",
                emp.union_fee or 0,
                emp.bank_techcombank or "",
                emp.bank_acb or "",
                emp.bank_vietcombank or "",
                emp.uniform_status or "",
                emp.shirt_size or "",
                emp.shirt_color or "",
                emp.referrer or "",
                fmt_date(emp.maternity_leave_start),
                fmt_date(emp.maternity_leave_end),
                fmt_date(emp.child_birth_date),
                fmt_date(emp.childcare_end_date),
                status_text,
                fmt_date(emp.resignation_date),
                emp.resignation_reason or "",
                emp.medical_fee_collected or 0
            ]

            for c_idx, val in enumerate(vals, 1):
                cell = ws.cell(row=current_row, column=c_idx, value=val)
                cell.font = font_data
                cell.border = border_all
                if isinstance(val, (int, float)) and c_idx in (29, 30, 31, 35, 50):
                    cell.number_format = '#,##0'
                    cell.alignment = align_right
                elif c_idx in (1, 2, 3, 6, 7, 8, 10, 14, 23, 24, 27, 28, 33, 34, 40, 41, 43, 44, 45, 46, 47, 48):
                    cell.alignment = align_center
                else:
                    cell.alignment = align_left

            current_row += 1

        stream = io.BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream

    @classmethod
    def export_employees_template(cls) -> io.BytesIO:
        """
        Xuất file Excel mẫu để người dùng điền thông tin và nhập hàng loạt (Import).
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Mau_Nhap_Nhan_Vien"
        ws.views.sheetView[0].showGridLines = True

        font_header = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
        font_note = Font(name="Segoe UI", size=8.5, italic=True, color="64748B")
        fill_header = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        fill_note = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
        border_all = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )
        align_center = Alignment(horizontal="center", vertical="center")
        align_left = Alignment(horizontal="left", vertical="center")

        ws.merge_cells("A1:G1")
        ws["A1"] = "HƯỚNG DẪN: Điền thông tin nhân viên theo các cột dưới đây. Cột Mã NV và Mã Máy Chấm Công là bắt buộc duy nhất."
        ws["A1"].font = font_note
        ws["A1"].fill = fill_note
        ws["A1"].alignment = align_left

        headers = [
            ("Mã NV (*)", 16),
            ("Mã Chấm Công (ZK ID) (*)", 24),
            ("Họ và Tên (*)", 25),
            ("Phòng Ban", 20),
            ("Chức Vụ", 18),
            ("Ngày Vào Làm (YYYY-MM-DD)", 24),
            ("Ghi Chú", 20),
        ]

        row_header = 3
        for col_idx, (h_title, width) in enumerate(headers, 1):
            cell = ws.cell(row=row_header, column=col_idx, value=h_title)
            cell.font = font_header
            cell.fill = fill_header
            cell.alignment = align_center
            cell.border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = width

        # Dòng mẫu
        sample_rows = [
            ("NV001", "1", "Nguyễn Văn An", "Sản Xuất", "Công nhân", "2024-01-15", "Mẫu công nhân"),
            ("NV002", "2", "Trần Thị Bình", "Kế Toán", "Nhân viên", "2023-06-01", "Mẫu văn phòng"),
            ("NV003", "3", "Lê Văn Cường", "Kỹ Thuật", "Kỹ sư", "2022-11-20", "Mẫu kỹ thuật"),
        ]

        for r_idx, row_data in enumerate(sample_rows, 4):
            for c_idx, val in enumerate(row_data, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.font = font_data
                cell.border = border_all
                cell.alignment = align_center if c_idx in [1, 2, 6] else align_left

        stream = io.BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream

    @classmethod
    def export_raw_attendance_logs(cls, punches_data: list) -> io.BytesIO:
        """
        Xuất danh sách nhật ký quẹt thẻ gốc từ máy chấm công ra Excel.
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Nhat_Ky_Quet_The"
        ws.views.sheetView[0].showGridLines = True

        font_title = Font(name="Segoe UI", size=14, bold=True, color="1E3A8A")
        font_header = Font(name="Segoe UI", size=9.5, bold=True, color="FFFFFF")
        font_data = Font(name="Segoe UI", size=9.5, color="0F172A")
        fill_header = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        border_all = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )
        align_center = Alignment(horizontal="center", vertical="center")
        align_left = Alignment(horizontal="left", vertical="center")

        ws.merge_cells("A1:H1")
        ws["A1"] = "NHẬT KÝ QUẸT THẺ GỐC (RAW PUNCH LOGS)"
        ws["A1"].font = font_title
        ws["A1"].alignment = align_left

        ws["A2"] = f"Thời điểm xuất file: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')} | Tổng số lượt quẹt: {len(punches_data)}"
        ws["A2"].font = Font(name="Segoe UI", size=9, color="64748B")

        headers = [
            ("STT", 6),
            ("Mã NV", 14),
            ("Họ và Tên", 24),
            ("Mã Máy Chấm Công (ZK ID)", 22),
            ("Phòng Ban", 18),
            ("Thời Gian Quẹt Thẻ", 22),
            ("Trạng Thái", 16),
            ("Thiết Bị", 20),
        ]

        row_header = 4
        for col_idx, (h_title, width) in enumerate(headers, 1):
            cell = ws.cell(row=row_header, column=col_idx, value=h_title)
            cell.font = font_header
            cell.fill = fill_header
            cell.alignment = align_center
            cell.border = border_all
            ws.column_dimensions[get_column_letter(col_idx)].width = width

        for idx, p in enumerate(punches_data, 1):
            r = row_header + idx
            ws.cell(row=r, column=1, value=idx).alignment = align_center
            ws.cell(row=r, column=2, value=p.get("employee_code", "-")).alignment = align_center
            ws.cell(row=r, column=3, value=p.get("full_name", "-")).alignment = align_left
            ws.cell(row=r, column=4, value=p.get("zk_user_id", "-")).alignment = align_center
            ws.cell(row=r, column=5, value=p.get("department", "-")).alignment = align_left
            ws.cell(row=r, column=6, value=p.get("check_time_str", "-")).alignment = align_center
            ws.cell(row=r, column=7, value=p.get("punch_state_name", "Quẹt thẻ")).alignment = align_center
            ws.cell(row=r, column=8, value=p.get("device_name", "Máy chấm công")).alignment = align_left

            for c in range(1, 9):
                cell = ws.cell(row=r, column=c)
                cell.font = font_data
                cell.border = border_all

        stream = io.BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream
