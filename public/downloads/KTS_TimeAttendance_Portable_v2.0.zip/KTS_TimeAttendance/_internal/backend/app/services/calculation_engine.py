import logging
import calendar
from datetime import datetime, date, time, timedelta
from typing import List, Optional, Tuple, Dict
from sqlalchemy.orm import Session

from backend.app.core.config import settings
from backend.app.models.employee import Employee
from backend.app.models.shift import Shift
from backend.app.models.attendance_log import RawAttendanceLog
from backend.app.models.daily_attendance import DailyAttendance
from backend.app.models.holiday import Holiday
from backend.app.models.leave_request import LeaveRequest

logger = logging.getLogger("calculation_engine")

class AttendanceCalculationEngine:
    """
    Thuật toán tính toán dữ liệu công, trễ/sớm và tăng ca (OT) cho doanh nghiệp.
    Tối ưu hóa hiệu năng cao (In-Memory Batch Engine) cho hàng nghìn nhân sự.
    - Lọc bỏ quẹt thẻ liên tiếp cách nhau dưới 5 phút (Anti-passback / Debounce).
    - Bắt cặp giờ Vào (check-in hợp lệ) và Giờ Ra (check-out hợp lệ).
    - Tính phút đi trễ, về sớm dựa theo Grace Period.
    - Tách giờ làm tiêu chuẩn (trừ giờ nghỉ trưa) và giờ OT sau ca.
    """

    @classmethod
    def match_best_shift(
        cls,
        check_in_time: Optional[datetime],
        all_shifts: List[Shift],
        default_shift: Shift
    ) -> Shift:
        """
        TỰ ĐỘNG NHẬN DIỆN CA THÔNG MINH (Auto Shift Detection):
        Dựa vào thời gian quẹt thẻ vào (Check-in time) của công nhân,
        tự động so khớp với ca có mốc giờ bắt đầu gần nhất.
        - Quẹt 05:30 - 06:30 -> Tự khớp Ca Sáng (06:00 - 14:00)
        - Quẹt 07:00 - 08:30 -> Tự khớp Ca Hành Chính (07:30 - 16:30)
        - Quẹt 13:30 - 14:30 -> Tự khớp Ca Chiều (14:00 - 22:00)
        - Quẹt 21:30 - 22:30 -> Tự khớp Ca Đêm (22:00 - 06:00)
        """
        if not check_in_time or not all_shifts:
            return default_shift

        cin_minutes = check_in_time.hour * 60 + check_in_time.minute
        best_shift = default_shift
        min_diff = 999999

        for s in all_shifts:
            try:
                parts = s.start_time.split(":")
                s_minutes = int(parts[0]) * 60 + int(parts[1])
                diff = abs(cin_minutes - s_minutes)
                if diff > 720:
                    diff = 1440 - diff

                if diff < min_diff:
                    min_diff = diff
                    best_shift = s
            except Exception:
                continue

        if min_diff <= 210:
            return best_shift
        return default_shift

    @staticmethod
    def debounce_logs(logs: List[RawAttendanceLog], min_interval_seconds: int = 300) -> List[RawAttendanceLog]:
        """
        Lọc bỏ các lần quẹt thẻ lặp lại trong vòng min_interval_seconds (mặc định 5 phút).
        Chỉ giữ lại lần quẹt thẻ hợp lệ đầu tiên trong mỗi khoảng debounce.
        """
        if not logs:
            return []

        sorted_logs = sorted(logs, key=lambda x: x.check_time)
        filtered: List[RawAttendanceLog] = [sorted_logs[0]]

        for log in sorted_logs[1:]:
            last_time = filtered[-1].check_time
            if (log.check_time - last_time).total_seconds() >= min_interval_seconds:
                filtered.append(log)

        return filtered

    @staticmethod
    def parse_time_str(time_str: Optional[str]) -> Optional[time]:
        if not time_str:
            return None
        parts = time_str.strip().split(":")
        return time(int(parts[0]), int(parts[1]))

    @classmethod
    def _evaluate_day(
        cls,
        valid_logs: List[RawAttendanceLog],
        shift: Shift,
        target_date: date,
        holiday: Optional[Holiday] = None,
        leave: Optional[LeaveRequest] = None
    ) -> Dict[str, Any]:
        """
        Tính toán các chỉ số công từ danh sách các lần quẹt thẻ đã debounce,
        tích hợp Ngày Lễ (Holidays) và Đơn Nghỉ Phép (Leave Requests).
        """
        is_weekend = (target_date.weekday() >= 6) # 6 là Chủ nhật

        # 1. ƯU TIÊN 1: XỬ LÝ NGÀY LỄ / TẾT (Holidays)
        if holiday:
            if not valid_logs:
                return {
                    "first_check_in": None,
                    "last_check_out": None,
                    "late_minutes": 0,
                    "early_leave_minutes": 0,
                    "standard_hours": 0.0,
                    "ot_15_hours": 0.0,
                    "ot_20_hours": 0.0,
                    "ot_30_hours": 0.0,
                    "work_units": 1.0, # Hưởng nguyên lương 100% theo BLLĐ
                    "status": "HOLIDAY",
                    "leave_type": "HOLIDAY",
                    "notes": f"Nghỉ lễ: {holiday.name}"
                }
            else:
                # Nhân viên đi làm vào ngày Lễ/Tết -> Hưởng công lễ (1.0) + Làm thêm giờ hệ số 3.0 (OT 300%)!
                first_check_in = valid_logs[0].check_time
                last_check_out = valid_logs[-1].check_time if len(valid_logs) > 1 else None
                worked_sec = (last_check_out - first_check_in).total_seconds() if last_check_out else 4.0 * 3600
                worked_h = round(worked_sec / 3600.0, 2)
                return {
                    "first_check_in": first_check_in,
                    "last_check_out": last_check_out,
                    "late_minutes": 0,
                    "early_leave_minutes": 0,
                    "standard_hours": 0.0,
                    "ot_15_hours": 0.0,
                    "ot_20_hours": 0.0,
                    "ot_30_hours": worked_h,
                    "work_units": 1.0,
                    "status": "HOLIDAY_WORK",
                    "leave_type": "HOLIDAY",
                    "notes": f"Đi làm ngày Lễ ({holiday.name}): OT {holiday.ot_rate or 3.0}x ({worked_h}h)"
                }

        # 2. ƯU TIÊN 2: XỬ LÝ ĐƠN NGHỈ PHÉP (Leave Requests)
        if leave:
            reason_txt = f": {leave.reason}" if leave.reason else ""
            if leave.leave_type == "UNPAID":
                return {
                    "first_check_in": None,
                    "last_check_out": None,
                    "late_minutes": 0,
                    "early_leave_minutes": 0,
                    "standard_hours": 0.0,
                    "ot_15_hours": 0.0,
                    "ot_20_hours": 0.0,
                    "ot_30_hours": 0.0,
                    "work_units": 0.0,
                    "status": "LEAVE_UNPAID",
                    "leave_type": "UNPAID",
                    "notes": f"Nghỉ không lương (Ro){reason_txt}"
                }
            elif leave.leave_type in ["SICK", "MATERNITY"]:
                ins_label = "Ốm đau (Ô)" if leave.leave_type == "SICK" else "Thai sản (TS)"
                return {
                    "first_check_in": None,
                    "last_check_out": None,
                    "late_minutes": 0,
                    "early_leave_minutes": 0,
                    "standard_hours": 0.0,
                    "ot_15_hours": 0.0,
                    "ot_20_hours": 0.0,
                    "ot_30_hours": 0.0,
                    "work_units": 0.0,
                    "status": "LEAVE_INSURANCE",
                    "leave_type": leave.leave_type,
                    "notes": f"Nghỉ chế độ BHXH - {ins_label}{reason_txt}"
                }
            elif leave.leave_type in ["ANNUAL", "MARRIAGE", "BUSINESS_TRIP"]:
                paid_label = "Nghỉ phép năm (P)" if leave.leave_type == "ANNUAL" else "Việc riêng có lương (VR)" if leave.leave_type == "MARRIAGE" else "Đi công tác (CT)"
                if leave.half_day_type == "FULL":
                    return {
                        "first_check_in": None,
                        "last_check_out": None,
                        "late_minutes": 0,
                        "early_leave_minutes": 0,
                        "standard_hours": 0.0,
                        "ot_15_hours": 0.0,
                        "ot_20_hours": 0.0,
                        "ot_30_hours": 0.0,
                        "work_units": 1.0,
                        "status": "BUSINESS_TRIP" if leave.leave_type == "BUSINESS_TRIP" else "LEAVE_PAID",
                        "leave_type": leave.leave_type,
                        "notes": f"{paid_label}{reason_txt}"
                    }
                else:
                    # Nghỉ nửa ngày phép
                    half_label = "Sáng" if leave.half_day_type == "MORNING" else "Chiều"
                    if not valid_logs:
                        return {
                            "first_check_in": None,
                            "last_check_out": None,
                            "late_minutes": 0,
                            "early_leave_minutes": 0,
                            "standard_hours": 4.0,
                            "ot_15_hours": 0.0,
                            "ot_20_hours": 0.0,
                            "ot_30_hours": 0.0,
                            "work_units": 0.5,
                            "status": "HALF_DAY",
                            "leave_type": leave.leave_type,
                            "notes": f"Nghỉ phép nửa ngày ({half_label}){reason_txt}"
                        }

        # 3. XỬ LÝ THEO QUẸT THẺ THỰC TẾ
        if not valid_logs:
            return {
                "first_check_in": None,
                "last_check_out": None,
                "late_minutes": 0,
                "early_leave_minutes": 0,
                "standard_hours": 0.0,
                "ot_15_hours": 0.0,
                "ot_20_hours": 0.0,
                "ot_30_hours": 0.0,
                "work_units": 0.0,
                "status": "WEEKEND" if is_weekend else "ABSENT",
                "leave_type": None,
                "notes": None
            }

        first_check_in = valid_logs[0].check_time
        last_check_out = valid_logs[-1].check_time if len(valid_logs) > 1 else None

        # Nếu chỉ có 1 lần quẹt thẻ trong ngày
        if not last_check_out:
            return {
                "first_check_in": first_check_in,
                "last_check_out": None,
                "late_minutes": 0,
                "early_leave_minutes": 0,
                "standard_hours": 4.0,
                "ot_15_hours": 0.0,
                "ot_20_hours": 0.0,
                "ot_30_hours": 0.0,
                "work_units": 0.5,
                "status": "HALF_DAY",
                "leave_type": None,
                "notes": "Chỉ có 1 lần quẹt thẻ (Cần giải trình)"
            }

        # Tính toán theo ca làm việc (Shift)
        shift_start_t = cls.parse_time_str(shift.start_time) or time(8, 0)
        shift_end_t = cls.parse_time_str(shift.end_time) or time(17, 30)
        shift_start_dt = datetime.combine(target_date, shift_start_t)
        shift_end_dt = datetime.combine(target_date, shift_end_t)

        grace_period = shift.grace_period_minutes or 15

        # Tính phút trễ
        late_minutes = 0
        if first_check_in > shift_start_dt:
            diff_minutes = int((first_check_in - shift_start_dt).total_seconds() / 60)
            if diff_minutes > grace_period:
                late_minutes = diff_minutes

        # Tính phút về sớm
        early_leave_minutes = 0
        if last_check_out < shift_end_dt:
            diff_minutes = int((shift_end_dt - last_check_out).total_seconds() / 60)
            if diff_minutes > grace_period:
                early_leave_minutes = diff_minutes

        # Giờ làm việc thực tế và khấu trừ nghỉ trưa
        worked_seconds = (last_check_out - first_check_in).total_seconds()
        break_seconds = 0
        if shift.break_start and shift.break_end:
            b_start_dt = datetime.combine(target_date, cls.parse_time_str(shift.break_start))
            b_end_dt = datetime.combine(target_date, cls.parse_time_str(shift.break_end))
            overlap_start = max(first_check_in, b_start_dt)
            overlap_end = min(last_check_out, b_end_dt)
            if overlap_end > overlap_start:
                break_seconds = (overlap_end - overlap_start).total_seconds()

        actual_worked_hours = max(0.0, (worked_seconds - break_seconds) / 3600.0)
        standard_cap = shift.standard_work_hours or 8.0
        standard_hours = round(min(actual_worked_hours, standard_cap), 2)

        # Tính OT
        ot_15_hours = 0.0
        ot_20_hours = 0.0
        ot_threshold_minutes = shift.ot_start_after_minutes or 30
        ot_start_dt = shift_end_dt + timedelta(minutes=ot_threshold_minutes)

        if last_check_out > ot_start_dt:
            ot_seconds = (last_check_out - shift_end_dt).total_seconds()
            ot_h = round(ot_seconds / 3600.0, 2)
            if is_weekend:
                ot_20_hours = ot_h
            else:
                ot_15_hours = ot_h

        # Trạng thái công
        work_units = 0.0
        if leave and leave.half_day_type in ["MORNING", "AFTERNOON"]:
            # Có nửa ngày phép + nửa ngày đi làm = đủ 1.0 công
            work_units = 1.0
            status = "FULL_DAY"
        elif standard_hours >= (standard_cap - 1.0):
            work_units = 1.0
            if (ot_15_hours + ot_20_hours) > 0:
                status = "OVERTIME"
            elif late_minutes > 0 or early_leave_minutes > 0:
                status = "LATE_EARLY"
            else:
                status = "FULL_DAY"
        elif standard_hours >= 3.5:
            work_units = 0.5
            status = "HALF_DAY"
        else:
            work_units = 0.0
            status = "ABSENT"

        return {
            "first_check_in": first_check_in,
            "last_check_out": last_check_out,
            "late_minutes": late_minutes,
            "early_leave_minutes": early_leave_minutes,
            "standard_hours": standard_hours,
            "ot_15_hours": ot_15_hours,
            "ot_20_hours": ot_20_hours,
            "ot_30_hours": 0.0,
            "work_units": work_units,
            "status": status,
            "leave_type": leave.leave_type if leave else None,
            "notes": None
        }

    @classmethod
    def calculate_month_for_all(
        cls,
        db: Session,
        year: int,
        month: int,
        employee_id: Optional[int] = None
    ) -> int:
        """
        Chạy tính toán bảng công cho toàn bộ nhân sự trong tháng với hiệu năng cực cao.
        Quét log một lần, gom nhóm trong RAM và commit một lần duy nhất.
        """
        num_days = calendar.monthrange(year, month)[1]

        emp_query = db.query(Employee).filter(Employee.is_active == True)
        if employee_id:
            emp_query = emp_query.filter(Employee.id == employee_id)
        employees = emp_query.all()
        if not employees:
            return 0

        all_shifts = db.query(Shift).all()
        default_shift = db.query(Shift).filter(Shift.is_default == True).first() or (all_shifts[0] if all_shifts else None)

        # 1. Kéo toàn bộ log chấm công của tháng một lần duy nhất
        start_range = datetime.combine(date(year, month, 1), time(4, 0, 0))
        end_range = datetime.combine(date(year, month, num_days), time(4, 0, 0)) + timedelta(hours=24)

        logs = db.query(RawAttendanceLog).filter(
            RawAttendanceLog.check_time >= start_range,
            RawAttendanceLog.check_time < end_range
        ).order_by(RawAttendanceLog.check_time.asc()).all()

        # Gom nhóm log theo (zk_user_id, target_date)
        logs_by_user_day: Dict[Tuple[str, date], List[RawAttendanceLog]] = {}
        for l in logs:
            # Ngày công tính từ 04:00 sáng hôm nay đến 03:59 sáng hôm sau
            work_day = (l.check_time - timedelta(hours=4)).date()
            key = (l.zk_user_id, work_day)
            if key not in logs_by_user_day:
                logs_by_user_day[key] = []
            logs_by_user_day[key].append(l)

        # 2. Kéo toàn bộ DailyAttendance của tháng hiện có trong DB
        existing_records = db.query(DailyAttendance).filter(
            DailyAttendance.attendance_date >= date(year, month, 1),
            DailyAttendance.attendance_date <= date(year, month, num_days)
        ).all()
        existing_map = {(r.employee_id, r.attendance_date): r for r in existing_records}

        # 3. Kéo toàn bộ Ngày Lễ (Holidays) áp dụng trong tháng
        holidays = db.query(Holiday).filter(
            Holiday.start_date <= date(year, month, num_days),
            Holiday.end_date >= date(year, month, 1)
        ).all()
        holiday_by_date: Dict[date, Holiday] = {}
        for h in holidays:
            curr = max(h.start_date, date(year, month, 1))
            end_h = min(h.end_date, date(year, month, num_days))
            while curr <= end_h:
                holiday_by_date[curr] = h
                curr += timedelta(days=1)

        # 4. Kéo toàn bộ Đơn Nghỉ Phép (Leave Requests) đã duyệt trong tháng
        leaves = db.query(LeaveRequest).filter(
            LeaveRequest.status == "APPROVED",
            LeaveRequest.start_date <= date(year, month, num_days),
            LeaveRequest.end_date >= date(year, month, 1)
        ).all()
        leaves_by_emp_date: Dict[Tuple[int, date], LeaveRequest] = {}
        for lv in leaves:
            curr = max(lv.start_date, date(year, month, 1))
            end_lv = min(lv.end_date, date(year, month, num_days))
            while curr <= end_lv:
                leaves_by_emp_date[(lv.employee_id, curr)] = lv
                curr += timedelta(days=1)

        new_records = []
        total_days = 0

        for emp in employees:
            shift = emp.shift or default_shift

            for day in range(1, num_days + 1):
                cur_date = date(year, month, day)
                total_days += 1

                existing = existing_map.get((emp.id, cur_date))
                if existing and existing.is_manual_override:
                    continue  # Giữ nguyên bản ghi quản lý đã sửa tay

                raw_day_logs = logs_by_user_day.get((emp.zk_user_id, cur_date), [])
                valid_logs = cls.debounce_logs(raw_day_logs, min_interval_seconds=settings.DEBOUNCE_SECONDS)

                # Tự động nhận diện ca thông minh theo giờ quẹt vào thực tế
                shift_to_use = emp.shift or default_shift
                if valid_logs and all_shifts:
                    shift_to_use = cls.match_best_shift(valid_logs[0].check_time, all_shifts, shift_to_use)

                cur_holiday = holiday_by_date.get(cur_date)
                cur_leave = leaves_by_emp_date.get((emp.id, cur_date))

                calc = cls._evaluate_day(
                    valid_logs=valid_logs,
                    shift=shift_to_use,
                    target_date=cur_date,
                    holiday=cur_holiday,
                    leave=cur_leave
                )

                if existing:
                    existing.shift_id = shift_to_use.id if shift_to_use else None
                    existing.first_check_in = calc["first_check_in"]
                    existing.last_check_out = calc["last_check_out"]
                    existing.late_minutes = calc["late_minutes"]
                    existing.early_leave_minutes = calc["early_leave_minutes"]
                    existing.standard_hours = calc["standard_hours"]
                    existing.ot_15_hours = calc["ot_15_hours"]
                    existing.ot_20_hours = calc["ot_20_hours"]
                    existing.ot_30_hours = calc.get("ot_30_hours", 0.0)
                    existing.work_units = calc["work_units"]
                    existing.status = calc["status"]
                    existing.leave_type = calc.get("leave_type")
                    if calc["notes"]:
                        existing.notes = calc["notes"]
                else:
                    new_rec = DailyAttendance(
                        attendance_date=cur_date,
                        employee_id=emp.id,
                        shift_id=shift_to_use.id if shift_to_use else None,
                        first_check_in=calc["first_check_in"],
                        last_check_out=calc["last_check_out"],
                        late_minutes=calc["late_minutes"],
                        early_leave_minutes=calc["early_leave_minutes"],
                        standard_hours=calc["standard_hours"],
                        ot_15_hours=calc["ot_15_hours"],
                        ot_20_hours=calc["ot_20_hours"],
                        ot_30_hours=calc.get("ot_30_hours", 0.0),
                        work_units=calc["work_units"],
                        status=calc["status"],
                        leave_type=calc.get("leave_type"),
                        notes=calc["notes"]
                    )
                    new_records.append(new_rec)

        if new_records:
            CHUNK = 1000
            for i in range(0, len(new_records), CHUNK):
                db.bulk_save_objects(new_records[i:i + CHUNK])

        db.commit()
        logger.info(f"Đã tính toán xong bảng công cho {len(employees)} nhân sự trong tháng {month}/{year}")
        return total_days
