import sqlite3
import os
import sys

def migrate_database(db_path="attendance.db"):
    if not os.path.exists(db_path):
        print(f"Database {db_path} does not exist.")
        return

    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    existing_cols = {col[1] for col in c.execute("PRAGMA table_info(employees)").fetchall()}
    print(f"Current columns in 'employees' table: {len(existing_cols)}")

    columns_to_add = [
        ("chinese_name", "VARCHAR(100)"),
        ("gender", "VARCHAR(10) DEFAULT 'Nam'"),
        ("birth_date", "DATE"),
        ("age", "INTEGER"),
        ("birth_place", "VARCHAR(100)"),
        ("nationality", "VARCHAR(100) DEFAULT 'Việt Nam'"),
        ("education", "VARCHAR(50)"),
        ("permanent_address", "VARCHAR(255)"),
        ("original_address", "VARCHAR(255)"),
        ("current_address", "VARCHAR(255)"),
        ("id_card_no", "VARCHAR(30)"),
        ("id_card_date", "DATE"),
        ("id_card_place", "VARCHAR(100)"),
        ("old_id_card_no", "VARCHAR(30)"),
        ("passport_no", "VARCHAR(50)"),
        ("passport_date", "DATE"),
        ("visa_date", "DATE"),
        ("work_permit_no", "VARCHAR(50)"),
        ("work_permit_date", "DATE"),
        ("work_permit_place", "VARCHAR(150)"),
        ("hospital", "VARCHAR(150)"),
        ("emergency_contact", "VARCHAR(255)"),
        ("workshop", "VARCHAR(100)"),
        ("status", "VARCHAR(50) DEFAULT 'active'"),
        ("contract_code", "VARCHAR(50)"),
        ("contract_type", "VARCHAR(100)"),
        ("contract_type_cn", "VARCHAR(100)"),
        ("contract_start_date", "DATE"),
        ("contract_end_date", "DATE"),
        ("contract_term_years", "VARCHAR(20)"),
        ("base_salary", "FLOAT DEFAULT 5315000.0"),
        ("allowance_position", "FLOAT DEFAULT 0.0"),
        ("probation_salary", "FLOAT"),
        ("official_salary", "FLOAT"),
        ("insurance_salary", "FLOAT DEFAULT 5315000.0"),
        ("social_insurance_no", "VARCHAR(50)"),
        ("insurance_increase_month", "VARCHAR(20)"),
        ("insurance_decrease_month", "VARCHAR(20)"),
        ("union_fee", "FLOAT DEFAULT 26575.0"),
        ("union_join_date", "DATE"),
        ("bank_techcombank", "VARCHAR(50)"),
        ("bank_acb", "VARCHAR(50)"),
        ("bank_vietcombank", "VARCHAR(50)"),
        ("bank_sacombank", "VARCHAR(50)"),
        ("uniform_status", "VARCHAR(50)"),
        ("shirt_size", "VARCHAR(20)"),
        ("shirt_color", "VARCHAR(20)"),
        ("referrer", "VARCHAR(150)"),
        ("maternity_leave_start", "DATE"),
        ("maternity_leave_end", "DATE"),
        ("maternity_off_month", "VARCHAR(20)"),
        ("maternity_on_month", "VARCHAR(20)"),
        ("child_birth_date", "DATE"),
        ("childcare_end_date", "DATE"),
        ("is_pregnant", "BOOLEAN DEFAULT 0"),
        ("pregnancy_start_date", "DATE"),
        ("resignation_date", "DATE"),
        ("resignation_reason", "VARCHAR(255)"),
        ("medical_fee_collected", "FLOAT DEFAULT 0.0"),
        ("contract_deduction", "FLOAT DEFAULT 0.0"),
        ("notes", "TEXT")
    ]

    added = 0
    for col_name, col_type in columns_to_add:
        if col_name not in existing_cols:
            query = f"ALTER TABLE employees ADD COLUMN {col_name} {col_type};"
            try:
                c.execute(query)
                added += 1
            except Exception as e:
                print(f"Error adding {col_name}: {e}")

    # Tạo index cho các cột tìm kiếm thường xuyên
    indexes = [
        ("idx_employees_chinese_name", "chinese_name"),
        ("idx_employees_id_card_no", "id_card_no"),
        ("idx_employees_passport_no", "passport_no"),
        ("idx_employees_status", "status"),
        ("idx_employees_workshop", "workshop")
    ]
    for idx_name, col in indexes:
        try:
            c.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON employees ({col});")
        except Exception as e:
            pass

    conn.commit()
    conn.close()
    print(f"Migration completed! Added {added} new columns to 'employees' table.")

if __name__ == "__main__":
    migrate_database()
