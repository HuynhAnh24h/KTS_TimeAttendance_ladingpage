import os
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    PROJECT_NAME: str = "Hệ thống Quản lý & Tính công Máy Chấm Công IP"
    VERSION: str = "2.0.0"
    API_PREFIX: str = "/api"
    
    # Mặc định sử dụng SQLite cục bộ giúp ứng dụng Desktop khởi động ngay lập tức không cần cài PostgreSQL.
    # Trong môi trường Enterprise, chỉ cần cấu hình DATABASE_URL=postgresql://user:password@localhost:5432/attendance_db
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./attendance.db")
    
    # Máy chấm công ZKTeco / Ronald Jack
    ZK_DEFAULT_PORT: int = 4370
    ZK_TIMEOUT: int = 5  # Giây timeout kết nối IP
    
    # Anti-passback debounce (giây) - bỏ qua quẹt thẻ trùng lặp dưới X giây
    DEBOUNCE_SECONDS: int = 300  # 5 phút
    
    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "*"
    ]

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()
