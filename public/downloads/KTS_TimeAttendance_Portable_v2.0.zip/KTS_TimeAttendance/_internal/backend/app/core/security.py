import os
import hmac
import json
import base64
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

# Khóa bí mật ký token xác thực
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "kts-cham-cong-secret-key-super-secure-production-2026")
TOKEN_EXPIRE_HOURS = 24 * 7  # 7 ngày

def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """
    Băm mật khẩu sử dụng PBKDF2-HMAC-SHA256 với 100,000 vòng lặp an toàn tuyệt đối.
    """
    if not salt:
        salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100000)
    return dk.hex(), salt

def verify_password(plain_password: str, hashed_password: str, salt: str) -> bool:
    """
    Xác thực mật khẩu người dùng nhập vào so với mật khẩu đã lưu.
    """
    dk, _ = hash_password(plain_password, salt)
    return hmac.compare_digest(dk, hashed_password)

def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """
    Tạo token phiên làm việc tự ký bằng HMAC-SHA256 chuẩn URL-safe.
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    to_encode.update({"exp": int(expire.timestamp())})
    
    payload_bytes = json.dumps(to_encode, separators=(",", ":")).encode("utf-8")
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).decode("utf-8").rstrip("=")
    
    signature = hmac.new(SECRET_KEY.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload_b64}.{signature}"

def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Giải mã và kiểm tra chữ ký cùng thời hạn sống của token.
    """
    try:
        parts = token.split(".")
        if len(parts) != 2:
            return None
        payload_b64, signature = parts
        
        expected_sig = hmac.new(SECRET_KEY.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected_sig):
            return None
        
        # Thêm padding nếu thiếu
        rem = len(payload_b64) % 4
        if rem > 0:
            payload_b64 += "=" * (4 - rem)
        
        payload_json = base64.urlsafe_b64decode(payload_b64.encode("utf-8")).decode("utf-8")
        data = json.loads(payload_json)
        
        # Kiểm tra hạn sử dụng
        if "exp" in data and datetime.utcnow().timestamp() > data["exp"]:
            return None
        
        return data
    except Exception:
        return None
