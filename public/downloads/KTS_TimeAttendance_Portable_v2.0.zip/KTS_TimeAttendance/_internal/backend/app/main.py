import os
import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# Khắc phục lỗi ConnectionResetError [WinError 10054] đặc trưng của Windows asyncio
# khi trình duyệt refresh hoặc đóng kết nối socket
if sys.platform == "win32":
    try:
        from asyncio.proactor_events import _ProactorBasePipeTransport
        _orig_call_connection_lost = _ProactorBasePipeTransport._call_connection_lost

        def _silenced_call_connection_lost(self, exc):
            try:
                _orig_call_connection_lost(self, exc)
            except (ConnectionResetError, OSError):
                pass

        _ProactorBasePipeTransport._call_connection_lost = _silenced_call_connection_lost
    except Exception:
        pass

import backend.app.models
from backend.app.core.config import settings
from backend.app.core.database import engine, Base, SessionLocal
from backend.app.api.router import api_router
from backend.app.seed_data import init_seed_data

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Khởi tạo bảng cơ sở dữ liệu nếu chưa tồn tại
    Base.metadata.create_all(bind=engine)
    
    # Nạp dữ liệu mẫu ban đầu
    db = SessionLocal()
    try:
        init_seed_data(db)
    finally:
        db.close()
        
    # Kích hoạt worker tự động đồng bộ ngầm máy chấm công định kỳ
    from backend.app.services.scheduler_service import AutoSyncScheduler
    scheduler = AutoSyncScheduler.get_instance()
    scheduler.start()

    yield

    # Dừng worker khi tắt ứng dụng
    scheduler.stop()

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan
)

# Cấu hình CORS để Frontend (React/Vite) gọi API thoải mái
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Gắn toàn bộ router nghiệp vụ
app.include_router(api_router, prefix=settings.API_PREFIX)

@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": "KTS_TimeAttendance", "version": settings.VERSION}

# Phục vụ file build Frontend (nếu đã build dist) để chạy trọn gói Desktop offline
def find_frontend_dist():
    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "dist"),
        os.path.join(getattr(sys, "_MEIPASS", ""), "frontend", "dist"),
        os.path.join(os.path.dirname(sys.executable), "_internal", "frontend", "dist"),
        os.path.join(os.path.dirname(sys.executable), "frontend", "dist"),
        os.path.abspath("frontend/dist"),
    ]
    for c in candidates:
        if c and os.path.exists(c) and os.path.exists(os.path.join(c, "index.html")):
            return os.path.abspath(c)
    return None

dist_path = find_frontend_dist()
if dist_path and os.path.exists(dist_path):
    app.mount("/assets", StaticFiles(directory=os.path.join(dist_path, "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        if full_path.startswith("api"):
            return None
        file_path = os.path.join(dist_path, full_path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(dist_path, "index.html"))
else:
    @app.get("/")
    def root():
        return {
            "app": settings.PROJECT_NAME,
            "version": settings.VERSION,
            "status": "Running",
            "api_docs": "/docs"
        }
