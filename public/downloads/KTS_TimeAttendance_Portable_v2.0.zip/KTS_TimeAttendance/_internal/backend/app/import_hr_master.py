import openpyxl
import datetime
import re
import sqlite3
import os
import sys

def parse_date(val):
    if val is None:
        return None
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y-%m-%d")
    val_str = str(val).strip()
    if not val_str or val_str.lower() in ("nan", "none", "00/01/1900", "0", "-"):
        return None
    
    # Try ISO YYYY-MM-DD
    m1 = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", val_str)
    if m1:
        y, m, d = int(m1.group(1)), int(m1.group(2)), int(m1.group(3))
        try:
            return datetime.date(y, m, d).strftime("%Y-%m-%d")
        except ValueError:
            pass

    # Try DD/MM/YYYY
    m2 = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})", val_str)
    if m2:
        d, m, y = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
        try:
            return datetime.date(y, m, d).strftime("%Y-%m-%d")
        except ValueError:
            pass

    return None

def parse_float(val):
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    val_str = str(val).strip()
    if not val_str or val_str.lower() in ("nan", "none", "-", "không"):
        return None
    
    # Extract only digits and decimal points
    cleaned = re.sub(r"[^\d.]", "", val_str.replace(",", ""))
    try:
        return float(cleaned)
    except Exception:
        return None

def parse_int(val):
    flt = parse_float(val)
    return int(flt) if flt is not None else None

def clean_str(val):
    if val is None:
        return None
    s = str(val).strip()
    if not s or s.lower() in ("nan", "none", "-", "null"):
        return None
    return s

def run_import(excel_path=r"C:\Users\Huynh Anh\.gemini\antigravity\brain\54f050a0-55d6-4227-80ac-861ec8f1d1bb\.user_uploaded\media_1793947415342_de5a05ce.xlsx", db_path="attendance.db"):
    if not os.path.exists(excel_path):
        print(f"Excel file {excel_path} not found.")
        return

    print("Opening Excel file:", excel_path)
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # 1. PROCESS TONG DS CN (Nhân viên hiện hữu / đang làm việc)
    ws_main = wb["TONG DS CN "]
    main_imported = 0
    print("Processing sheet: TONG DS CN ...")

    for r in range(2, ws_main.max_row + 1):
        emp_code = clean_str(ws_main.cell(row=r, column=2).value) # B: Mã NV
        full_name = clean_str(ws_main.cell(row=r, column=3).value) # C: Họ Tên
        if not emp_code or not full_name:
            continue
        if emp_code.startswith("000") or emp_code.isdigit():
            # Standardize numeric format if needed
            pass

        zk_id = emp_code.replace("KDB", "").lstrip("0") or emp_code
        chinese_name = clean_str(ws_main.cell(row=r, column=4).value) # D: Tên tiếng Hoa
        department = clean_str(ws_main.cell(row=r, column=5).value) or "Sản xuất" # E: Bộ phận
        position = clean_str(ws_main.cell(row=r, column=6).value) or "Công nhân" # F: Chức vụ
        workshop = clean_str(ws_main.cell(row=r, column=7).value) # G: Xưởng
        birth_date = parse_date(ws_main.cell(row=r, column=8).value) # H: Ngày sinh
        age = parse_int(ws_main.cell(row=r, column=9).value) # I: Tuổi
        gender = clean_str(ws_main.cell(row=r, column=10).value) or "Nam" # J: Giới tính
        birth_place = clean_str(ws_main.cell(row=r, column=11).value) # K: Nơi sinh
        permanent_address = clean_str(ws_main.cell(row=r, column=12).value) # L: Địa chỉ sau sáp nhập
        id_card_no = clean_str(ws_main.cell(row=r, column=13).value) # M: Số CCCD
        id_card_date = parse_date(ws_main.cell(row=r, column=14).value) # N: Ngày cấp
        id_card_place = clean_str(ws_main.cell(row=r, column=15).value) # O: Nơi cấp
        hire_date = parse_date(ws_main.cell(row=r, column=16).value) # P: Ngày vào làm
        contract_code = clean_str(ws_main.cell(row=r, column=17).value) # Q: Mã HĐ
        contract_start = parse_date(ws_main.cell(row=r, column=18).value) # R: Từ ngày
        contract_end = parse_date(ws_main.cell(row=r, column=19).value) # S: Đến ngày
        contract_type = clean_str(ws_main.cell(row=r, column=24).value) # X: Loại HĐ
        contract_type_cn = clean_str(ws_main.cell(row=r, column=25).value) # Y: Loại HĐTH
        education = clean_str(ws_main.cell(row=r, column=26).value) # Z: Học vấn
        phone = clean_str(ws_main.cell(row=r, column=27).value) # AA: Điện thoại
        base_salary = parse_float(ws_main.cell(row=r, column=28).value) or 5315000.0 # AB: Lương cơ bản
        allowance_position = parse_float(ws_main.cell(row=r, column=29).value) or 0.0 # AC: PC chức vụ
        insurance_salary = parse_float(ws_main.cell(row=r, column=30).value) or base_salary # AD: Lương đóng BH
        union_fee = parse_float(ws_main.cell(row=r, column=31).value) or 26575.0 # AE: Công đoàn
        union_join_date = parse_date(ws_main.cell(row=r, column=32).value) # AF: Ngày vào CĐ
        insurance_increase_month = clean_str(ws_main.cell(row=r, column=33).value) # AG: Báo tăng
        social_insurance_no = clean_str(ws_main.cell(row=r, column=34).value) # AH: Mã số BHXH
        old_id_card_no = clean_str(ws_main.cell(row=r, column=35).value) # AI: Số CMND
        emergency_contact = clean_str(ws_main.cell(row=r, column=36).value) # AJ: Số ĐT người thân
        bank_techcombank = clean_str(ws_main.cell(row=r, column=37).value) # AK: STK Techcombank
        bank_acb = clean_str(ws_main.cell(row=r, column=38).value) # AL: STK ACB
        probation_salary = parse_float(ws_main.cell(row=r, column=39).value) # AM: Lương thử việc
        official_salary = parse_float(ws_main.cell(row=r, column=40).value) # AN: Tổng lương chính thức
        original_address = clean_str(ws_main.cell(row=r, column=41).value) # AO: Địa chỉ trước sáp nhập
        uniform_status = clean_str(ws_main.cell(row=r, column=42).value) # AP: Đồng phục
        shirt_size = clean_str(ws_main.cell(row=r, column=43).value) # AQ: Size áo
        shirt_color = clean_str(ws_main.cell(row=r, column=44).value) # AR: Màu áo
        referrer = clean_str(ws_main.cell(row=r, column=45).value) # AS: Người giới thiệu
        maternity_leave_start = parse_date(ws_main.cell(row=r, column=48).value) # AV: Ngày nghỉ sinh
        maternity_leave_end = parse_date(ws_main.cell(row=r, column=49).value) # AW: Ngày vào làm lại
        maternity_off_month = clean_str(ws_main.cell(row=r, column=50).value) # AX: OF Thai sản
        maternity_on_month = clean_str(ws_main.cell(row=r, column=51).value) # AY: ON Đi làm lại
        child_birth_date = parse_date(ws_main.cell(row=r, column=52).value) # AZ: Ngày sinh con
        childcare_end_date = parse_date(ws_main.cell(row=r, column=53).value) # BA: Ngày hết nuôi con nhỏ
        notes = clean_str(ws_main.cell(row=r, column=54).value) # BB: Ký tên / note
        contract_term_years = clean_str(ws_main.cell(row=r, column=55).value) # BC: Thời hạn HĐ

        status = "active"
        if maternity_leave_start or maternity_off_month:
            status = "maternity"
        elif childcare_end_date:
            status = "childcare"
        elif contract_code and "TV" in contract_code:
            status = "probation"

        # Check if already exists by employee_code
        existing = c.execute("SELECT id FROM employees WHERE employee_code = ?", (emp_code,)).fetchone()
        if existing:
            c.execute("""
                UPDATE employees SET
                    full_name=?, chinese_name=?, department=?, position=?, workshop=?,
                    birth_date=?, age=?, gender=?, birth_place=?, permanent_address=?, original_address=?,
                    id_card_no=?, id_card_date=?, id_card_place=?, old_id_card_no=?,
                    hire_date=?, contract_code=?, contract_type=?, contract_type_cn=?,
                    contract_start_date=?, contract_end_date=?, contract_term_years=?,
                    education=?, phone=?, base_salary=?, allowance_position=?,
                    insurance_salary=?, union_fee=?, union_join_date=?, insurance_increase_month=?,
                    social_insurance_no=?, emergency_contact=?, bank_techcombank=?, bank_acb=?,
                    probation_salary=?, official_salary=?, uniform_status=?, shirt_size=?, shirt_color=?,
                    referrer=?, maternity_leave_start=?, maternity_leave_end=?, maternity_off_month=?,
                    maternity_on_month=?, child_birth_date=?, childcare_end_date=?,
                    notes=?, is_active=1, status=?
                WHERE id = ?
            """, (
                full_name, chinese_name, department, position, workshop,
                birth_date, age, gender, birth_place, permanent_address, original_address,
                id_card_no, id_card_date, id_card_place, old_id_card_no,
                hire_date, contract_code, contract_type, contract_type_cn,
                contract_start, contract_end, contract_term_years,
                education, phone, base_salary, allowance_position,
                insurance_salary, union_fee, union_join_date, insurance_increase_month,
                social_insurance_no, emergency_contact, bank_techcombank, bank_acb,
                probation_salary, official_salary, uniform_status, shirt_size, shirt_color,
                referrer, maternity_leave_start, maternity_leave_end, maternity_off_month,
                maternity_on_month, child_birth_date, childcare_end_date,
                notes, status, existing[0]
            ))
        else:
            # Check zk_user_id conflict
            chk_zk = c.execute("SELECT id FROM employees WHERE zk_user_id = ?", (zk_id,)).fetchone()
            if chk_zk:
                zk_id = f"{zk_id}_{emp_code}"

            c.execute("""
                INSERT INTO employees (
                    zk_user_id, employee_code, full_name, chinese_name, department, position, workshop,
                    birth_date, age, gender, birth_place, permanent_address, original_address,
                    id_card_no, id_card_date, id_card_place, old_id_card_no,
                    hire_date, contract_code, contract_type, contract_type_cn,
                    contract_start_date, contract_end_date, contract_term_years,
                    education, phone, base_salary, allowance_position,
                    insurance_salary, union_fee, union_join_date, insurance_increase_month,
                    social_insurance_no, emergency_contact, bank_techcombank, bank_acb,
                    probation_salary, official_salary, uniform_status, shirt_size, shirt_color,
                    referrer, maternity_leave_start, maternity_leave_end, maternity_off_month,
                    maternity_on_month, child_birth_date, childcare_end_date,
                    notes, is_active, status
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, 1, ?
                )
            """, (
                zk_id, emp_code, full_name, chinese_name, department, position, workshop,
                birth_date, age, gender, birth_place, permanent_address, original_address,
                id_card_no, id_card_date, id_card_place, old_id_card_no,
                hire_date, contract_code, contract_type, contract_type_cn,
                contract_start, contract_end, contract_term_years,
                education, phone, base_salary, allowance_position,
                insurance_salary, union_fee, union_join_date, insurance_increase_month,
                social_insurance_no, emergency_contact, bank_techcombank, bank_acb,
                probation_salary, official_salary, uniform_status, shirt_size, shirt_color,
                referrer, maternity_leave_start, maternity_leave_end, maternity_off_month,
                maternity_on_month, child_birth_date, childcare_end_date,
                notes, status
            ))
        main_imported += 1

    print(f"-> Processed {main_imported} active employees from TONG DS CN.")

    # 2. PROCESS TRUNG QUOC / TQ NV (Chuyên gia & Chủ quản nước ngoài)
    print("Processing sheet: TRUNG QUOC...")
    ws_tq = wb["TRUNG QUOC"]
    tq_imported = 0
    for r in range(2, ws_tq.max_row + 1):
        raw_code = clean_str(ws_tq.cell(row=r, column=2).value)
        full_name = clean_str(ws_tq.cell(row=r, column=3).value)
        if not full_name:
            continue
        emp_code = raw_code if raw_code and raw_code.startswith("KDB") else f"TQ{str(raw_code or r-1).zfill(3)}"
        zk_id = emp_code.replace("KDB", "").replace("TQ", "9").lstrip("0") or emp_code

        dept = clean_str(ws_tq.cell(row=r, column=4).value) or "Quản lý / Chuyên gia"
        pos = clean_str(ws_tq.cell(row=r, column=5).value) or "Chủ quản"
        nationality = clean_str(ws_tq.cell(row=r, column=6).value) or "Trung Quốc"
        dob = parse_date(ws_tq.cell(row=r, column=7).value)
        age = parse_int(ws_tq.cell(row=r, column=8).value)
        pob = clean_str(ws_tq.cell(row=r, column=9).value) or "Trung Quốc"
        gender = clean_str(ws_tq.cell(row=r, column=10).value) or "Nam"
        passport_no = clean_str(ws_tq.cell(row=r, column=11).value)
        passport_date = parse_date(ws_tq.cell(row=r, column=12).value)
        visa_date = parse_date(ws_tq.cell(row=r, column=13).value)
        work_permit_date = parse_date(ws_tq.cell(row=r, column=14).value)
        work_permit_no = clean_str(ws_tq.cell(row=r, column=15).value)
        work_permit_place = clean_str(ws_tq.cell(row=r, column=16).value)
        hire_date = parse_date(ws_tq.cell(row=r, column=17).value)
        contract_code = clean_str(ws_tq.cell(row=r, column=18).value)
        contract_start = parse_date(ws_tq.cell(row=r, column=19).value)
        contract_end = parse_date(ws_tq.cell(row=r, column=20).value)
        contract_type = clean_str(ws_tq.cell(row=r, column=25).value)
        contract_type_cn = clean_str(ws_tq.cell(row=r, column=26).value)
        shirt_size = clean_str(ws_tq.cell(row=r, column=32).value)
        uniform_status = clean_str(ws_tq.cell(row=r, column=33).value)
        insurance_salary = parse_float(ws_tq.cell(row=r, column=34).value)
        social_insurance_no = clean_str(ws_tq.cell(row=r, column=36).value)
        hospital = clean_str(ws_tq.cell(row=r, column=37).value)
        phone = clean_str(ws_tq.cell(row=r, column=38).value)
        bank_vietcombank = clean_str(ws_tq.cell(row=r, column=39).value)
        bank_sacombank = clean_str(ws_tq.cell(row=r, column=40).value)

        # Check existing
        existing = c.execute("SELECT id FROM employees WHERE employee_code = ? OR (full_name = ? AND nationality = 'Trung Quốc')", (emp_code, full_name)).fetchone()
        if existing:
            c.execute("""
                UPDATE employees SET
                    nationality=?, passport_no=?, passport_date=?, visa_date=?,
                    work_permit_no=?, work_permit_date=?, work_permit_place=?,
                    hospital=?, bank_vietcombank=?, bank_sacombank=?,
                    status='foreign_expert', is_active=1
                WHERE id = ?
            """, (
                nationality, passport_no, passport_date, visa_date,
                work_permit_no, work_permit_date, work_permit_place,
                hospital, bank_vietcombank, bank_sacombank, existing[0]
            ))
        else:
            chk_zk = c.execute("SELECT id FROM employees WHERE zk_user_id = ?", (zk_id,)).fetchone()
            if chk_zk:
                zk_id = f"{zk_id}_{emp_code}"

            c.execute("""
                INSERT INTO employees (
                    zk_user_id, employee_code, full_name, department, position,
                    nationality, birth_date, age, birth_place, gender,
                    passport_no, passport_date, visa_date, work_permit_no,
                    work_permit_date, work_permit_place, hire_date,
                    contract_code, contract_type, contract_type_cn, contract_start_date, contract_end_date,
                    shirt_size, uniform_status, insurance_salary, social_insurance_no,
                    hospital, phone, bank_vietcombank, bank_sacombank,
                    is_active, status
                ) VALUES (
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    1, 'foreign_expert'
                )
            """, (
                zk_id, emp_code, full_name, dept, pos,
                nationality, dob, age, pob, gender,
                passport_no, passport_date, visa_date, work_permit_no,
                work_permit_date, work_permit_place, hire_date,
                contract_code, contract_type, contract_type_cn, contract_start, contract_end,
                shirt_size, uniform_status, insurance_salary, social_insurance_no,
                hospital, phone, bank_vietcombank, bank_sacombank
            ))
        tq_imported += 1

    print(f"-> Processed {tq_imported} foreign experts.")

    # 3. PROCESS THAI SAN (Chế độ Con nhỏ & Thai sản)
    print("Processing sheet: THAI SAN...")
    ws_ts = wb["THAI SAN"]
    ts_updated = 0
    for r in range(4, ws_ts.max_row + 1):
        emp_code = clean_str(ws_ts.cell(row=r, column=6).value)
        if not emp_code:
            continue
        maternity_start = parse_date(ws_ts.cell(row=r, column=2).value)
        maternity_end = parse_date(ws_ts.cell(row=r, column=3).value)
        child_dob = parse_date(ws_ts.cell(row=r, column=8).value)
        childcare_end = parse_date(ws_ts.cell(row=r, column=9).value)

        # Update matching employee
        c.execute("""
            UPDATE employees SET
                maternity_leave_start = COALESCE(?, maternity_leave_start),
                maternity_leave_end = COALESCE(?, maternity_leave_end),
                child_birth_date = COALESCE(?, child_birth_date),
                childcare_end_date = COALESCE(?, childcare_end_date),
                status = CASE WHEN status = 'resigned' THEN 'resigned' ELSE 'childcare' END
            WHERE employee_code = ?
        """, (maternity_start, maternity_end, child_dob, childcare_end, emp_code))
        ts_updated += 1

    print(f"-> Updated {ts_updated} maternity / childcare records.")

    # 4. PROCESS NGHI VIEC (Nhân viên đã thôi việc)
    print("Processing sheet: NGHI VIEC...")
    ws_nv = wb["NGHI VIEC"]
    nv_updated = 0
    for r in range(2, ws_nv.max_row + 1):
        emp_code = clean_str(ws_nv.cell(row=r, column=8).value) or clean_str(ws_nv.cell(row=r, column=1).value)
        if not emp_code or emp_code == "0" or emp_code == "None":
            continue
        
        reason = clean_str(ws_nv.cell(row=r, column=4).value)
        medical_fee = parse_float(ws_nv.cell(row=r, column=5).value) or 0.0
        ins_dec_month = clean_str(ws_nv.cell(row=r, column=6).value)
        resignation_date = parse_date(ws_nv.cell(row=r, column=7).value)

        existing = c.execute("SELECT id FROM employees WHERE employee_code = ?", (emp_code,)).fetchone()
        if existing:
            c.execute("""
                UPDATE employees SET
                    is_active = 0,
                    status = 'resigned',
                    resignation_date = ?,
                    resignation_reason = ?,
                    medical_fee_collected = ?,
                    insurance_decrease_month = ?
                WHERE id = ?
            """, (resignation_date, reason, medical_fee, ins_dec_month, existing[0]))
            nv_updated += 1
        else:
            # Add resigned employee with info in sheet
            full_name = clean_str(ws_nv.cell(row=r, column=9).value) or clean_str(ws_nv.cell(row=r, column=2).value)
            if full_name:
                zk_id = emp_code.replace("KDB", "").lstrip("0") or emp_code
                chk_zk = c.execute("SELECT id FROM employees WHERE zk_user_id = ?", (zk_id,)).fetchone()
                if chk_zk:
                    zk_id = f"{zk_id}_{emp_code}"

                c.execute("""
                    INSERT INTO employees (
                        zk_user_id, employee_code, full_name, department, position,
                        is_active, status, resignation_date, resignation_reason,
                        medical_fee_collected, insurance_decrease_month
                    ) VALUES (
                        ?, ?, ?, 'Đã Nghỉ Việc', 'Cựu nhân viên',
                        0, 'resigned', ?, ?,
                        ?, ?
                    )
                """, (zk_id, emp_code, full_name, resignation_date, reason, medical_fee, ins_dec_month))
                nv_updated += 1

    print(f"-> Processed {nv_updated} resigned employee records.")

    conn.commit()
    conn.close()
    print("Master HR import successfully completed!")

if __name__ == "__main__":
    run_import()
