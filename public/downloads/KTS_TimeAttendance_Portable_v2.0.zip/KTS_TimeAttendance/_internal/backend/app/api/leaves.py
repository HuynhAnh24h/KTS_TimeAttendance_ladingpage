from datetime import date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import extract

from backend.app.core.database import get_db
from backend.app.models.employee import Employee
from backend.app.models.leave_request import LeaveRequest
from backend.app.schemas.leave_holiday import LeaveRequestCreate, LeaveRequestUpdate, LeaveRequestOut
from backend.app.api.auth import get_current_user_optional
from backend.app.models.user import User

router = APIRouter(prefix="/leaves", tags=["Leaves"])

LEAVE_TYPE_META = [
    {"code": "ANNUAL", "name": "Nghỉ Phép Năm", "symbol": "P", "is_paid": True, "description": "Hưởng 100% lương theo Luật Lao Động"},
    {"code": "SICK", "name": "Nghỉ Ốm Đau (BHXH)", "symbol": "Ô", "is_paid": False, "description": "Chế độ ốm đau do Cơ quan BHXH chi trả"},
    {"code": "MATERNITY", "name": "Nghỉ Thai Sản (BHXH)", "symbol": "TS", "is_paid": False, "description": "Chế độ thai sản do BHXH chi trả"},
    {"code": "MARRIAGE", "name": "Việc Riêng Hưởng Lương", "symbol": "VR", "is_paid": True, "description": "Kết hôn (3 ngày), con kết hôn (1 ngày), tang chế (3 ngày)"},
    {"code": "UNPAID", "name": "Nghỉ Không Hưởng Lương", "symbol": "Ro", "is_paid": False, "description": "Nghỉ có phép nhưng không hưởng lương"},
    {"code": "BUSINESS_TRIP", "name": "Đi Công Tác Ngoài", "symbol": "CT", "is_paid": True, "description": "Đi công tác theo lệnh công ty, tính đủ 1.0 công"}
]

@router.get("/types")
def get_leave_types():
    """
    Trả về danh mục các loại nghỉ phép chuẩn Việt Nam kèm ký hiệu hiển thị trên bảng công.
    """
    return LEAVE_TYPE_META

@router.get("", response_model=List[LeaveRequestOut])
def get_leave_requests(
    year: Optional[int] = Query(None),
    month: Optional[int] = Query(None),
    department: Optional[str] = Query(None),
    employee_id: Optional[int] = Query(None),
    leave_type: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(LeaveRequest).join(Employee)

    if employee_id:
        query = query.filter(LeaveRequest.employee_id == employee_id)
    if department and department != "Tất cả":
        query = query.filter(Employee.department == department)
    if leave_type and leave_type != "Tất cả":
        query = query.filter(LeaveRequest.leave_type == leave_type)
    if year:
        query = query.filter(
            (extract('year', LeaveRequest.start_date) == year) |
            (extract('year', LeaveRequest.end_date) == year)
        )
    if month:
        query = query.filter(
            (extract('month', LeaveRequest.start_date) == month) |
            (extract('month', LeaveRequest.end_date) == month)
        )

    records = query.order_by(LeaveRequest.start_date.desc()).all()
    results = []
    for r in records:
        out = LeaveRequestOut(
            id=r.id,
            employee_id=r.employee_id,
            leave_type=r.leave_type,
            start_date=r.start_date,
            end_date=r.end_date,
            half_day_type=r.half_day_type,
            reason=r.reason,
            status=r.status,
            approved_by=r.approved_by,
            created_at=r.created_at,
            employee_code=r.employee.employee_code if r.employee else None,
            employee_name=r.employee.full_name if r.employee else None,
            department=r.employee.department if r.employee else None
        )
        results.append(out)
    return results

@router.post("", response_model=LeaveRequestOut)
def create_leave_request(data: LeaveRequestCreate, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == data.employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên này")
    if data.end_date < data.start_date:
        raise HTTPException(status_code=400, detail="Ngày kết thúc không thể trước ngày bắt đầu")

    req = LeaveRequest(
        employee_id=data.employee_id,
        leave_type=data.leave_type,
        start_date=data.start_date,
        end_date=data.end_date,
        half_day_type=data.half_day_type,
        reason=data.reason,
        status=data.status,
        approved_by=data.approved_by or "Quản trị viên"
    )
    db.add(req)
    db.commit()
    db.refresh(req)

    return LeaveRequestOut(
        id=req.id,
        employee_id=req.employee_id,
        leave_type=req.leave_type,
        start_date=req.start_date,
        end_date=req.end_date,
        half_day_type=req.half_day_type,
        reason=req.reason,
        status=req.status,
        approved_by=req.approved_by,
        created_at=req.created_at,
        employee_code=emp.employee_code,
        employee_name=emp.full_name,
        department=emp.department
    )

@router.put("/{leave_id}", response_model=LeaveRequestOut)
def update_leave_request(leave_id: int, data: LeaveRequestUpdate, db: Session = Depends(get_db)):
    req = db.query(LeaveRequest).filter(LeaveRequest.id == leave_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn nghỉ phép")

    update_data = data.model_dump(exclude_unset=True)
    for field, val in update_data.items():
        setattr(req, field, val)

    if req.end_date < req.start_date:
        raise HTTPException(status_code=400, detail="Ngày kết thúc không thể trước ngày bắt đầu")

    db.commit()
    db.refresh(req)

    return LeaveRequestOut(
        id=req.id,
        employee_id=req.employee_id,
        leave_type=req.leave_type,
        start_date=req.start_date,
        end_date=req.end_date,
        half_day_type=req.half_day_type,
        reason=req.reason,
        status=req.status,
        approved_by=req.approved_by,
        created_at=req.created_at,
        employee_code=req.employee.employee_code if req.employee else None,
        employee_name=req.employee.full_name if req.employee else None,
        department=req.employee.department if req.employee else None
    )

@router.delete("/{leave_id}")
def delete_leave_request(leave_id: int, db: Session = Depends(get_db)):
    req = db.query(LeaveRequest).filter(LeaveRequest.id == leave_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn nghỉ phép")
    db.delete(req)
    db.commit()
    return {"success": True, "message": "Đã xóa đơn nghỉ phép thành công"}

@router.get("/quota-summary")
def get_leave_quota_summary(
    year: int = Query(default=date.today().year),
    department: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Bảng tổng hợp theo dõi Phép Năm và Nghỉ chế độ theo Luật Lao Động Việt Nam:
    - Tiêu chuẩn phép năm: 12 ngày/năm + thâm niên (cứ 5 năm làm việc + 1 ngày phép).
    - Thống kê chi tiết: Số ngày phép năm đã dùng, Số ngày còn lại, Nghỉ ốm (Ô), Nghỉ không lương (Ro).
    """
    emp_query = db.query(Employee).filter(Employee.is_active == True)
    if department and department != "Tất cả":
        emp_query = emp_query.filter(Employee.department == department)
    employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

    # Lấy toàn bộ đơn nghỉ phép đã duyệt trong năm
    from datetime import timedelta
    start_of_year = date(year, 1, 1)
    end_of_year = date(year, 12, 31)

    leaves = db.query(LeaveRequest).filter(
        LeaveRequest.status == "APPROVED",
        LeaveRequest.start_date <= end_of_year,
        LeaveRequest.end_date >= start_of_year
    ).all()

    # Tính số ngày phép của từng đơn
    emp_leaves_map = {}
    for lv in leaves:
        if lv.employee_id not in emp_leaves_map:
            emp_leaves_map[lv.employee_id] = []
        emp_leaves_map[lv.employee_id].append(lv)

    results = []
    for emp in employees:
        # Tiêu chuẩn phép năm: Cơ bản 12 ngày + Thâm niên
        seniority_bonus = 0
        if emp.hire_date:
            years_worked = max(0, year - emp.hire_date.year)
            seniority_bonus = years_worked // 5
        total_quota = 12.0 + seniority_bonus

        emp_leaves = emp_leaves_map.get(emp.id, [])
        annual_used = 0.0
        sick_days = 0.0
        unpaid_days = 0.0
        marriage_days = 0.0

        for lv in emp_leaves:
            # Tính số ngày nằm trong năm được chọn
            s = max(lv.start_date, start_of_year)
            e = min(lv.end_date, end_of_year)
            if s > e:
                continue
            day_count = (e - s).days + 1
            if lv.half_day_type in ["MORNING", "AFTERNOON"]:
                weight = 0.5
            else:
                weight = 1.0
            total_days_for_leave = day_count * weight

            if lv.leave_type == "ANNUAL":
                annual_used += total_days_for_leave
            elif lv.leave_type in ["SICK", "MATERNITY"]:
                sick_days += total_days_for_leave
            elif lv.leave_type == "UNPAID":
                unpaid_days += total_days_for_leave
            elif lv.leave_type in ["MARRIAGE", "BUSINESS_TRIP"]:
                marriage_days += total_days_for_leave

        remaining = max(0.0, total_quota - annual_used)

        results.append({
            "employee_id": emp.id,
            "employee_code": emp.employee_code,
            "full_name": emp.full_name,
            "department": emp.department,
            "position": emp.position,
            "hire_date": emp.hire_date.isoformat() if emp.hire_date else None,
            "total_quota": total_quota,
            "annual_used": round(annual_used, 1),
            "remaining": round(remaining, 1),
            "sick_days": round(sick_days, 1),
            "unpaid_days": round(unpaid_days, 1),
            "marriage_days": round(marriage_days, 1)
        })

    return {
        "year": year,
        "department": department or "Tất cả",
        "total_employees": len(results),
        "data": results
    }

