from typing import Optional
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.models.settings import SystemSetting
from backend.app.models.user import User
from backend.app.api.auth import require_roles, get_current_user

router = APIRouter(prefix="/settings", tags=["System Settings"])

class SystemSettingSchema(BaseModel):
    id: Optional[int] = 1
    company_name: str = "CÔNG TY TNHH KỸ THUẬT SỐ KTS"
    company_address: str = "Khu Công Nghiệp, TP. Hồ Chí Minh"
    company_phone: str = "0908 123 456"
    company_tax_id: str = "0312345678"
    standard_working_days: float = 26.0
    daily_working_hours: float = 8.0
    late_grace_minutes: int = 5
    early_grace_minutes: int = 5
    ot_normal_rate: float = 1.5
    ot_sunday_rate: float = 2.0
    ot_holiday_rate: float = 3.0
    night_shift_bonus_rate: float = 0.3
    auto_calculate_on_sync: bool = True

    class Config:
        from_attributes = True

def get_or_create_settings(db: Session) -> SystemSetting:
    setting = db.query(SystemSetting).filter(SystemSetting.id == 1).first()
    if not setting:
        setting = SystemSetting(id=1)
        db.add(setting)
        db.commit()
        db.refresh(setting)
    return setting

@router.get("", response_model=SystemSettingSchema)
def get_settings(db: Session = Depends(get_db)):
    """
    Lấy thông tin cấu hình công ty và quy chế tính công hiện tại.
    """
    return get_or_create_settings(db)

@router.put("", response_model=SystemSettingSchema)
def update_settings(
    payload: SystemSettingSchema,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Cập nhật cấu hình công ty và quy chế (Chỉ dành cho Admin).
    """
    setting = get_or_create_settings(db)
    
    setting.company_name = payload.company_name
    setting.company_address = payload.company_address
    setting.company_phone = payload.company_phone
    setting.company_tax_id = payload.company_tax_id
    setting.standard_working_days = max(1.0, payload.standard_working_days)
    setting.daily_working_hours = max(1.0, payload.daily_working_hours)
    setting.late_grace_minutes = max(0, payload.late_grace_minutes)
    setting.early_grace_minutes = max(0, payload.early_grace_minutes)
    setting.ot_normal_rate = max(1.0, payload.ot_normal_rate)
    setting.ot_sunday_rate = max(1.0, payload.ot_sunday_rate)
    setting.ot_holiday_rate = max(1.0, payload.ot_holiday_rate)
    setting.night_shift_bonus_rate = max(0.0, payload.night_shift_bonus_rate)
    setting.auto_calculate_on_sync = payload.auto_calculate_on_sync

    db.commit()
    db.refresh(setting)
    return setting
