import os
import sys
import re
import urllib.parse
import unicodedata
import subprocess
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.models.employee import Employee
from backend.app.models.payroll import SalaryConfig, PayrollRecord
from backend.app.models.user import User
from backend.app.schemas.payroll import (
    PayrollRecordOut, PayrollRecordUpdate,
    PayrollSummaryResponse, PayrollCalculateRequest,
    SalaryConfigOut, SalaryConfigUpdate
)
from backend.app.services.payroll_service import PayrollService
from backend.app.api.auth import get_current_user_optional, require_roles

router = APIRouter(prefix="/payroll", tags=["Payroll"])

def _sanitize_ascii_filename(text: str) -> str:
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = ''.join(c for c in nfkd if not unicodedata.combining(c))
    ascii_text = ascii_text.replace('đ', 'd').replace('Đ', 'D')
    return re.sub(r'[^a-zA-Z0-9_.-]', '_', ascii_text)

@router.get("/records", response_model=PayrollSummaryResponse)
def get_payroll_records(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Lấy danh sách bảng lương tháng kèm các chỉ số KPI tài chính tổng quan:
    - Tổng quỹ lương Gross & Net
    - Tổng giờ tăng ca & tiền tăng ca (1.5x, 2.0x, 3.0x)
    - Tổng tạm ứng & Trích nộp BHXH
    """
    dept_val = department if (department and department != "Tất cả") else None

    query = db.query(PayrollRecord).join(Employee).filter(
        PayrollRecord.year == year,
        PayrollRecord.month == month
    )
    if dept_val:
        query = query.filter(Employee.department == dept_val)

    records = query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

    # Nếu tháng này chưa từng được tính, tự động kích hoạt tính lần đầu
    if not records:
        records = PayrollService.calculate_monthly_payroll(db, year, month, dept_val)

    # Tổng hợp chỉ số KPI
    total_gross = sum(r.gross_salary for r in records)
    total_net = sum(r.net_salary for r in records)
    total_ot_hours = sum(r.ot_normal_hours + r.ot_sunday_hours + r.ot_holiday_hours for r in records)
    total_ot_salary = sum(r.total_ot_salary for r in records)
    total_advance = sum(r.advance_amount for r in records)
    total_ins = sum(r.insurance_deduction for r in records)

    out_records = []
    for r in records:
        emp = r.employee
        out = PayrollRecordOut(
            id=r.id,
            employee_id=r.employee_id,
            employee_code=emp.employee_code if emp else "",
            employee_name=emp.full_name if emp else "",
            department=emp.department if emp else "",
            position=emp.position if emp else "",
            year=r.year,
            month=r.month,
            standard_days=r.standard_days,
            actual_work_days=r.actual_work_days,
            paid_leave_days=r.paid_leave_days,
            holiday_days=r.holiday_days,
            total_paid_days=r.total_paid_days,
            ot_normal_hours=r.ot_normal_hours,
            ot_sunday_hours=r.ot_sunday_hours,
            ot_holiday_hours=r.ot_holiday_hours,
            night_shift_hours=r.night_shift_hours,
            base_salary=r.base_salary,
            day_rate=r.day_rate,
            hour_rate=r.hour_rate,
            salary_by_work_days=r.salary_by_work_days,
            salary_ot_normal=r.salary_ot_normal,
            salary_ot_sunday=r.salary_ot_sunday,
            salary_ot_holiday=r.salary_ot_holiday,
            salary_night_bonus=r.salary_night_bonus,
            total_ot_salary=r.total_ot_salary,
            allowance_diligence=r.allowance_diligence,
            allowance_meal=r.allowance_meal,
            allowance_transport=r.allowance_transport,
            allowance_hazardous=r.allowance_hazardous,
            allowance_position=r.allowance_position,
            total_allowance=r.total_allowance,
            gross_salary=r.gross_salary,
            advance_amount=r.advance_amount,
            insurance_deduction=r.insurance_deduction,
            other_deduction=r.other_deduction,
            total_deductions=r.total_deductions,
            net_salary=r.net_salary,
            notes=r.notes,
            status=r.status,
            updated_at=r.updated_at
        )
        out_records.append(out)

    return PayrollSummaryResponse(
        year=year,
        month=month,
        department=department or "Tất cả",
        total_employees=len(records),
        total_gross_payroll=round(total_gross, 0),
        total_net_payroll=round(total_net, 0),
        total_ot_hours=round(total_ot_hours, 1),
        total_ot_salary=round(total_ot_salary, 0),
        total_advance_amount=round(total_advance, 0),
        total_insurance_deduction=round(total_ins, 0),
        records=out_records
    )

@router.post("/calculate", response_model=PayrollSummaryResponse)
def calculate_payroll(
    req: PayrollCalculateRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Tính lại bảng lương tháng tự động theo dữ liệu chấm công mới nhất.
    """
    dept = req.department
    dept_val = dept if (dept and dept != "Tất cả") else None
    PayrollService.calculate_monthly_payroll(db, req.year, req.month, dept_val)
    return get_payroll_records(year=req.year, month=req.month, department=dept, db=db, current_user=current_user)

@router.put("/records/{record_id}", response_model=PayrollRecordOut)
def update_payroll_record(
    record_id: int,
    payload: PayrollRecordUpdate,
    db: Session = Depends(get_db)
):
    """
    Cập nhật số tiền tạm ứng, khoản khấu trừ khác hoặc ghi chú cho một nhân viên.
    """
    rec = db.query(PayrollRecord).filter(PayrollRecord.id == record_id).first()
    if not rec:
        raise HTTPException(status_code=404, detail="Không tìm thấy bản ghi lương.")

    if payload.advance_amount is not None:
        rec.advance_amount = payload.advance_amount
    if payload.other_deduction is not None:
        rec.other_deduction = payload.other_deduction
    if payload.notes is not None:
        rec.notes = payload.notes
    if payload.status is not None:
        rec.status = payload.status

    rec.total_deductions = rec.advance_amount + rec.insurance_deduction + rec.other_deduction
    rec.net_salary = max(0.0, round(rec.gross_salary - rec.total_deductions, 0))
    rec.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(rec)

    emp = rec.employee
    return PayrollRecordOut(
        id=rec.id,
        employee_id=rec.employee_id,
        employee_code=emp.employee_code if emp else "",
        employee_name=emp.full_name if emp else "",
        department=emp.department if emp else "",
        position=emp.position if emp else "",
        year=rec.year,
        month=rec.month,
        standard_days=rec.standard_days,
        actual_work_days=rec.actual_work_days,
        paid_leave_days=rec.paid_leave_days,
        holiday_days=rec.holiday_days,
        total_paid_days=rec.total_paid_days,
        ot_normal_hours=rec.ot_normal_hours,
        ot_sunday_hours=rec.ot_sunday_hours,
        ot_holiday_hours=rec.ot_holiday_hours,
        night_shift_hours=rec.night_shift_hours,
        base_salary=rec.base_salary,
        day_rate=rec.day_rate,
        hour_rate=rec.hour_rate,
        salary_by_work_days=rec.salary_by_work_days,
        salary_ot_normal=rec.salary_ot_normal,
        salary_ot_sunday=rec.salary_ot_sunday,
        salary_ot_holiday=rec.salary_ot_holiday,
        salary_night_bonus=rec.salary_night_bonus,
        total_ot_salary=rec.total_ot_salary,
        allowance_diligence=rec.allowance_diligence,
        allowance_meal=rec.allowance_meal,
        allowance_transport=rec.allowance_transport,
        allowance_hazardous=rec.allowance_hazardous,
        allowance_position=rec.allowance_position,
        total_allowance=rec.total_allowance,
        gross_salary=rec.gross_salary,
        advance_amount=rec.advance_amount,
        insurance_deduction=rec.insurance_deduction,
        other_deduction=rec.other_deduction,
        total_deductions=rec.total_deductions,
        net_salary=rec.net_salary,
        notes=rec.notes,
        status=rec.status,
        updated_at=rec.updated_at
    )

@router.get("/config/{employee_id}", response_model=SalaryConfigOut)
def get_salary_config(employee_id: int, db: Session = Depends(get_db)):
    """
    Lấy cấu hình lương cơ bản & phụ cấp của nhân viên.
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên.")
    cfg = PayrollService.get_or_create_salary_config(db, emp)
    return SalaryConfigOut(
        id=cfg.id,
        employee_id=cfg.employee_id,
        base_salary=cfg.base_salary,
        allowance_diligence=cfg.allowance_diligence,
        allowance_meal=cfg.allowance_meal,
        allowance_transport=cfg.allowance_transport,
        allowance_hazardous=cfg.allowance_hazardous,
        allowance_position=cfg.allowance_position,
        insurance_rate=cfg.insurance_rate,
        total_allowance=cfg.to_dict()["total_allowance"]
    )

@router.put("/config/{employee_id}", response_model=SalaryConfigOut)
def update_salary_config(
    employee_id: int,
    payload: SalaryConfigUpdate,
    db: Session = Depends(get_db)
):
    """
    Cập nhật lương cơ bản hoặc mức phụ cấp của nhân viên.
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên.")
    cfg = PayrollService.get_or_create_salary_config(db, emp)

    if payload.base_salary is not None:
        cfg.base_salary = payload.base_salary
    if payload.allowance_diligence is not None:
        cfg.allowance_diligence = payload.allowance_diligence
    if payload.allowance_meal is not None:
        cfg.allowance_meal = payload.allowance_meal
    if payload.allowance_transport is not None:
        cfg.allowance_transport = payload.allowance_transport
    if payload.allowance_hazardous is not None:
        cfg.allowance_hazardous = payload.allowance_hazardous
    if payload.allowance_position is not None:
        cfg.allowance_position = payload.allowance_position
    if payload.insurance_rate is not None:
        cfg.insurance_rate = payload.insurance_rate

    db.commit()
    db.refresh(cfg)
    return SalaryConfigOut(
        id=cfg.id,
        employee_id=cfg.employee_id,
        base_salary=cfg.base_salary,
        allowance_diligence=cfg.allowance_diligence,
        allowance_meal=cfg.allowance_meal,
        allowance_transport=cfg.allowance_transport,
        allowance_hazardous=cfg.allowance_hazardous,
        allowance_position=cfg.allowance_position,
        insurance_rate=cfg.insurance_rate,
        total_allowance=cfg.to_dict()["total_allowance"]
    )

@router.get("/export-excel")
def export_payroll_excel(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Tải file Excel Bảng Lương tháng trực tiếp qua HTTP.
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = PayrollService.export_payroll_excel(db, year, month, dept_val)
    dept_suffix = f"_{department.replace(' ', '_')}" if dept_val else ""
    filename = f"Bang_Luong_Thang_{month}_{year}{dept_suffix}.xlsx"

    ascii_filename = _sanitize_ascii_filename(filename)
    quoted_filename = urllib.parse.quote(filename)
    headers = {
        "Content-Disposition": f'attachment; filename="{ascii_filename}"; filename*=UTF-8\'\'{quoted_filename}',
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Access-Control-Expose-Headers": "Content-Disposition"
    }
    return StreamingResponse(excel_stream, headers=headers)

@router.post("/export-excel-file")
def export_payroll_excel_file_to_desktop(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = Query(default=None),
    open_file: bool = Query(default=True),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Xuất file Excel Bảng Lương ra thư mục Desktop / Exports và tự động mở file ngay lập tức.
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = PayrollService.export_payroll_excel(db, year, month, dept_val)

    desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
    export_dir = os.path.join(desktop_dir, "Bao_Cao_Cham_Cong") if os.path.exists(desktop_dir) else os.path.abspath("exports")
    os.makedirs(export_dir, exist_ok=True)

    dept_suffix = f"_{_sanitize_ascii_filename(department)}" if dept_val else ""
    filename = f"Bang_Luong_Thang_{month}_{year}{dept_suffix}.xlsx"
    file_path = os.path.join(export_dir, filename)

    with open(file_path, "wb") as f:
        f.write(excel_stream.getvalue())

    opened = False
    if open_file:
        try:
            if sys.platform == "win32":
                os.startfile(file_path)
                opened = True
            elif sys.platform == "darwin":
                subprocess.Popen(["open", file_path])
                opened = True
            else:
                subprocess.Popen(["xdg-open", file_path])
                opened = True
        except Exception:
            pass

    return {
        "success": True,
        "message": f"Đã xuất bảng lương thành công tại: {file_path}",
        "file_path": file_path,
        "opened": opened
    }
