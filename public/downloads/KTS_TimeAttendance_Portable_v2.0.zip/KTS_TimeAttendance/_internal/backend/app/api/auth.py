from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Header, status
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.models.user import User
from backend.app.schemas.auth import LoginRequest, TokenResponse, UserOut, ChangePasswordRequest
from backend.app.core.security import verify_password, hash_password, create_access_token, decode_access_token

router = APIRouter(prefix="/auth", tags=["Authentication"])

def get_current_user_optional(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
) -> Optional[User]:
    """
    Lấy thông tin người dùng từ token Bearer (không bắt buộc).
    Nếu không có token hoặc token không hợp lệ, trả về None.
    """
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.split(" ")[1]
    payload = decode_access_token(token)
    if not payload or "sub" not in payload:
        return None
    user_id = payload["sub"]
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    return user

def get_current_user(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
) -> User:
    """
    Bắt buộc phải đăng nhập. Nếu chưa đăng nhập hoặc token hết hạn -> 401 Unauthorized.
    """
    user = get_current_user_optional(authorization, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Phiên đăng nhập không hợp lệ hoặc đã hết hạn. Vui lòng đăng nhập lại.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

def require_roles(allowed_roles: List[str]):
    """
    Dependency kiểm tra quyền hạn (RBAC):
    Ví dụ: Depends(require_roles(["admin", "accountant"]))
    Tài khoản 'superadmin' tự động có toàn quyền tối cao đối với mọi chức năng.
    """
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role in ["superadmin", "admin"]:
            return current_user
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Tài khoản của bạn ({current_user.role}) không có quyền thực hiện thao tác này."
            )
        return current_user
    return role_checker

@router.post("/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    """
    Xác thực tài khoản và trả về JWT Bearer Token.
    """
    user = db.query(User).filter(User.username == data.username).first()
    if not user or not verify_password(data.password, user.hashed_password, user.salt):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tên đăng nhập hoặc mật khẩu không chính xác."
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tài khoản đã bị tạm khóa. Vui lòng liên hệ Quản trị viên."
        )

    # Cập nhật thời gian đăng nhập
    user.last_login = datetime.utcnow()
    db.commit()
    db.refresh(user)

    token_data = {
        "sub": user.id,
        "username": user.username,
        "role": user.role,
    }
    token = create_access_token(token_data)

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user)
    )

@router.get("/me", response_model=UserOut)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """
    Lấy thông tin người dùng đang đăng nhập trong phiên làm việc hiện tại.
    """
    return current_user

@router.post("/change-password")
def change_password(
    data: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Đổi mật khẩu cho người dùng hiện tại sau khi xác thực mật khẩu cũ.
    """
    if not verify_password(data.current_password, current_user.hashed_password, current_user.salt):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Mật khẩu hiện tại không chính xác."
        )
    
    hashed_pwd, salt = hash_password(data.new_password)
    current_user.hashed_password = hashed_pwd
    current_user.salt = salt
    db.commit()
    
    return {"message": "Đổi mật khẩu thành công!"}

