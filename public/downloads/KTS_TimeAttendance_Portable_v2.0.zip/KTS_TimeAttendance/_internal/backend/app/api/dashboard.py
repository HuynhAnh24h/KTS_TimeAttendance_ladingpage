from datetime import date, datetime, timedelta, time
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.app.core.database import get_db
from backend.app.models.employee import Employee
from backend.app.models.device import Device
from backend.app.models.daily_attendance import DailyAttendance
from backend.app.models.attendance_log import RawAttendanceLog
from backend.app.schemas.dashboard import DashboardSummary, RecentPunchItem

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/summary", response_model=DashboardSummary)
def get_dashboard_summary(db: Session = Depends(get_db)):
    today = date.today()

    total_emp = db.query(func.count(Employee.id)).scalar() or 0
    active_emp = db.query(func.count(Employee.id)).filter(Employee.is_active == True).scalar() or 0

    today_records = db.query(DailyAttendance).filter(DailyAttendance.attendance_date == today).all()

    working_today = sum(1 for r in today_records if r.work_units > 0)
    late_today = sum(1 for r in today_records if r.late_minutes > 0)
    ot_count_today = sum(1 for r in today_records if (r.ot_15_hours + r.ot_20_hours) > 0)
    absent_today = max(0, active_emp - working_today)

    devices_total = db.query(func.count(Device.id)).scalar() or 0
    devices_online = db.query(func.count(Device.id)).filter(Device.status == "ONLINE").scalar() or 0

    # Lấy 10 lần quẹt thẻ gần nhất
    recent_logs = db.query(
        RawAttendanceLog, Employee.full_name, Employee.department, Device.name
    ).outerjoin(
        Employee, Employee.zk_user_id == RawAttendanceLog.zk_user_id
    ).outerjoin(
        Device, Device.id == RawAttendanceLog.device_id
    ).order_by(
        RawAttendanceLog.check_time.desc()
    ).limit(10).all()

    recent_punches = []
    punch_type_names = {
        0: "Chấm Vào (Check In)",
        1: "Chấm Ra (Check Out)",
        2: "Nghỉ Giữa Ca",
        3: "Vào Giữa Ca",
        4: "Bắt Đầu OT",
        5: "Kết Thúc OT"
    }

    for log, emp_name, dept, dev_name in recent_logs:
        recent_punches.append(RecentPunchItem(
            id=log.id,
            zk_user_id=log.zk_user_id,
            employee_name=emp_name or f"Chưa Đăng Ký ({log.zk_user_id})",
            department=dept or "Chưa phân bổ",
            check_time=log.check_time,
            device_name=dev_name or "Máy Chấm Công",
            punch_type_desc=punch_type_names.get(log.punch_state, "Quẹt thẻ")
        ))

    return DashboardSummary(
        today_date=today.strftime("%d/%m/%Y"),
        total_employees=total_emp,
        active_employees=active_emp,
        working_today=working_today,
        late_today=late_today,
        absent_today=absent_today,
        ot_count_today=ot_count_today,
        devices_online=devices_online,
        devices_total=devices_total,
        recent_punches=recent_punches
    )
