import os
import shutil
import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from backend.app.core.database import get_db, SessionLocal
from backend.app.models.employee import Employee
from backend.app.models.daily_attendance import DailyAttendance
from backend.app.models.attendance_log import RawAttendanceLog
from backend.app.models.payroll import PayrollRecord, SalaryConfig
from backend.app.models.user import User
from backend.app.models.device import Device
from backend.app.models.biometric_template import BiometricTemplate
from backend.app.models.leave_request import LeaveRequest
from backend.app.models.settings import SystemSetting
from backend.app.services.license_service import LicenseService
from backend.app.api.auth import require_roles

router = APIRouter(prefix="/system", tags=["System & Database Management"])

def get_current_db_path() -> str:
    db_url = os.environ.get("DATABASE_URL", "sqlite:///attendance.db")
    if db_url.startswith("sqlite:///"):
        path = db_url.replace("sqlite:///", "")
        return os.path.abspath(path)
    return os.path.abspath("attendance.db")

def get_backups_dir() -> str:
    data_dir = os.environ.get("DATA_DIR", os.path.dirname(get_current_db_path()))
    backup_dir = os.path.join(data_dir, "backups")
    os.makedirs(backup_dir, exist_ok=True)
    return backup_dir

@router.get("/stats")
def get_system_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Thông tin thống kê hệ thống, tình trạng CSDL và bản quyền.
    """
    db_path = get_current_db_path()
    size_bytes = os.path.getsize(db_path) if os.path.exists(db_path) else 0
    size_mb = round(size_bytes / (1024 * 1024), 2)

    license_info = LicenseService.get_license_status()

    # Thống kê bản ghi
    total_emp = db.query(Employee).count()
    total_att = db.query(DailyAttendance).count()
    total_punches = db.query(RawAttendanceLog).count()
    total_payroll = db.query(PayrollRecord).count()
    total_users = db.query(User).count()
    total_devices = db.query(Device).count()

    # Danh sách các bản sao lưu gần nhất
    backup_dir = get_backups_dir()
    backup_files = []
    if os.path.exists(backup_dir):
        for fname in sorted(os.listdir(backup_dir), reverse=True):
            if fname.endswith((".db", ".bak", ".sqlite")):
                fpath = os.path.join(backup_dir, fname)
                fsize_kb = round(os.path.getsize(fpath) / 1024, 1)
                mtime = datetime.fromtimestamp(os.path.getmtime(fpath)).strftime("%Y-%m-%d %H:%M:%S")
                backup_files.append({
                    "filename": fname,
                    "size_kb": fsize_kb,
                    "created_at": mtime
                })

    return {
        "db_path": db_path,
        "db_size_mb": size_mb,
        "db_size_bytes": size_bytes,
        "total_employees": total_emp,
        "total_daily_attendance": total_att,
        "total_punches": total_punches,
        "total_payroll": total_payroll,
        "total_users": total_users,
        "total_devices": total_devices,
        "license": license_info,
        "backups": backup_files[:10]
    }

@router.post("/backup")
def create_backup(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Thực hiện sao lưu an toàn CSDL SQLite trực tuyến (Non-blocking Snapshot).
    Lưu vào thư mục backups/ và tự động copy vào thư mục Downloads của người dùng.
    """
    src_db = get_current_db_path()
    if not os.path.exists(src_db):
        raise HTTPException(status_code=404, detail="Không tìm thấy file CSDL nguồn.")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"KTS_Attendance_Backup_{timestamp}.db"
    backup_dir = get_backups_dir()
    dest_path = os.path.join(backup_dir, backup_filename)

    try:
        # Sử dụng SQLite backup API để sao lưu an toàn khi server đang chạy
        src_conn = sqlite3.connect(src_db)
        dest_conn = sqlite3.connect(dest_path)
        with dest_conn:
            src_conn.backup(dest_conn)
        dest_conn.close()
        src_conn.close()

        # Copy thêm vào thư mục Downloads của máy người dùng nếu có
        user_downloads = os.path.join(os.path.expanduser("~"), "Downloads")
        saved_to_downloads = False
        downloads_file_path = None
        if os.path.exists(user_downloads):
            downloads_file_path = os.path.join(user_downloads, backup_filename)
            try:
                shutil.copy2(dest_path, downloads_file_path)
                saved_to_downloads = True
            except Exception:
                pass

        return {
            "success": True,
            "filename": backup_filename,
            "backup_path": dest_path,
            "download_url": f"/api/system/download-backup?filename={backup_filename}",
            "saved_to_downloads": saved_to_downloads,
            "downloads_file_path": downloads_file_path,
            "size_kb": round(os.path.getsize(dest_path) / 1024, 1),
            "message": f"Sao lưu CSDL thành công: {backup_filename}"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi khi sao lưu CSDL: {str(e)}")

@router.get("/download-backup")
def download_backup_file(
    filename: str = Query(..., description="Tên file backup cần tải về"),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Tải file sao lưu CSDL về máy qua trình duyệt.
    """
    backup_dir = get_backups_dir()
    file_path = os.path.join(backup_dir, os.path.basename(filename))
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File sao lưu không tồn tại.")

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/octet-stream"
    )

@router.post("/restore")
async def restore_database(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Khôi phục CSDL từ file sao lưu .db do người dùng tải lên.
    Có cơ chế tự động tạo điểm khôi phục dự phòng trước khi thay thế.
    """
    if not file.filename.endswith((".db", ".sqlite", ".bak")):
        raise HTTPException(
            status_code=400,
            detail="File không hợp lệ. Vui lòng chọn file CSDL SQLite có đuôi .db, .sqlite hoặc .bak"
        )

    content = await file.read()
    if len(content) < 100:
        raise HTTPException(status_code=400, detail="File CSDL quá nhỏ hoặc bị lỗi rỗng.")

    # 1. Kiểm tra header SQLite hợp lệ (16 bytes đầu tiên phải là 'SQLite format 3\x00')
    if not content.startswith(b"SQLite format 3\x00"):
        raise HTTPException(status_code=400, detail="File tải lên không phải là định dạng CSDL SQLite hợp lệ!")

    # 2. Lưu file tạm và kiểm tra cấu trúc bảng bắt buộc
    temp_path = os.path.join(get_backups_dir(), f"temp_restore_{datetime.now().strftime('%Y%m%d%H%M%S')}.db")
    with open(temp_path, "wb") as f:
        f.write(content)

    try:
        chk_conn = sqlite3.connect(temp_path)
        cursor = chk_conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        chk_conn.close()

        required_tables = ["employees", "users", "shifts"]
        missing_tables = [t for t in required_tables if t not in tables]
        if missing_tables:
            os.remove(temp_path)
            raise HTTPException(
                status_code=400,
                detail=f"File CSDL thiếu các bảng quan trọng: {', '.join(missing_tables)}. Không thể khôi phục file này!"
            )

        # 3. Tạo bản sao lưu khẩn cấp của CSDL hiện tại trước khi ghi đè
        active_db_path = get_current_db_path()
        if os.path.exists(active_db_path):
            rollback_path = os.path.join(
                get_backups_dir(),
                f"KTS_Emergency_PreRestore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
            )
            shutil.copy2(active_db_path, rollback_path)

        # 4. Ghi đè vào CSDL hoạt động
        shutil.copy2(temp_path, active_db_path)
        os.remove(temp_path)

        return {
            "success": True,
            "message": "Đã khôi phục CSDL thành công! Hệ thống đã nhận diện lại toàn bộ dữ liệu.",
            "restored_tables_count": len(tables)
        }
    except HTTPException:
        raise
    except Exception as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise HTTPException(status_code=500, detail=f"Lỗi trong quá trình khôi phục: {str(e)}")

@router.post("/clear-attendance")
def clear_attendance_data(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Xóa sạch toàn bộ dữ liệu nhật ký quẹt thẻ, bảng công hàng ngày và bảng lương.
    Giữ nguyên toàn bộ danh sách nhân sự, ca làm việc và cài đặt hệ thống.
    """
    try:
        # Tự động tạo snapshot dự phòng trước khi xóa
        create_backup(db=db, current_user=current_user)

        del_punches = db.query(RawAttendanceLog).delete()
        del_att = db.query(DailyAttendance).delete()
        del_payroll = db.query(PayrollRecord).delete()
        db.commit()

        return {
            "success": True,
            "message": f"Đã xóa sạch dữ liệu chấm công: {del_punches} lượt quẹt thẻ, {del_att} ngày công, {del_payroll} bảng lương. Danh sách nhân sự vẫn được giữ nguyên.",
            "deleted_punches": del_punches,
            "deleted_daily_attendance": del_att,
            "deleted_payroll": del_payroll
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Lỗi xóa dữ liệu chấm công: {str(e)}")

@router.post("/reset-to-clean")
def reset_to_clean_slate(
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    KHỞI TẠO DỮ LIỆU TRẮNG THƯƠNG MẠI (COMMERCIAL CLEAN SLATE):
    Xóa toàn bộ hồ sơ nhân viên mẫu, bảng công, nhật ký quẹt thẻ, mẫu vân tay.
    Đặt lại tên doanh nghiệp và danh sách phòng ban về trạng thái xuất xưởng.
    Hệ thống trở thành bản cài đặt trắng 100%, sẵn sàng triển khai cho khách hàng mới.
    """
    confirmation = payload.get("confirmation", "").strip().upper()
    if confirmation != "XACNHAN":
        raise HTTPException(
            status_code=400,
            detail="Vui lòng nhập chính xác từ khóa 'XACNHAN' để thực hiện thao tác xóa trắng hệ thống."
        )

    try:
        # 1. Tự động backup snapshot khẩn cấp
        create_backup(db=db, current_user=current_user)

        # 2. Xóa các bảng liên quan đến nhân sự và chấm công
        db.query(RawAttendanceLog).delete()
        db.query(DailyAttendance).delete()
        db.query(PayrollRecord).delete()
        db.query(SalaryConfig).delete()
        db.query(BiometricTemplate).delete()
        db.query(LeaveRequest).delete()
        del_emps = db.query(Employee).delete()

        # 3. Cập nhật thông tin công ty về trạng thái mặc định nếu có
        new_company_name = payload.get("company_name", "DOANH NGHIỆP CỦA BẠN").strip()
        comp_setting = db.query(SystemSetting).filter(SystemSetting.id == 1).first()
        if comp_setting:
            comp_setting.company_name = new_company_name
        else:
            comp_setting = SystemSetting(id=1, company_name=new_company_name)
            db.add(comp_setting)

        db.commit()

        return {
            "success": True,
            "message": f"Hệ thống đã được khởi tạo về trạng thái trắng thương mại thành công! Đã xóa {del_emps} nhân sự mẫu và toàn bộ dữ liệu chấm công cũ. Sẵn sàng bàn giao khách hàng mới.",
            "deleted_employees": del_emps
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Lỗi khởi tạo dữ liệu trắng: {str(e)}")

