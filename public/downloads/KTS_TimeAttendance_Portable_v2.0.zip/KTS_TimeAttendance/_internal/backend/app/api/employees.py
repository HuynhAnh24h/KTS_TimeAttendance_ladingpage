from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_, func, case
from typing import List, Optional

from backend.app.core.database import get_db
from backend.app.models.employee import Employee
from backend.app.schemas.employee import (
    EmployeeCreate,
    EmployeeUpdate,
    EmployeeOut,
    EmployeeStatsSummary,
    EmployeeImportResult
)
from backend.app.services.excel_service import ExcelService

router = APIRouter(prefix="/employees", tags=["Employees"])

@router.get("", response_model=List[EmployeeOut])
def get_employees(
    department: Optional[str] = None,
    workshop: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    search: Optional[str] = None,
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Employee)
    
    # Department filter
    if department and department != "Tất cả":
        query = query.filter(Employee.department == department)
        
    # Workshop filter
    if workshop and workshop != "Tất cả":
        query = query.filter(Employee.workshop == workshop)
        
    # Active filter
    if is_active is not None:
        query = query.filter(Employee.is_active == is_active)
        
    # Status category filter
    if status_filter and status_filter != "all":
        if status_filter == "active":
            query = query.filter(Employee.is_active == True)
        elif status_filter == "probation":
            query = query.filter(
                or_(
                    Employee.status == "probation",
                    Employee.contract_code.ilike("%TV%"),
                    Employee.contract_type.ilike("%thử việc%")
                )
            )
        elif status_filter == "maternity_childcare":
            query = query.filter(
                or_(
                    Employee.status.in_(["maternity", "childcare", "pregnant"]),
                    Employee.maternity_leave_start.isnot(None),
                    Employee.childcare_end_date.isnot(None),
                    Employee.is_pregnant == True
                )
            )
        elif status_filter == "foreign_expert":
            query = query.filter(
                or_(
                    Employee.status == "foreign_expert",
                    Employee.nationality == "Trung Quốc",
                    Employee.passport_no.isnot(None)
                )
            )
        elif status_filter == "resigned":
            query = query.filter(
                or_(
                    Employee.is_active == False,
                    Employee.status == "resigned",
                    Employee.resignation_date.isnot(None)
                )
            )
        else:
            query = query.filter(Employee.status == status_filter)

    # Search filter across multiple relevant columns
    if search:
        s = f"%{search.strip()}%"
        query = query.filter(
            or_(
                Employee.full_name.ilike(s),
                Employee.chinese_name.ilike(s),
                Employee.employee_code.ilike(s),
                Employee.zk_user_id.ilike(s),
                Employee.id_card_no.ilike(s),
                Employee.passport_no.ilike(s),
                Employee.phone.ilike(s),
                Employee.department.ilike(s),
                Employee.position.ilike(s)
            )
        )

    return query.order_by(Employee.is_active.desc(), Employee.id.asc()).all()

@router.get("/stats/summary", response_model=EmployeeStatsSummary)
def get_employee_stats(db: Session = Depends(get_db)):
    total = db.query(func.count(Employee.id)).scalar() or 0
    active = db.query(func.count(Employee.id)).filter(Employee.is_active == True).scalar() or 0
    resigned = db.query(func.count(Employee.id)).filter(Employee.is_active == False).scalar() or 0
    
    probation = db.query(func.count(Employee.id)).filter(
        Employee.is_active == True,
        or_(
            Employee.status == "probation",
            Employee.contract_code.ilike("%TV%"),
            Employee.contract_type.ilike("%thử việc%")
        )
    ).scalar() or 0

    maternity_childcare = db.query(func.count(Employee.id)).filter(
        Employee.is_active == True,
        or_(
            Employee.status.in_(["maternity", "childcare", "pregnant"]),
            Employee.maternity_leave_start.isnot(None),
            Employee.childcare_end_date.isnot(None),
            Employee.is_pregnant == True
        )
    ).scalar() or 0

    foreign_expert = db.query(func.count(Employee.id)).filter(
        Employee.is_active == True,
        or_(
            Employee.status == "foreign_expert",
            Employee.nationality == "Trung Quốc",
            Employee.passport_no.isnot(None)
        )
    ).scalar() or 0

    # Department distribution (active only)
    dept_rows = db.query(Employee.department, func.count(Employee.id)).filter(
        Employee.is_active == True
    ).group_by(Employee.department).all()
    dept_counts = {row[0]: row[1] for row in dept_rows if row[0]}

    # Workshop distribution (active only)
    ws_rows = db.query(Employee.workshop, func.count(Employee.id)).filter(
        Employee.is_active == True,
        Employee.workshop.isnot(None)
    ).group_by(Employee.workshop).all()
    ws_counts = {row[0]: row[1] for row in ws_rows if row[0]}

    return EmployeeStatsSummary(
        total_employees=total,
        active_employees=active,
        probation_employees=probation,
        resigned_employees=resigned,
        maternity_childcare_count=maternity_childcare,
        foreign_expert_count=foreign_expert,
        department_counts=dept_counts,
        workshop_counts=ws_counts
    )

@router.get("/departments", response_model=List[str])
def get_departments(active_only: bool = True, db: Session = Depends(get_db)):
    query = db.query(Employee.department)
    if active_only:
        query = query.filter(Employee.is_active == True)
    departments = query.distinct().order_by(Employee.department.asc()).all()
    return [d[0] for d in departments if d[0] and d[0] != "Đã Nghỉ Việc"]

@router.get("/workshops", response_model=List[str])
def get_workshops(active_only: bool = True, db: Session = Depends(get_db)):
    query = db.query(Employee.workshop)
    if active_only:
        query = query.filter(Employee.is_active == True)
    workshops = query.distinct().order_by(Employee.workshop.asc()).all()
    return [w[0] for w in workshops if w[0]]

@router.get("/{employee_id}", response_model=EmployeeOut)
def get_employee(employee_id: int, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên")
    return emp

@router.post("", response_model=EmployeeOut, status_code=status.HTTP_201_CREATED)
def create_employee(payload: EmployeeCreate, db: Session = Depends(get_db)):
    # Validate unique code and zk_user_id
    if db.query(Employee).filter(Employee.employee_code == payload.employee_code).first():
        raise HTTPException(status_code=400, detail=f"Mã nhân viên {payload.employee_code} đã tồn tại")
    if db.query(Employee).filter(Employee.zk_user_id == payload.zk_user_id).first():
        raise HTTPException(status_code=400, detail=f"Mã chấm công (ZK ID) {payload.zk_user_id} đã tồn tại")

    emp = Employee(**payload.model_dump())
    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp

@router.put("/{employee_id}", response_model=EmployeeOut)
def update_employee(employee_id: int, payload: EmployeeUpdate, db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên")

    data = payload.model_dump(exclude_unset=True)
    if "employee_code" in data and data["employee_code"] != emp.employee_code:
        if db.query(Employee).filter(Employee.employee_code == data["employee_code"]).first():
            raise HTTPException(status_code=400, detail=f"Mã nhân viên {data['employee_code']} đã tồn tại")
    if "zk_user_id" in data and data["zk_user_id"] != emp.zk_user_id:
        if db.query(Employee).filter(Employee.zk_user_id == data["zk_user_id"]).first():
            raise HTTPException(status_code=400, detail=f"Mã chấm công {data['zk_user_id']} đã tồn tại")

    for k, v in data.items():
        setattr(emp, k, v)

    db.commit()
    db.refresh(emp)
    return emp

@router.delete("/{employee_id}")
def delete_employee(
    employee_id: int,
    delete_on_device: bool = False,
    db: Session = Depends(get_db)
):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên")
    
    zk_id = emp.zk_user_id
    device_deleted = False

    if delete_on_device:
        from backend.app.models.device import Device
        from backend.app.services.zk_sync_service import ZkSyncService
        devices = db.query(Device).filter(Device.is_active == True).all()
        for dev in devices:
            try:
                res = ZkSyncService.delete_user_from_device(dev.id, zk_id)
                if res.get("success"):
                    device_deleted = True
            except Exception:
                pass

    # Xóa sạch các bản ghi phụ thuộc để đảm bảo toàn vẹn dữ liệu
    from backend.app.models.daily_attendance import DailyAttendance
    from backend.app.models.leave_request import LeaveRequest
    from backend.app.models.payroll import SalaryConfig, MonthlyPayroll
    from backend.app.models.biometric_template import BiometricTemplate

    db.query(DailyAttendance).filter(DailyAttendance.employee_id == emp.id).delete(synchronize_session=False)
    db.query(LeaveRequest).filter(LeaveRequest.employee_id == emp.id).delete(synchronize_session=False)
    db.query(SalaryConfig).filter(SalaryConfig.employee_id == emp.id).delete(synchronize_session=False)
    db.query(MonthlyPayroll).filter(MonthlyPayroll.employee_id == emp.id).delete(synchronize_session=False)
    if delete_on_device and zk_id:
        db.query(BiometricTemplate).filter(BiometricTemplate.zk_user_id == zk_id).delete(synchronize_session=False)

    emp_name = emp.full_name
    db.delete(emp)
    db.commit()
    msg = f"Đã xóa nhân viên {emp_name} thành công"
    if delete_on_device and device_deleted:
        msg += " (Đã xóa đồng thời trên máy chấm công)"
    return {"message": msg, "device_deleted": device_deleted}

@router.post("/batch-delete")
def batch_delete_employees(
    payload: dict,
    db: Session = Depends(get_db)
):
    """
    Xóa hàng loạt nhiều nhân viên cùng lúc khỏi phần mềm.
    Có tùy chọn delete_on_device để xóa sạch trên cả máy chấm công.
    """
    employee_ids = payload.get("employee_ids", [])
    delete_on_device = payload.get("delete_on_device", False)

    if not employee_ids:
        raise HTTPException(status_code=400, detail="Chưa chọn nhân viên nào để xóa.")

    employees = db.query(Employee).filter(Employee.id.in_(employee_ids)).all()
    count = len(employees)
    emp_ids = [e.id for e in employees]
    zk_ids = [e.zk_user_id for e in employees if e.zk_user_id]

    if delete_on_device:
        from backend.app.models.device import Device
        from backend.app.services.zk_sync_service import ZkSyncService
        devices = db.query(Device).filter(Device.is_active == True).all()
        for zk_id in zk_ids:
            for dev in devices:
                try:
                    ZkSyncService.delete_user_from_device(dev.id, zk_id)
                except Exception:
                    pass

    from backend.app.models.daily_attendance import DailyAttendance
    from backend.app.models.leave_request import LeaveRequest
    from backend.app.models.payroll import SalaryConfig, MonthlyPayroll
    from backend.app.models.biometric_template import BiometricTemplate

    db.query(DailyAttendance).filter(DailyAttendance.employee_id.in_(emp_ids)).delete(synchronize_session=False)
    db.query(LeaveRequest).filter(LeaveRequest.employee_id.in_(emp_ids)).delete(synchronize_session=False)
    db.query(SalaryConfig).filter(SalaryConfig.employee_id.in_(emp_ids)).delete(synchronize_session=False)
    db.query(MonthlyPayroll).filter(MonthlyPayroll.employee_id.in_(emp_ids)).delete(synchronize_session=False)
    if delete_on_device and zk_ids:
        db.query(BiometricTemplate).filter(BiometricTemplate.zk_user_id.in_(zk_ids)).delete(synchronize_session=False)

    for emp in employees:
        db.delete(emp)

    db.commit()
    return {
        "success": True,
        "message": f"Đã xóa thành công {count} nhân viên.",
        "deleted_count": count
    }

@router.post("/pull-from-device")
def pull_employees_from_device(
    payload: dict,
    db: Session = Depends(get_db)
):
    """
    Kéo trực tiếp danh sách nhân viên từ một máy chấm công IP về phần mềm.
    """
    device_id = payload.get("device_id")
    default_dept = payload.get("department", "Nhân viên mới")
    
    if not device_id:
        raise HTTPException(status_code=400, detail="Thiếu ID máy chấm công.")

    from backend.app.services.zk_sync_service import ZkSyncService
    res = ZkSyncService.pull_users_from_device(db=db, device_id=device_id, default_department=default_dept)
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi kéo nhân viên từ máy chấm công"))
    return res

@router.get("/departments/manage")
def get_departments_manage(db: Session = Depends(get_db)):
    """
    Lấy danh sách các phòng ban kèm theo số lượng nhân sự hiện tại.
    """
    rows = db.query(
        Employee.department,
        func.count(Employee.id).label("total_count"),
        func.sum(case((Employee.is_active == True, 1), else_=0)).label("active_count")
    ).group_by(Employee.department).all()

    return [
        {
            "name": r[0] or "Chưa phân ban",
            "total_count": r[1] or 0,
            "active_count": r[2] or 0
        }
        for r in rows if r[0] and r[0] != "Đã Nghỉ Việc"
    ]

@router.post("/departments/rename")
def rename_department(
    payload: dict,
    db: Session = Depends(get_db)
):
    """
    Đổi tên phòng ban / bộ phận hàng loạt cho toàn bộ nhân sự.
    """
    old_name = payload.get("old_name", "").strip()
    new_name = payload.get("new_name", "").strip()

    if not old_name or not new_name:
        raise HTTPException(status_code=400, detail="Vui lòng điền tên phòng ban cũ và mới.")

    updated_count = db.query(Employee).filter(Employee.department == old_name).update(
        {Employee.department: new_name},
        synchronize_session=False
    )
    db.commit()

    return {
        "success": True,
        "message": f"Đã đổi tên phòng ban '{old_name}' thành '{new_name}' cho {updated_count} nhân sự.",
        "updated_count": updated_count
    }

@router.post("/import-excel", response_model=EmployeeImportResult)
async def import_employees_excel(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.endswith((".xlsx", ".xls")):
        raise HTTPException(status_code=400, detail="Vui lòng tải lên file định dạng Excel (.xlsx hoặc .xls)")
    
    content = await file.read()
    try:
        result = ExcelService.import_employees_from_excel(db, content)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi khi xử lý file Excel: {str(e)}")

@router.get("/export-excel")
def export_employees_excel(
    department: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db)
):
    """
    Xuất danh sách nhân viên đầy đủ thông tin nhân sự ra file Excel.
    """
    try:
        stream = ExcelService.export_employees_list(db, department, status_filter)
        headers = {
            "Content-Disposition": "attachment; filename=Ho_So_Nhan_Su_KTS.xlsx"
        }
        return StreamingResponse(
            stream,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers=headers
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi xuất danh sách nhân viên: {str(e)}")

@router.get("/template-excel")
def download_employee_template():
    """
    Tải file Excel mẫu để nhập danh sách nhân viên.
    """
    try:
        stream = ExcelService.export_employees_template()
        headers = {
            "Content-Disposition": "attachment; filename=Mau_Ho_So_Nhan_Vien_KTS.xlsx"
        }
        return StreamingResponse(
            stream,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers=headers
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi tải file mẫu: {str(e)}")
