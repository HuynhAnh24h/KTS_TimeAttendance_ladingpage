from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Dict, Any

from backend.app.services.license_service import LicenseService
from backend.app.api.auth import get_current_user_optional, require_roles
from backend.app.models.user import User

router = APIRouter(prefix="/license", tags=["License"])

class LicenseActivateRequest(BaseModel):
    license_key: str = Field(..., description="Chuỗi mã bản quyền được cung cấp bởi nhà phát triển")

@router.get("/status")
def get_license_status():
    """
    Lấy thông tin bản quyền và mã phần cứng (Machine ID) của máy tính.
    """
    return LicenseService.get_license_status()

@router.post("/activate")
def activate_license(payload: LicenseActivateRequest):
    """
    Kích hoạt mã bản quyền thương mại vào hệ thống.
    """
    result = LicenseService.activate_key(payload.license_key)
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("message", "Mã bản quyền không hợp lệ"))
    return result
