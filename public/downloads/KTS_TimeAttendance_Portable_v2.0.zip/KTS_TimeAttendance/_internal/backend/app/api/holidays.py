from datetime import date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import extract

from backend.app.core.database import get_db
from backend.app.models.holiday import Holiday
from backend.app.schemas.leave_holiday import HolidayCreate, HolidayUpdate, HolidayOut

router = APIRouter(prefix="/holidays", tags=["Holidays"])

@router.get("", response_model=List[HolidayOut])
def get_holidays(
    year: Optional[int] = Query(None, description="Lọc theo năm"),
    db: Session = Depends(get_db)
):
    query = db.query(Holiday)
    if year:
        query = query.filter(
            (extract('year', Holiday.start_date) == year) |
            (extract('year', Holiday.end_date) == year)
        )
    return query.order_by(Holiday.start_date.asc()).all()

@router.post("", response_model=HolidayOut)
def create_holiday(data: HolidayCreate, db: Session = Depends(get_db)):
    if data.end_date < data.start_date:
        raise HTTPException(status_code=400, detail="Ngày kết thúc không thể trước ngày bắt đầu")
    
    holiday = Holiday(
        name=data.name,
        start_date=data.start_date,
        end_date=data.end_date,
        ot_rate=data.ot_rate,
        description=data.description
    )
    db.add(holiday)
    db.commit()
    db.refresh(holiday)
    return holiday

@router.put("/{holiday_id}", response_model=HolidayOut)
def update_holiday(holiday_id: int, data: HolidayUpdate, db: Session = Depends(get_db)):
    holiday = db.query(Holiday).filter(Holiday.id == holiday_id).first()
    if not holiday:
        raise HTTPException(status_code=404, detail="Không tìm thấy ngày lễ này")
    
    update_data = data.model_dump(exclude_unset=True)
    for field, val in update_data.items():
        setattr(holiday, field, val)
    
    if holiday.end_date < holiday.start_date:
        raise HTTPException(status_code=400, detail="Ngày kết thúc không thể trước ngày bắt đầu")
        
    db.commit()
    db.refresh(holiday)
    return holiday

@router.delete("/{holiday_id}")
def delete_holiday(holiday_id: int, db: Session = Depends(get_db)):
    holiday = db.query(Holiday).filter(Holiday.id == holiday_id).first()
    if not holiday:
        raise HTTPException(status_code=404, detail="Không tìm thấy ngày lễ này")
    db.delete(holiday)
    db.commit()
    return {"success": True, "message": "Đã xóa ngày lễ thành công"}

@router.post("/seed-vn")
def seed_vietnam_holidays(year: int = Query(default=2026), db: Session = Depends(get_db)):
    """
    Tự động nạp bộ Ngày Lễ chuẩn của Việt Nam theo Bộ Luật Lao Động cho năm chỉ định.
    """
    # Danh sách ngày lễ chuẩn Việt Nam
    vn_holidays = [
        {
            "name": f"Tết Dương Lịch {year}",
            "start_date": date(year, 1, 1),
            "end_date": date(year, 1, 1),
            "ot_rate": 3.0,
            "description": "Nghỉ 01 ngày hưởng nguyên lương theo BLLĐ"
        },
        {
            "name": f"Tết Nguyên Đán {year}",
            "start_date": date(year, 2, 14),
            "end_date": date(year, 2, 20),
            "ot_rate": 3.0,
            "description": "Nghỉ Tết Âm lịch theo thông báo của Bộ LĐ-TB&XH"
        },
        {
            "name": f"Giỗ Tổ Hùng Vương {year}",
            "start_date": date(year, 4, 26),
            "end_date": date(year, 4, 26),
            "ot_rate": 3.0,
            "description": "Mùng 10 tháng 3 Âm lịch"
        },
        {
            "name": f"Ngày Giải Phóng Miền Nam (30/4) & Quốc Tế Lao Động (1/5) {year}",
            "start_date": date(year, 4, 30),
            "end_date": date(year, 5, 1),
            "ot_rate": 3.0,
            "description": "Nghỉ 02 ngày hưởng nguyên lương"
        },
        {
            "name": f"Quốc Khánh {year} (2/9)",
            "start_date": date(year, 9, 1),
            "end_date": date(year, 9, 2),
            "ot_rate": 3.0,
            "description": "Nghỉ 02 ngày hưởng nguyên lương"
        }
    ]

    added = 0
    for h in vn_holidays:
        exists = db.query(Holiday).filter(
            Holiday.name == h["name"],
            Holiday.start_date == h["start_date"]
        ).first()
        if not exists:
            holiday = Holiday(**h)
            db.add(holiday)
            added += 1

    db.commit()
    return {
        "success": True,
        "message": f"Đã nạp thành công {added} ngày lễ chuẩn Việt Nam năm {year}!",
        "total_added": added
    }
