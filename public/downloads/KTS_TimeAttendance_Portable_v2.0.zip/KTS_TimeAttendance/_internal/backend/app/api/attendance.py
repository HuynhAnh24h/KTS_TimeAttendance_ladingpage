import os
import sys
import re
import urllib.parse
import unicodedata
import subprocess
import calendar
from datetime import date, datetime, timedelta, time
from typing import Optional, List, Dict
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.models.employee import Employee
from backend.app.models.device import Device
from backend.app.models.shift import Shift
from backend.app.models.attendance_log import RawAttendanceLog
from backend.app.models.daily_attendance import DailyAttendance
from backend.app.schemas.attendance import (
    TimesheetMatrixResponse, TimesheetRow, MatrixCell,
    CalculationRequest, CalculationResponse, DailyAttendanceOut, DailyAttendanceUpdate,
    RawAttendanceLogOut, AttendanceRegularizeRequest,
    DailyReportResponse, DailyReportSummary, DailyReportRecord
)
from backend.app.services.calculation_engine import AttendanceCalculationEngine
from backend.app.services.excel_service import ExcelService
from backend.app.api.auth import get_current_user_optional
from backend.app.models.user import User

router = APIRouter(prefix="/attendance", tags=["Attendance"])

@router.get("/matrix", response_model=TimesheetMatrixResponse)
def get_timesheet_matrix(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Trả về dữ liệu Bảng Công Ma Trận (Timesheet View):
    - Cột 1 đến 31 ngày trong tháng.
    - Hàng là danh sách nhân viên.
    - Từng ô (cell) chứa trạng thái trực quan, số công, giờ vào ra và cờ cuối tuần.
    """
    num_days = calendar.monthrange(year, month)[1]

    emp_query = db.query(Employee).filter(Employee.is_active == True)
    if department and department != "Tất cả":
        emp_query = emp_query.filter(Employee.department == department)
    employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

    start_date = date(year, month, 1)
    end_date = date(year, month, num_days)

    emp_ids = [e.id for e in employees]
    attendances = db.query(DailyAttendance).filter(
        DailyAttendance.employee_id.in_(emp_ids),
        DailyAttendance.attendance_date >= start_date,
        DailyAttendance.attendance_date <= end_date
    ).all()

    # Map: (employee_id, day) -> DailyAttendance
    att_map = {(a.employee_id, a.attendance_date.day): a for a in attendances}

    rows: List[TimesheetRow] = []
    for emp in employees:
        days_dict: Dict[int, MatrixCell] = {}
        total_work = 0.0
        total_late = 0
        total_ot = 0.0
        total_ot_30 = 0.0
        total_paid_leave = 0.0
        total_holiday = 0.0
        total_unpaid = 0.0
        total_actual_work = 0.0

        for day in range(1, num_days + 1):
            cur_date = date(year, month, day)
            is_wk = (cur_date.weekday() >= 6) # Chủ nhật

            att = att_map.get((emp.id, day))
            if att:
                status = att.status
                leave_type = getattr(att, "leave_type", None)
                work_u = att.work_units
                late_m = att.late_minutes
                early_m = att.early_leave_minutes
                ot_h = round(att.ot_15_hours + att.ot_20_hours, 1)
                ot_30 = round(getattr(att, "ot_30_hours", 0.0) or 0.0, 1)
                in_str = att.first_check_in.strftime("%H:%M") if att.first_check_in else None
                out_str = att.last_check_out.strftime("%H:%M") if att.last_check_out else None
                rec_id = att.id
                note_str = att.notes

                # Xác định ký hiệu hiển thị chuẩn
                if status == "HOLIDAY":
                    symbol = "L"
                    total_holiday += 1.0
                elif status == "HOLIDAY_WORK":
                    symbol = "L*"
                    total_holiday += 1.0
                    total_actual_work += 1.0
                elif status == "LEAVE_PAID":
                    symbol = "VR" if leave_type == "MARRIAGE" else "P"
                    total_paid_leave += 1.0
                elif status == "BUSINESS_TRIP":
                    symbol = "CT"
                    total_actual_work += 1.0
                elif status == "LEAVE_UNPAID":
                    symbol = "Ro"
                    total_unpaid += 1.0
                elif status == "LEAVE_INSURANCE":
                    symbol = "TS" if leave_type == "MATERNITY" else "Ô"
                elif status == "WEEKEND":
                    symbol = "-"
                elif status == "ABSENT":
                    symbol = "V"
                elif status in ["FULL_DAY", "OVERTIME", "LATE_EARLY"]:
                    symbol = "1.0"
                    total_actual_work += 1.0
                elif status == "HALF_DAY":
                    symbol = "0.5"
                    if leave_type in ["ANNUAL", "MARRIAGE"]:
                        total_paid_leave += 0.5
                    total_actual_work += 0.5
                else:
                    symbol = ""

                total_work += work_u
                total_late += late_m
                total_ot += ot_h
                total_ot_30 += ot_30
            else:
                status = "WEEKEND" if is_wk else "NO_DATA"
                symbol = "-" if is_wk else ""
                leave_type = None
                work_u = 0.0
                late_m = 0
                early_m = 0
                ot_h = 0.0
                ot_30 = 0.0
                in_str = None
                out_str = None
                rec_id = None
                note_str = None

            days_dict[day] = MatrixCell(
                day=day,
                date_str=cur_date.strftime("%Y-%m-%d"),
                status=status,
                leave_type=leave_type,
                symbol=symbol,
                work_units=work_u,
                late_minutes=late_m,
                early_leave_minutes=early_m,
                ot_hours=ot_h,
                ot_30_hours=ot_30,
                first_check_in_str=in_str,
                last_check_out_str=out_str,
                is_weekend=is_wk,
                is_manual_override=bool(getattr(att, 'is_manual_override', False)) if att else False,
                daily_attendance_id=rec_id,
                notes=note_str
            )

        rows.append(TimesheetRow(
            employee_id=emp.id,
            employee_code=emp.employee_code,
            full_name=emp.full_name,
            department=emp.department,
            position=emp.position,
            zk_user_id=emp.zk_user_id,
            days=days_dict,
            total_work_units=round(total_work, 1),
            total_late_minutes=total_late,
            total_ot_hours=round(total_ot, 1),
            total_ot_30_hours=round(total_ot_30, 1),
            total_paid_leave_days=round(total_paid_leave, 1),
            total_holiday_days=round(total_holiday, 1),
            total_unpaid_leave_days=round(total_unpaid, 1),
            total_actual_work_units=round(total_actual_work, 1)
        ))

    return TimesheetMatrixResponse(
        month=month,
        year=year,
        days_in_month=num_days,
        total_employees=len(employees),
        rows=rows
    )

@router.post("/calculate", response_model=CalculationResponse)
def calculate_attendance(payload: CalculationRequest, db: Session = Depends(get_db)):
    """
    Chạy engine tính toán công cho tháng.
    """
    total = AttendanceCalculationEngine.calculate_month_for_all(
        db=db,
        year=payload.year,
        month=payload.month,
        employee_id=payload.employee_id
    )
    return CalculationResponse(
        success=True,
        message=f"Đã tính toán hoàn tất dữ liệu tháng {payload.month}/{payload.year}",
        total_records_calculated=total
    )

@router.get("/detail/{attendance_id}")
def get_attendance_detail(attendance_id: int, db: Session = Depends(get_db)):
    """
    Xem chi tiết quẹt thẻ và thông số tính công của 1 ngày.
    Kèm theo toàn bộ raw punch logs của nhân viên trong ngày đó.
    """
    record = db.query(DailyAttendance).filter(DailyAttendance.id == attendance_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Không tìm thấy bản ghi công")

    employee = db.query(Employee).filter(Employee.id == record.employee_id).first()
    shift = db.query(Shift).filter(Shift.id == record.shift_id).first() if record.shift_id else None

    # Lấy các lần quẹt thẻ trong khoảng 24h của ngày đó
    start_range = datetime.combine(record.attendance_date, time(4, 0, 0))
    end_range = start_range + timedelta(hours=24)

    punches = db.query(RawAttendanceLog).filter(
        RawAttendanceLog.zk_user_id == employee.zk_user_id,
        RawAttendanceLog.check_time >= start_range,
        RawAttendanceLog.check_time < end_range
    ).order_by(RawAttendanceLog.check_time.asc()).all()

    punch_list = [
        {
            "id": p.id,
            "check_time": p.check_time.strftime("%H:%M:%S"),
            "full_datetime": p.check_time.isoformat(),
            "punch_state": p.punch_state,
            "verify_type": p.verify_type,
            "device_id": p.device_id
        }
        for p in punches
    ]

    return {
        "daily_attendance": DailyAttendanceOut.model_validate(record),
        "employee_name": employee.full_name,
        "employee_code": employee.employee_code,
        "zk_user_id": employee.zk_user_id,
        "department": employee.department,
        "shift_name": shift.name if shift else "Chưa gán ca",
        "punches": punch_list
    }

@router.put("/detail/{attendance_id}", response_model=DailyAttendanceOut)
def update_attendance_detail(
    attendance_id: int,
    payload: DailyAttendanceUpdate,
    db: Session = Depends(get_db)
):
    """
    Hiệu chỉnh công thủ công (Manual override khi nhân viên quên quẹt thẻ hoặc giải trình hợp lệ).
    """
    record = db.query(DailyAttendance).filter(DailyAttendance.id == attendance_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Không tìm thấy bản ghi công")

    data = payload.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(record, k, v)

    record.is_manual_override = True
    db.commit()
    db.refresh(record)
    return record

@router.post("/regularize", response_model=DailyAttendanceOut)
def regularize_attendance(
    payload: AttendanceRegularizeRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    CHẤM BÙ CÔNG (QUÊN CHẤM VÀO, QUÊN CHẤM RA, QUÊN CẢ NGÀY):
    Hiệu chỉnh công thủ công có lý do giải trình hợp lệ.
    Bản ghi được đánh dấu is_manual_override = True để không bị tính lại đè lên.
    Tổ trưởng/Quản đốc chỉ có quyền chấm bù cho công nhân thuộc phân xưởng của mình.
    """
    emp = db.query(Employee).filter(Employee.id == payload.employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Không tìm thấy nhân viên")

    # Phân quyền: Chỉ Admin và Nhân sự mới có quyền chấm bù công
    if current_user and current_user.role not in ["admin", "hr"]:
        raise HTTPException(
            status_code=403,
            detail=f"Tài khoản của bạn ({current_user.full_name} - {current_user.role}) không có quyền duyệt chấm bù công. Chỉ Admin và Nhân sự mới có quyền này."
        )

    target_date = payload.attendance_date
    record = db.query(DailyAttendance).filter(
        DailyAttendance.employee_id == payload.employee_id,
        DailyAttendance.attendance_date == target_date
    ).first()

    all_shifts = db.query(Shift).all()
    default_shift = emp.shift or next((s for s in all_shifts if s.is_default), all_shifts[0] if all_shifts else None)

    if not record:
        record = DailyAttendance(
            employee_id=emp.id,
            attendance_date=target_date,
            shift_id=default_shift.id if default_shift else None,
            work_units=1.0,
            status="FULL_DAY"
        )
        db.add(record)

    shift = record.shift or default_shift
    shift_start_str = shift.start_time if shift else "07:30"
    shift_end_str = shift.end_time if shift else "16:30"

    t_start = datetime.strptime(shift_start_str, "%H:%M").time()
    t_end = datetime.strptime(shift_end_str, "%H:%M").time()

    ctype = payload.compensation_type

    if ctype == "FULL_DAY":
        record.first_check_in = datetime.combine(target_date, t_start)
        record.last_check_out = datetime.combine(target_date, t_end)
        record.work_units = payload.work_units if payload.work_units is not None else 1.0
        record.late_minutes = 0
        record.early_leave_minutes = 0
        record.ot_15_hours = payload.ot_hours or 0.0
        record.status = "FULL_DAY"
    elif ctype == "HALF_DAY_MORNING":
        record.first_check_in = datetime.combine(target_date, t_start)
        record.last_check_out = datetime.combine(target_date, time(11, 30))
        record.work_units = 0.5
        record.late_minutes = 0
        record.early_leave_minutes = 0
        record.status = "HALF_DAY"
    elif ctype == "HALF_DAY_AFTERNOON":
        record.first_check_in = datetime.combine(target_date, time(13, 0))
        record.last_check_out = datetime.combine(target_date, t_end)
        record.work_units = 0.5
        record.late_minutes = 0
        record.early_leave_minutes = 0
        record.status = "HALF_DAY"
    elif ctype == "MISSING_IN":
        cin_t = datetime.strptime(payload.check_in_time or shift_start_str, "%H:%M").time()
        record.first_check_in = datetime.combine(target_date, cin_t)
        if not record.last_check_out:
            record.last_check_out = datetime.combine(target_date, t_end)
        record.work_units = payload.work_units if payload.work_units is not None else 1.0
        record.status = "FULL_DAY" if record.work_units >= 1.0 else "HALF_DAY"
    elif ctype == "MISSING_OUT":
        cout_t = datetime.strptime(payload.check_out_time or shift_end_str, "%H:%M").time()
        if not record.first_check_in:
            record.first_check_in = datetime.combine(target_date, t_start)
        record.last_check_out = datetime.combine(target_date, cout_t)
        record.work_units = payload.work_units if payload.work_units is not None else 1.0
        record.status = "FULL_DAY" if record.work_units >= 1.0 else "HALF_DAY"
    elif ctype == "CUSTOM":
        if payload.check_in_time:
            record.first_check_in = datetime.combine(target_date, datetime.strptime(payload.check_in_time, "%H:%M").time())
        if payload.check_out_time:
            record.last_check_out = datetime.combine(target_date, datetime.strptime(payload.check_out_time, "%H:%M").time())
        record.work_units = payload.work_units if payload.work_units is not None else 1.0
        record.ot_15_hours = payload.ot_hours or 0.0
        record.status = "FULL_DAY" if record.work_units >= 1.0 else "HALF_DAY"

    record.is_manual_override = True
    record.notes = payload.notes.strip() if payload.notes else "Chấm bù công"

    db.commit()
    db.refresh(record)
    return record

@router.get("/daily-report", response_model=DailyReportResponse)
def get_daily_report(
    target_date: date = Query(default=date.today()),
    department: Optional[str] = Query(default=None),
    status_filter: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    BÁO CÁO ĐIỂM DANH HÀNG NGÀY (DAILY HR REPORT):
    Xem nhanh quân số đi làm, vắng mặt, đi trễ, về sớm, tăng ca hôm nay.
    """
    emp_query = db.query(Employee).filter(Employee.is_active == True)
    if department and department != "Tất cả":
        emp_query = emp_query.filter(Employee.department == department)
    employees = emp_query.order_by(Employee.department.asc(), Employee.employee_code.asc()).all()

    emp_ids = [e.id for e in employees]
    records = db.query(DailyAttendance).filter(
        DailyAttendance.attendance_date == target_date,
        DailyAttendance.employee_id.in_(emp_ids)
    ).all()
    rec_map = {r.employee_id: r for r in records}

    all_shifts = db.query(Shift).all()
    shift_map = {s.id: s for s in all_shifts}
    default_shift = next((s for s in all_shifts if s.is_default), all_shifts[0] if all_shifts else None)

    summary = DailyReportSummary(
        total_employees=len(employees),
        present_count=0,
        absent_count=0,
        late_count=0,
        early_count=0,
        ot_count=0,
        leave_count=0,
        manual_count=0
    )

    report_records: List[DailyReportRecord] = []

    for emp in employees:
        att = rec_map.get(emp.id)
        shift = (shift_map.get(att.shift_id) if att and att.shift_id else None) or emp.shift or default_shift
        if shift:
            if shift.start_time and shift.start_time in shift.name:
                shift_name = shift.name
            else:
                shift_name = f"{shift.name} ({shift.start_time} - {shift.end_time})"
        else:
            shift_name = "Chưa gán ca"

        if att:
            in_str = att.first_check_in.strftime("%H:%M") if att.first_check_in else None
            out_str = att.last_check_out.strftime("%H:%M") if att.last_check_out else None
            is_present = (att.work_units > 0 or in_str is not None)
            is_absent = (att.status == "ABSENT")
            is_late = (att.late_minutes > 0)
            is_early = (att.early_leave_minutes > 0)
            is_ot = (att.ot_15_hours > 0 or att.ot_20_hours > 0 or getattr(att, "ot_30_hours", 0) > 0)
            is_leave = (att.status in ["HOLIDAY", "HOLIDAY_WORK", "LEAVE_PAID", "LEAVE_UNPAID", "LEAVE_INSURANCE", "BUSINESS_TRIP"])
            is_manual = bool(att.is_manual_override)

            if is_present: summary.present_count += 1
            if is_absent: summary.absent_count += 1
            if is_late: summary.late_count += 1
            if is_early: summary.early_count += 1
            if is_ot: summary.ot_count += 1
            if is_leave: summary.leave_count += 1
            if is_manual: summary.manual_count += 1

            status_val = att.status
            rec_id = att.id
            work_u = att.work_units
            late_m = att.late_minutes
            early_m = att.early_leave_minutes
            ot_h = round((att.ot_15_hours or 0) + (att.ot_20_hours or 0) + (getattr(att, "ot_30_hours", 0) or 0), 1)
            notes_val = att.notes
        else:
            in_str = None
            out_str = None
            is_present = False
            is_absent = True
            is_late = False
            is_early = False
            is_ot = False
            is_manual = False
            summary.absent_count += 1

            status_val = "ABSENT"
            rec_id = None
            work_u = 0.0
            late_m = 0
            early_m = 0
            ot_h = 0.0
            notes_val = None

        if status_filter:
            if status_filter == "PRESENT" and not is_present: continue
            if status_filter == "ABSENT" and not is_absent: continue
            if status_filter == "LATE" and not is_late: continue
            if status_filter == "EARLY" and not is_early: continue
            if status_filter == "OT" and not is_ot: continue
            if status_filter == "MANUAL" and not is_manual: continue

        report_records.append(DailyReportRecord(
            daily_attendance_id=rec_id,
            employee_id=emp.id,
            employee_code=emp.employee_code,
            full_name=emp.full_name,
            department=emp.department,
            position=emp.position,
            shift_name=shift_name,
            first_check_in_str=in_str,
            last_check_out_str=out_str,
            late_minutes=late_m,
            early_leave_minutes=early_m,
            ot_hours=ot_h,
            work_units=work_u,
            status=status_val,
            is_manual_override=is_manual,
            notes=notes_val
        ))

    return DailyReportResponse(
        date=target_date.strftime("%Y-%m-%d"),
        summary=summary,
        records=report_records
    )

@router.get("/export-daily-excel")
def export_daily_excel_report(
    target_date: date = Query(default=date.today()),
    department: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Xuất file Excel báo cáo điểm danh ngày chuẩn kế toán & nhân sự.
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = ExcelService.export_daily_report(db=db, target_date=target_date, department=dept_val)
    dept_suffix = f"_{department.replace(' ', '_')}" if dept_val else ""
    date_str = target_date.strftime("%d_%m_%Y")
    filename = f"Bao_Cao_Diem_Danh_{date_str}{dept_suffix}.xlsx"

    ascii_filename = _sanitize_ascii_filename(filename)
    quoted_filename = urllib.parse.quote(filename)
    headers = {
        "Content-Disposition": f'attachment; filename="{ascii_filename}"; filename*=UTF-8\'\'{quoted_filename}',
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Access-Control-Expose-Headers": "Content-Disposition"
    }
    return StreamingResponse(
        excel_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers
    )

@router.post("/export-daily-excel-file")
def export_daily_excel_file_to_desktop(
    target_date: date = Query(default=date.today()),
    department: Optional[str] = Query(default=None),
    open_file: bool = Query(default=True),
    db: Session = Depends(get_db)
):
    """
    Xuất file Excel báo cáo ngày và lưu trực tiếp vào thư mục Downloads của người dùng, tự động mở file.
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = ExcelService.export_daily_report(db=db, target_date=target_date, department=dept_val)
    dept_suffix = f"_{department.replace(' ', '_')}" if dept_val else ""
    date_str = target_date.strftime("%d_%m_%Y")
    filename = f"Bao_Cao_Diem_Danh_{date_str}{dept_suffix}.xlsx"

    downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(downloads_dir, exist_ok=True)
    file_path = os.path.join(downloads_dir, filename)

    with open(file_path, "wb") as f:
        f.write(excel_stream.getvalue())

    opened = False
    if open_file and sys.platform == "win32":
        try:
            os.startfile(file_path)
            opened = True
        except Exception:
            try:
                subprocess.Popen(f'explorer /select,"{file_path}"')
                opened = True
            except Exception:
                pass

    return {
        "success": True,
        "filename": filename,
        "file_path": file_path,
        "opened": opened,
        "message": f"Đã lưu thành công tại: {file_path}"
    }

def _sanitize_ascii_filename(text: str) -> str:
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = ''.join(c for c in nfkd if not unicodedata.combining(c))
    ascii_text = ascii_text.replace('đ', 'd').replace('Đ', 'D')
    return re.sub(r'[^a-zA-Z0-9_.-]', '_', ascii_text)

@router.get("/export-excel")
def export_excel_timesheet(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Xuất file Excel bảng công ma trận tháng chuẩn kế toán Việt Nam dưới dạng file tải về trực tiếp.
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = ExcelService.export_monthly_timesheet(db=db, year=year, month=month, department=dept_val)
    dept_suffix = f"_{department.replace(' ', '_')}" if dept_val else ""
    filename = f"Bang_Cham_Cong_Thang_{month}_{year}{dept_suffix}.xlsx"
    
    ascii_filename = _sanitize_ascii_filename(filename)
    quoted_filename = urllib.parse.quote(filename)
    headers = {
        "Content-Disposition": f'attachment; filename="{ascii_filename}"; filename*=UTF-8\'\'{quoted_filename}',
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Access-Control-Expose-Headers": "Content-Disposition"
    }
    return StreamingResponse(
        excel_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers
    )

@router.post("/export-excel-file")
def export_excel_file_to_desktop(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    department: Optional[str] = Query(default=None),
    open_file: bool = Query(default=True),
    db: Session = Depends(get_db)
):
    """
    Dành riêng cho Desktop App:
    Tự động ghi file Excel vào thư mục Downloads của người dùng
    và mở tự động file Excel (hoặc mở thư mục chứa file trong Windows Explorer).
    """
    dept_val = department if (department and department != "Tất cả") else None
    excel_stream = ExcelService.export_monthly_timesheet(db=db, year=year, month=month, department=dept_val)
    dept_suffix = f"_{department.replace(' ', '_')}" if dept_val else ""
    filename = f"Bang_Cham_Cong_Thang_{month}_{year}{dept_suffix}.xlsx"

    downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(downloads_dir, exist_ok=True)
    file_path = os.path.join(downloads_dir, filename)

    with open(file_path, "wb") as f:
        f.write(excel_stream.getvalue())

    opened = False
    if open_file and sys.platform == "win32":
        try:
            os.startfile(file_path)
            opened = True
        except Exception:
            try:
                subprocess.Popen(f'explorer /select,"{file_path}"')
                opened = True
            except Exception:
                pass

    return {
        "success": True,
        "filename": filename,
        "file_path": file_path,
        "opened": opened,
        "message": f"Đã lưu thành công tại: {file_path}"
    }

@router.get("/raw-logs")
def get_raw_attendance_logs(
    from_date: Optional[str] = Query(None, description="Từ ngày (YYYY-MM-DD)"),
    to_date: Optional[str] = Query(None, description="Đến ngày (YYYY-MM-DD)"),
    search: Optional[str] = Query(None, description="Tìm theo tên, mã NV hoặc ZK ID"),
    device_id: Optional[int] = Query(None, description="Lọc theo ID thiết bị"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """
    Truy vấn nhật ký quẹt thẻ gốc trực tiếp từ máy chấm công.
    Hỗ trợ tìm kiếm, lọc theo ngày và theo thiết bị.
    """
    query = db.query(RawAttendanceLog)
    
    if from_date:
        try:
            f_d = datetime.strptime(from_date, "%Y-%m-%d")
            query = query.filter(RawAttendanceLog.check_time >= f_d)
        except ValueError:
            pass

    if to_date:
        try:
            t_d = datetime.strptime(to_date, "%Y-%m-%d") + timedelta(days=1)
            query = query.filter(RawAttendanceLog.check_time < t_d)
        except ValueError:
            pass

    if device_id:
        query = query.filter(RawAttendanceLog.device_id == device_id)

    # Build employee mapping for enrichment
    employees = db.query(Employee).all()
    emp_by_zk = {e.zk_user_id: e for e in employees if e.zk_user_id}
    devices = {d.id: d.name for d in db.query(Device).all()}

    if search:
        s_term = search.lower().strip()
        matched_zk_ids = [
            zk for zk, e in emp_by_zk.items()
            if s_term in e.full_name.lower() or s_term in e.employee_code.lower() or s_term in zk.lower()
        ]
        query = query.filter(RawAttendanceLog.zk_user_id.in_(matched_zk_ids))

    total = query.count()
    logs = query.order_by(RawAttendanceLog.check_time.desc()).offset(offset).limit(limit).all()

    punch_states = {
        0: "Check-In (Vào)",
        1: "Check-Out (Ra)",
        2: "Break-Out",
        3: "Break-In",
        4: "OT-In",
        5: "OT-Out",
        255: "Tự động"
    }

    result = []
    for l in logs:
        emp = emp_by_zk.get(l.zk_user_id)
        result.append({
            "id": l.id,
            "zk_user_id": l.zk_user_id,
            "employee_code": emp.employee_code if emp else "-",
            "full_name": emp.full_name if emp else f"Chưa gán hồ sơ (ZK: {l.zk_user_id})",
            "department": emp.department if emp else "-",
            "check_time_str": l.check_time.strftime("%d/%m/%Y %H:%M:%S"),
            "check_time_iso": l.check_time.isoformat(),
            "punch_state": l.punch_state,
            "punch_state_name": punch_states.get(l.punch_state, "Quẹt thẻ"),
            "verify_type": l.verify_type,
            "device_id": l.device_id,
            "device_name": devices.get(l.device_id, f"Máy #{l.device_id}" if l.device_id else "Không rõ")
        })

    return {
        "total": total,
        "items": result,
        "limit": limit,
        "offset": offset
    }

@router.get("/export-raw-logs")
def export_raw_attendance_logs_excel(
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    search: Optional[str] = None,
    device_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """
    Xuất danh sách nhật ký quẹt thẻ gốc ra file Excel.
    """
    data = get_raw_attendance_logs(
        from_date=from_date,
        to_date=to_date,
        search=search,
        device_id=device_id,
        limit=5000,
        offset=0,
        db=db
    )
    stream = ExcelService.export_raw_attendance_logs(data["items"])
    headers = {
        "Content-Disposition": f"attachment; filename=Nhat_Ky_Quet_The_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    }
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers
    )

