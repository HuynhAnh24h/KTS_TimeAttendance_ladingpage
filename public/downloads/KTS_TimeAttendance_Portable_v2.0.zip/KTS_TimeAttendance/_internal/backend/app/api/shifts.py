from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from backend.app.core.database import get_db
from backend.app.models.shift import Shift
from backend.app.schemas.shift import ShiftCreate, ShiftUpdate, ShiftOut

router = APIRouter(prefix="/shifts", tags=["Shifts"])

@router.get("", response_model=List[ShiftOut])
def get_shifts(db: Session = Depends(get_db)):
    return db.query(Shift).order_by(Shift.id.asc()).all()

@router.post("", response_model=ShiftOut, status_code=status.HTTP_201_CREATED)
def create_shift(payload: ShiftCreate, db: Session = Depends(get_db)):
    existing = db.query(Shift).filter(Shift.code == payload.code).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Mã ca {payload.code} đã tồn tại")
    
    if payload.is_default:
        # Hủy is_default ở các ca khác
        db.query(Shift).update({Shift.is_default: False})

    shift = Shift(**payload.model_dump())
    db.add(shift)
    db.commit()
    db.refresh(shift)
    return shift

@router.put("/{shift_id}", response_model=ShiftOut)
def update_shift(shift_id: int, payload: ShiftUpdate, db: Session = Depends(get_db)):
    shift = db.query(Shift).filter(Shift.id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=404, detail="Không tìm thấy ca làm việc")
    
    data = payload.model_dump(exclude_unset=True)
    if "is_default" in data and data["is_default"]:
        db.query(Shift).filter(Shift.id != shift_id).update({Shift.is_default: False})

    for k, v in data.items():
        setattr(shift, k, v)
        
    db.commit()
    db.refresh(shift)
    return shift

@router.delete("/{shift_id}")
def delete_shift(shift_id: int, db: Session = Depends(get_db)):
    shift = db.query(Shift).filter(Shift.id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=404, detail="Không tìm thấy ca làm việc")
    
    db.delete(shift)
    db.commit()
    return {"message": "Đã xóa ca làm việc thành công"}
