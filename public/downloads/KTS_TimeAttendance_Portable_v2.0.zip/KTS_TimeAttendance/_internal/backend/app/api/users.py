from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.core.database import get_db
from backend.app.models.user import User
from backend.app.schemas.auth import UserCreate, UserUpdate, UserOut
from backend.app.core.security import hash_password
from backend.app.api.auth import require_roles, get_current_user

router = APIRouter(prefix="/users", tags=["User Management"])

VALID_ROLES = ["superadmin", "admin", "hr", "accountant"]

@router.get("", response_model=List[UserOut])
def get_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Danh sách tài khoản trong hệ thống (Chỉ dành cho Quản trị viên Admin).
    """
    return db.query(User).order_by(User.id.asc()).all()

@router.post("", response_model=UserOut)
def create_user(
    data: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Tạo tài khoản người dùng mới (Chỉ dành cho Admin: admin, hr, accountant).
    """
    if data.role not in VALID_ROLES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Vai trò không hợp lệ. Các vai trò được phép: {', '.join(VALID_ROLES)}"
        )

    existing = db.query(User).filter(User.username == data.username).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Tên đăng nhập '{data.username}' đã tồn tại trong hệ thống."
        )

    hashed_pw, salt = hash_password(data.password)
    user = User(
        username=data.username,
        hashed_password=hashed_pw,
        salt=salt,
        full_name=data.full_name,
        email=data.email,
        role=data.role,
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.put("/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Cập nhật thông tin, vai trò hoặc đổi mật khẩu người dùng (Admin).
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Không tìm thấy người dùng.")

    if data.role and data.role not in VALID_ROLES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Vai trò không hợp lệ. Các vai trò được phép: {', '.join(VALID_ROLES)}"
        )

    if data.full_name is not None:
        user.full_name = data.full_name
    if data.email is not None:
        user.email = data.email
    if data.role is not None:
        user.role = data.role
    if data.is_active is not None:
        user.is_active = data.is_active
    if data.password:
        hashed_pw, salt = hash_password(data.password)
        user.hashed_password = hashed_pw
        user.salt = salt

    db.commit()
    db.refresh(user)
    return user

@router.delete("/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["admin"]))
):
    """
    Xóa tài khoản người dùng (Không thể tự xóa chính mình).
    """
    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Bạn không thể tự xóa tài khoản đang đăng nhập của chính mình."
        )

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Không tìm thấy người dùng.")

    db.delete(user)
    db.commit()
    return {"message": f"Đã xóa tài khoản {user.username} thành công."}
