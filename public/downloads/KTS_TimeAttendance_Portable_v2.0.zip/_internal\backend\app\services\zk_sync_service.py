import os
import json
import base64
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.app.core.config import settings
from backend.app.models.device import Device
from backend.app.models.employee import Employee
from backend.app.models.shift import Shift
from backend.app.models.attendance_log import RawAttendanceLog
from backend.app.models.biometric_template import BiometricTemplate

logger = logging.getLogger("zk_sync_service")
logging.basicConfig(level=logging.INFO)

class ZkSyncService:
    """
    Dịch vụ giao tiếp và đồng bộ dữ liệu với máy chấm công ZKTeco / Ronald Jack qua mạng IP (LAN).
    Hỗ trợ đa giao thức thông minh: Tự động phát hiện TCP (SpeedFace, FaceDepot) hoặc UDP (K14, Ronald Jack).
    """

    @staticmethod
    def _get_device_comm_params(device: Device) -> Tuple[int, bool]:
        """
        Trích xuất mật khẩu kết nối (Comm Key) và chế độ UDP ưu tiên cho thiết bị.
        Các dòng Gigata (T9, T8...), Ronald Jack, Wise Eye, Mita ưu tiên giao thức UDP.
        """
        comm_pass = 0
        if device.comm_password:
            try:
                comm_pass = int(device.comm_password)
            except ValueError:
                comm_pass = 0
        is_udp = (device.protocol_type == "ZK_UDP") or (device.brand in ["GIGATA", "RONALD_JACK", "WISE_EYE", "MITA"])
        return comm_pass, is_udp

    @staticmethod
    def _create_zk_connection(ip: str, port: int = 4370, timeout: int = 5, password: int = 0, force_udp: bool = True):
        """
        Kết nối thông minh đa giao thức (tự động thử UDP và TCP).
        Tương thích 100% tất cả các dòng máy chấm công:
        - Gigata (T9, T8, FA-113, ...)
        - Ronald Jack (RJ2200, RJ3000, RJ4000, RJ8000, 5000AID, X628-C, ...)
        - ZKTeco (SpeedFace, FaceDepot, K14, K40, MB20, MB40, ...)
        - Wise Eye, Mita, Granding, Aikyo, v.v.
        """
        from zk import ZK

        if force_udp:
            # Ưu tiên UDP trước (Gigata T9, Ronald Jack, K-series)
            try:
                zk_udp = ZK(ip, port=port, timeout=timeout, password=password, force_udp=True, ommit_ping=True)
                conn = zk_udp.connect()
                return zk_udp, conn
            except Exception as e_udp:
                logger.info(f"Kết nối UDP tới {ip}:{port} không phản hồi ({e_udp}), chuyển sang thử TCP...")
                try:
                    zk_tcp = ZK(ip, port=port, timeout=timeout, password=password, force_udp=False, ommit_ping=True)
                    conn = zk_tcp.connect()
                    return zk_tcp, conn
                except Exception as e_tcp:
                    raise Exception(f"Không thể kết nối tới máy chấm công {ip}:{port} (Đã thử cả UDP: {e_udp} và TCP: {e_tcp})")
        else:
            # Ưu tiên TCP trước (SpeedFace, FaceDepot, ProFace)
            try:
                zk_tcp = ZK(ip, port=port, timeout=timeout, password=password, force_udp=False, ommit_ping=True)
                conn = zk_tcp.connect()
                return zk_tcp, conn
            except Exception as e_tcp:
                logger.info(f"Kết nối TCP tới {ip}:{port} không phản hồi ({e_tcp}), chuyển sang thử UDP...")
                try:
                    zk_udp = ZK(ip, port=port, timeout=timeout, password=password, force_udp=True, ommit_ping=True)
                    conn = zk_udp.connect()
                    return zk_udp, conn
                except Exception as e_udp:
                    raise Exception(f"Không thể kết nối tới máy chấm công {ip}:{port} (Đã thử cả TCP: {e_tcp} và UDP: {e_udp})")

    @classmethod
    def test_connection(cls, ip: str, port: int = 4370, timeout: int = 5, password: int = 0, force_udp: bool = True) -> Dict[str, Any]:
        """
        Kiểm tra kết nối tới máy chấm công và đọc thông tin cấu hình phần cứng.
        """
        try:
            zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=password, force_udp=force_udp)
            
            try:
                conn.disable_device()
                device_name = conn.get_device_name() or "ZKTeco Device"
                serial_number = conn.get_serialnumber() or "Unknown"
                firmware = conn.get_firmware_version() or "Unknown"
                users = conn.get_users()
                user_count = len(users) if users else 0
                conn.enable_device()
            finally:
                conn.disconnect()

            return {
                "success": True,
                "message": f"Kết nối thành công tới thiết bị {device_name} ({ip})",
                "device_name": device_name,
                "serial_number": serial_number,
                "firmware_version": firmware,
                "user_count": user_count
            }
        except Exception as e:
            logger.error(f"Lỗi kiểm tra kết nối IP {ip}:{port} -> {str(e)}")
            return {
                "success": False,
                "message": f"Không thể kết nối tới {ip}:{port}. Lỗi: {str(e)}",
                "device_name": None,
                "serial_number": None,
                "firmware_version": None,
                "user_count": 0
            }

    @staticmethod
    def sync_device_logs(
        db: Session,
        device: Device,
        simulate_if_offline: bool = False,
        sync_users: bool = True
    ) -> Tuple[int, int, Optional[str]]:
        """
        Đồng bộ logs từ thiết bị về cơ sở dữ liệu.
        Tự động đồng bộ danh sách nhân sự (Users) từ máy về CSDL nếu chưa có.
        Trả về: (tổng_số_log_quét_được, số_log_mới_đã_lưu, lỗi_nếu_có)
        """
        ip = device.ip_address
        port = device.port or 4370
        timeout = settings.ZK_TIMEOUT

        logger.info(f"Bắt đầu đồng bộ từ máy {device.name} [IP: {ip}:{port}]...")
        device.status = "SYNCING"
        db.commit()

        raw_logs = []
        raw_users = []
        sync_error = None

        comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

        try:
            zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
            try:
                conn.disable_device()
                
                # 1. Kéo thông tin thiết bị
                try:
                    device.device_name_hw = conn.get_device_name() or device.device_name_hw
                    device.serial_number = conn.get_serialnumber() or device.serial_number
                    device.firmware_version = conn.get_firmware_version() or device.firmware_version
                except Exception:
                    pass

                # 2. Kéo danh sách User từ máy
                if sync_users:
                    try:
                        raw_users = conn.get_users() or []
                        device.user_count = len(raw_users)
                    except Exception as eu:
                        logger.warning(f"Lỗi lấy users từ máy: {eu}")

                # 3. Kéo toàn bộ log chấm công
                attendances = conn.get_attendance()
                raw_logs = attendances if attendances else []
                device.log_count = len(raw_logs)

                conn.enable_device()
            finally:
                conn.disconnect()

            device.status = "ONLINE"
            device.last_synced_at = datetime.utcnow()

        except Exception as e:
            sync_error = str(e)
            logger.warning(f"Không thể kết nối máy chấm công thực tế {ip}:{port} -> {sync_error}")
            
            if simulate_if_offline:
                logger.info(f"Kích hoạt chế độ mô phỏng cho thiết bị {device.name} để thử nghiệm.")
                raw_logs = ZkSyncService._generate_mock_attendances(db)
                device.status = "ONLINE"
                device.last_synced_at = datetime.utcnow()
                sync_error = None
            else:
                device.status = "ERROR"
                db.commit()
                return 0, 0, f"Lỗi kết nối máy {device.name} ({ip}): {sync_error}"

        # Lưu thông tin nhân sự từ máy vào DB
        if raw_users:
            default_shift = db.query(Shift).filter(Shift.is_default == True).first() or db.query(Shift).first()
            existing_zk_ids = {e.zk_user_id: e for e in db.query(Employee).all()}
            existing_codes = {e.employee_code for e in existing_zk_ids.values()}

            new_employees = []
            for u in raw_users:
                uid_str = str(u.user_id)
                uname = (u.name or "").strip() or f"Nhân viên {uid_str}"
                
                if uid_str not in existing_zk_ids:
                    code_cand = f"NV{uid_str.zfill(4)}"
                    if code_cand in existing_codes:
                        code_cand = f"NV_{uid_str}"
                    existing_codes.add(code_cand)

                    new_emp = Employee(
                        zk_user_id=uid_str,
                        employee_code=code_cand,
                        full_name=uname,
                        department="Khu Vực Sản Xuất",
                        position="Nhân viên",
                        card_number=str(u.card) if getattr(u, 'card', None) else None,
                        shift_id=default_shift.id if default_shift else None,
                        is_active=True
                    )
                    new_employees.append(new_emp)
                    existing_zk_ids[uid_str] = new_emp
                else:
                    curr = existing_zk_ids[uid_str]
                    if uname and (not curr.full_name or curr.full_name.startswith("Chưa")):
                        curr.full_name = uname

            if new_employees:
                db.bulk_save_objects(new_employees)
                db.commit()
                logger.info(f"Đã tự động nạp {len(new_employees)} nhân viên mới từ máy {device.name}")

        if not raw_logs:
            db.commit()
            return 0, 0, None

        # Lọc trùng lặp hiệu năng cao:
        min_time = min(att.timestamp for att in raw_logs)
        max_time = max(att.timestamp for att in raw_logs)

        # Lấy các log đã có trong DB trong khoảng thời gian này
        existing_records = db.query(RawAttendanceLog.zk_user_id, RawAttendanceLog.check_time).filter(
            RawAttendanceLog.check_time >= min_time,
            RawAttendanceLog.check_time <= max_time
        ).all()

        existing_set = set(existing_records)

        new_log_objects = []
        for att in raw_logs:
            uid = str(att.user_id)
            ctime = att.timestamp
            
            if (uid, ctime) not in existing_set:
                new_log_objects.append(
                    RawAttendanceLog(
                        zk_user_id=uid,
                        check_time=ctime,
                        punch_state=getattr(att, 'punch', 0) or 0,
                        verify_type=getattr(att, 'status', 1) or 1,
                        device_id=device.id
                    )
                )
                existing_set.add((uid, ctime))

        if new_log_objects:
            # Lưu theo từng chunk 1000 bản ghi để tối ưu I/O
            CHUNK_SIZE = 1000
            for i in range(0, len(new_log_objects), CHUNK_SIZE):
                batch = new_log_objects[i:i + CHUNK_SIZE]
                db.bulk_save_objects(batch)
                db.commit()
            logger.info(f"Đã lưu thành công {len(new_log_objects)} bản ghi quẹt thẻ mới từ {device.name}")
        else:
            logger.info(f"Không có bản ghi quẹt thẻ mới nào từ {device.name} (Tất cả đã tồn tại).")

        return len(raw_logs), len(new_log_objects), None

    @staticmethod
    def _generate_mock_attendances(db: Session):
        import random
        from datetime import datetime, timedelta

        employees = db.query(Employee).filter(Employee.is_active == True).all()
        if not employees:
            return []

        class MockAttendance:
            def __init__(self, user_id, timestamp, punch=0, status=1):
                self.user_id = user_id
                self.timestamp = timestamp
                self.punch = punch
                self.status = status

        mock_list = []
        now = datetime.now()
        for day_offset in range(5, -1, -1):
            cur_date = (now - timedelta(days=day_offset)).date()
            if cur_date.weekday() >= 6:
                continue
            
            for emp in employees:
                if random.random() > 0.12:
                    in_minute = random.randint(-15, 35)
                    check_in = datetime.combine(cur_date, datetime.strptime("08:00", "%H:%M").time()) + timedelta(minutes=in_minute)
                    mock_list.append(MockAttendance(emp.zk_user_id, check_in, punch=0))

                    out_minute = random.randint(-20, 120)
                    check_out = datetime.combine(cur_date, datetime.strptime("17:30", "%H:%M").time()) + timedelta(minutes=out_minute)
                    mock_list.append(MockAttendance(emp.zk_user_id, check_out, punch=1))

        return mock_list

    @staticmethod
    def get_biometrics_stats(db: Session) -> Dict[str, Any]:
        """
        Lấy thống kê dữ liệu vân tay sinh trắc học đã lưu trữ trong CSDL.
        """
        total_templates = db.query(BiometricTemplate).count()
        users_with_templates = db.query(BiometricTemplate.zk_user_id).distinct().count()
        total_active_emps = db.query(Employee).filter(Employee.is_active == True).count()
        last_updated = db.query(func.max(BiometricTemplate.updated_at)).scalar()

        return {
            "total_templates": total_templates,
            "users_with_templates": users_with_templates,
            "total_active_employees": total_active_emps,
            "last_backup_at": last_updated.isoformat() if last_updated else None,
            "coverage_percent": round((users_with_templates / total_active_emps * 100), 1) if total_active_emps > 0 else 0
        }

    @staticmethod
    def backup_device_biometrics(
        db: Session,
        device_id: int,
        simulate_if_offline: bool = False
    ) -> Dict[str, Any]:
        """
        KÉO DỮ LIỆU SINH TRẮC HỌC TỪ MÁY CHẤM CÔNG VỀ CSDL:
        1. Đọc toàn bộ danh sách User trên máy (Họ tên, Mã chấm công, Thẻ RFID).
        2. Đọc toàn bộ Mẫu Dấu Vân Tay (Biometric Templates) của tất cả ngón tay (0-9).
        3. Lưu trữ vào bảng biometric_templates trong CSDL và tự động xuất bản sao lưu .json.
        """
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return {"success": False, "message": "Không tìm thấy thiết bị"}

        ip = device.ip_address
        port = device.port or 4370
        timeout = settings.ZK_TIMEOUT

        raw_users = []
        raw_templates = []
        is_simulated = False

        comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

        try:
            zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
            try:
                conn.disable_device()
                raw_users = conn.get_users() or []
                raw_templates = conn.get_templates() or []
                conn.enable_device()
            finally:
                conn.disconnect()
            device.status = "ONLINE"
        except Exception as e:
            logger.warning(f"Không thể kết nối máy chấm công {ip}:{port} để sao lưu vân tay -> {e}")
            if simulate_if_offline:
                is_simulated = True
                device.status = "ONLINE"
                # Tạo dữ liệu mô phỏng nếu máy đang offline trong môi trường thử nghiệm
                active_emps = db.query(Employee).filter(Employee.is_active == True).all()
                for idx, emp in enumerate(active_emps):
                    fake_bytes = f"ZKFP_TEMPLATE_V10_USER_{emp.zk_user_id}_FINGER_0_{idx:04d}".encode("utf-8")
                    class MockFinger:
                        def __init__(self, uid, fid, valid, tpl):
                            self.uid = uid
                            self.fid = fid
                            self.valid = valid
                            self.template = tpl
                    raw_templates.append(MockFinger(int(emp.zk_user_id) if emp.zk_user_id.isdigit() else idx + 1, 0, 1, fake_bytes))
            else:
                device.status = "ERROR"
                db.commit()
                return {"success": False, "message": f"Không thể kết nối máy {device.name} ({ip}): {str(e)}"}

        # Map uid -> zk_user_id
        uid_to_zk_id = {}
        for u in raw_users:
            uid_to_zk_id[u.uid] = str(u.user_id)

        # Lưu mẫu vân tay vào CSDL
        saved_count = 0
        existing_tpls = {(t.zk_user_id, t.finger_index): t for t in db.query(BiometricTemplate).all()}

        for f in raw_templates:
            zk_id = uid_to_zk_id.get(f.uid, str(f.uid))
            fid = f.fid
            tpl_bytes = f.template if isinstance(f.template, bytes) else str(f.template).encode("utf-8")
            b64_data = base64.b64encode(tpl_bytes).decode("ascii")

            key = (zk_id, fid)
            if key in existing_tpls:
                tpl = existing_tpls[key]
                tpl.template_data = b64_data
                tpl.template_size = len(tpl_bytes)
                tpl.valid_flag = f.valid
                tpl.device_id = device.id
                tpl.updated_at = datetime.utcnow()
            else:
                tpl = BiometricTemplate(
                    zk_user_id=zk_id,
                    finger_index=fid,
                    template_data=b64_data,
                    template_size=len(tpl_bytes),
                    valid_flag=f.valid,
                    device_id=device.id
                )
                db.add(tpl)
                existing_tpls[key] = tpl
            saved_count += 1

        device.last_synced_at = datetime.utcnow()
        db.commit()

        # Tự động xuất file sao lưu JSON an toàn vào thư mục Downloads
        backup_file_path = None
        try:
            backup_res = ZkSyncService.export_biometric_backup(db)
            backup_file_path = backup_res.get("file_path")
        except Exception as e_bk:
            logger.warning(f"Lỗi xuất file backup tự động: {e_bk}")

        return {
            "success": True,
            "message": f"Đã sao lưu thành công {saved_count} mẫu dấu vân tay từ thiết bị {device.name}!",
            "device_name": device.name,
            "ip_address": device.ip_address,
            "total_templates_synced": saved_count,
            "is_simulated": is_simulated,
            "backup_file": backup_file_path
        }

    @staticmethod
    def restore_device_biometrics(
        db: Session,
        target_device_id: int,
        simulate_if_offline: bool = False
    ) -> Dict[str, Any]:
        """
        NẠP DỮ LIỆU & DẤU VÂN TAY SANG MÁY CHẤM CÔNG MỚI:
        Khi công ty thay máy mới hoặc lắp thêm máy ở xưởng 2:
        1. Đẩy toàn bộ danh sách nhân viên đang làm việc lên máy.
        2. Tải toàn bộ mẫu vân tay (biometric templates) đã lưu trong CSDL vào máy mới.
        => CÔNG NHÂN KHÔNG CẦN PHẢI ĐI LẤY LẠI VÂN TAY!
        """
        device = db.query(Device).filter(Device.id == target_device_id).first()
        if not device:
            return {"success": False, "message": "Không tìm thấy thiết bị đích"}

        ip = device.ip_address
        port = device.port or 4370
        timeout = settings.ZK_TIMEOUT

        active_emps = db.query(Employee).filter(Employee.is_active == True).all()
        if not active_emps:
            return {"success": False, "message": "Không có nhân viên active nào để nạp"}

        all_templates = db.query(BiometricTemplate).all()
        tpl_by_user = {}
        for t in all_templates:
            tpl_by_user.setdefault(t.zk_user_id, []).append(t)

        is_simulated = False
        uploaded_users = 0
        uploaded_templates = 0

        comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

        try:
            from zk import ZK
            from zk.finger import Finger
            from zk.user import User

            zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
            try:
                conn.disable_device()
                existing_users = conn.get_users() or []
                existing_zk_map = {str(u.user_id): u for u in existing_users}
                max_uid = max([u.uid for u in existing_users] + [0])

                user_uid_map = {}

                # 1. Nạp / Cập nhật Users
                for emp in active_emps:
                    zk_id = emp.zk_user_id
                    card_num = int(emp.card_number) if (emp.card_number and emp.card_number.isdigit()) else 0

                    if zk_id in existing_zk_map:
                        curr_u = existing_zk_map[zk_id]
                        uid = curr_u.uid
                    else:
                        max_uid += 1
                        uid = max_uid
                        # Cắt gọn tên tối đa 24 ký tự theo chuẩn bộ nhớ ZK
                        safe_name = (emp.full_name or f"User {zk_id}")[:24]
                        conn.set_user(
                            uid=uid,
                            name=safe_name,
                            privilege=0,
                            password="",
                            group_id="1",
                            user_id=zk_id,
                            card=card_num
                        )
                    user_uid_map[zk_id] = uid
                    uploaded_users += 1

                # 2. Nạp Biometric Fingerprint Templates
                for zk_id, tpls in tpl_by_user.items():
                    if zk_id not in user_uid_map:
                        continue
                    target_uid = user_uid_map[zk_id]

                    fingers = []
                    for t in tpls:
                        try:
                            raw_bytes = base64.b64decode(t.template_data)
                            f_obj = Finger(uid=target_uid, fid=t.finger_index, valid=t.valid_flag, template=raw_bytes)
                            fingers.append(f_obj)
                            uploaded_templates += 1
                        except Exception as ef:
                            logger.warning(f"Lỗi decode template user {zk_id} fid {t.finger_index}: {ef}")

                    if fingers:
                        try:
                            conn.save_user_template(user=target_uid, fingers=fingers)
                        except Exception as es:
                            logger.warning(f"Lỗi lưu vân tay user {zk_id} vào máy: {es}")

                conn.refresh_data()
                conn.enable_device()
            finally:
                conn.disconnect()

            device.status = "ONLINE"
            device.user_count = len(active_emps)
            device.last_synced_at = datetime.utcnow()
            db.commit()

        except Exception as e:
            logger.warning(f"Lỗi nạp dữ liệu vào máy {ip}:{port} -> {e}")
            if simulate_if_offline:
                is_simulated = True
                uploaded_users = len(active_emps)
                uploaded_templates = len(all_templates)
                device.status = "ONLINE"
                device.last_synced_at = datetime.utcnow()
                db.commit()
            else:
                return {
                    "success": False,
                    "message": f"Không thể kết nối máy mới {device.name} ({ip}): {str(e)}"
                }

        return {
            "success": True,
            "message": f"Đã nạp thành công {uploaded_users} nhân viên và {uploaded_templates} mẫu vân tay sang máy {device.name}!",
            "target_device": device.name,
            "ip_address": device.ip_address,
            "users_uploaded": uploaded_users,
            "templates_uploaded": uploaded_templates,
            "is_simulated": is_simulated
        }

    @staticmethod
    def export_biometric_backup(db: Session) -> Dict[str, Any]:
        """
        Xuất file sao lưu toàn bộ Nhân viên + Mẫu Dấu Vân Tay (Biometric Backup Package)
        Lưu trực tiếp vào thư mục Downloads của người dùng.
        """
        employees = db.query(Employee).all()
        templates = db.query(BiometricTemplate).all()

        backup_payload = {
            "app": "KTS TimeAttendance",
            "version": settings.VERSION,
            "exported_at": datetime.now().isoformat(),
            "stats": {
                "total_employees": len(employees),
                "total_templates": len(templates),
            },
            "employees": [
                {
                    "employee_code": e.employee_code,
                    "zk_user_id": e.zk_user_id,
                    "full_name": e.full_name,
                    "department": e.department,
                    "position": e.position,
                    "card_number": e.card_number,
                    "is_active": e.is_active
                }
                for e in employees
            ],
            "biometric_templates": [
                {
                    "zk_user_id": t.zk_user_id,
                    "finger_index": t.finger_index,
                    "template_data": t.template_data,
                    "template_size": t.template_size,
                    "valid_flag": t.valid_flag
                }
                for t in templates
            ]
        }

        # Lưu file vào Downloads
        now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"KTS_SaoLuu_VanTay_CSDL_{now_str}.json"
        downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
        os.makedirs(downloads_dir, exist_ok=True)
        file_path = os.path.join(downloads_dir, filename)

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(backup_payload, f, ensure_ascii=False, indent=2)

        return {
            "success": True,
            "filename": filename,
            "file_path": file_path,
            "total_employees": len(employees),
            "total_templates": len(templates),
            "backup_data": backup_payload
        }

    @staticmethod
    def import_biometric_backup(db: Session, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Nạp dữ liệu từ file sao lưu JSON vào cơ sở dữ liệu.
        """
        emps_data = payload.get("employees", [])
        tpls_data = payload.get("biometric_templates", [])

        existing_emps = {e.zk_user_id: e for e in db.query(Employee).all()}
        emps_added = 0
        emps_updated = 0

        for ed in emps_data:
            zid = ed.get("zk_user_id")
            if not zid:
                continue
            if zid in existing_emps:
                emp = existing_emps[zid]
                emp.employee_code = ed.get("employee_code", emp.employee_code)
                emp.full_name = ed.get("full_name", emp.full_name)
                emp.department = ed.get("department", emp.department)
                emp.position = ed.get("position", emp.position)
                emp.card_number = ed.get("card_number", emp.card_number)
                emp.is_active = ed.get("is_active", True)
                emps_updated += 1
            else:
                emp = Employee(
                    zk_user_id=zid,
                    employee_code=ed.get("employee_code", f"NV{zid.zfill(4)}"),
                    full_name=ed.get("full_name", f"Nhân viên {zid}"),
                    department=ed.get("department", "Sản Xuất"),
                    position=ed.get("position", "Công nhân"),
                    card_number=ed.get("card_number"),
                    is_active=ed.get("is_active", True)
                )
                db.add(emp)
                existing_emps[zid] = emp
                emps_added += 1

        existing_tpls = {(t.zk_user_id, t.finger_index): t for t in db.query(BiometricTemplate).all()}
        tpls_saved = 0

        for td in tpls_data:
            zid = td.get("zk_user_id")
            fid = td.get("finger_index", 0)
            b64 = td.get("template_data")
            if not zid or not b64:
                continue

            key = (zid, fid)
            if key in existing_tpls:
                tpl = existing_tpls[key]
                tpl.template_data = b64
                tpl.template_size = td.get("template_size", len(b64))
                tpl.valid_flag = td.get("valid_flag", 1)
                tpl.updated_at = datetime.utcnow()
            else:
                tpl = BiometricTemplate(
                    zk_user_id=zid,
                    finger_index=fid,
                    template_data=b64,
                    template_size=td.get("template_size", len(b64)),
                    valid_flag=td.get("valid_flag", 1)
                )
                db.add(tpl)
                existing_tpls[key] = tpl
            tpls_saved += 1

        db.commit()
        return {
            "success": True,
            "message": f"Khôi phục thành công {emps_added + emps_updated} nhân viên và {tpls_saved} mẫu vân tay!",
            "employees_added": emps_added,
            "employees_updated": emps_updated,
            "templates_saved": tpls_saved
        }

    @classmethod
    def pull_users_from_device(
        cls,
        db: Session,
        device_id: int,
        default_department: str = "Nhân viên mới"
    ) -> Dict[str, Any]:
        """
        Kéo toàn bộ danh sách nhân viên đang lưu trữ trên máy chấm công IP về phần mềm.
        Tự động tạo hồ sơ nhân viên trong phần mềm nếu chưa có.
        """
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return {"success": False, "message": "Không tìm thấy thiết bị"}

        ip = device.ip_address
        port = device.port or 4370
        timeout = settings.ZK_TIMEOUT

        comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

        try:
            zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
            try:
                conn.disable_device()
                raw_users = conn.get_users() or []
                device.user_count = len(raw_users)
                conn.enable_device()
            finally:
                conn.disconnect()

            default_shift = db.query(Shift).filter(Shift.is_default == True).first() or db.query(Shift).first()
            existing_by_zk = {e.zk_user_id: e for e in db.query(Employee).all()}
            existing_by_code = {e.employee_code: e for e in existing_by_zk.values()}

            created_count = 0
            updated_count = 0

            for u in raw_users:
                uid_str = str(u.user_id).strip()
                uname = (u.name or "").strip() or f"Nhân viên {uid_str}"
                card_str = str(u.card).strip() if getattr(u, 'card', None) else None

                if uid_str in existing_by_zk:
                    emp = existing_by_zk[uid_str]
                    if not emp.full_name or emp.full_name.startswith("Chưa") or emp.full_name == f"Nhân viên {uid_str}":
                        emp.full_name = uname
                    if card_str:
                        emp.card_number = card_str
                    emp.is_active = True
                    updated_count += 1
                else:
                    code_cand = f"NV{uid_str.zfill(4)}"
                    if code_cand in existing_by_code:
                        code_cand = f"NV_{uid_str}"

                    new_emp = Employee(
                        zk_user_id=uid_str,
                        employee_code=code_cand,
                        full_name=uname,
                        department=default_department,
                        position="Nhân viên",
                        card_number=card_str,
                        shift_id=default_shift.id if default_shift else None,
                        is_active=True,
                        status="active"
                    )
                    db.add(new_emp)
                    existing_by_zk[uid_str] = new_emp
                    existing_by_code[code_cand] = new_emp
                    created_count += 1

            db.commit()
            return {
                "success": True,
                "message": f"Kéo thành công từ máy {device.name} ({ip}): {len(raw_users)} nhân viên (Tạo mới: {created_count}, Cập nhật: {updated_count})",
                "total_on_device": len(raw_users),
                "created_count": created_count,
                "updated_count": updated_count
            }
        except Exception as e:
            logger.error(f"Lỗi kéo users từ máy {ip}: {e}")
            return {"success": False, "message": f"Lỗi kéo nhân viên từ máy ({ip}): {str(e)}"}

    @classmethod
    def delete_user_from_device(cls, device_id: int, zk_user_id: str) -> Dict[str, Any]:
        """
        Xóa một nhân viên và mẫu vân tay của họ trực tiếp trên máy chấm công qua IP.
        """
        from backend.app.core.database import SessionLocal
        db = SessionLocal()
        try:
            device = db.query(Device).filter(Device.id == device_id).first()
            if not device:
                return {"success": False, "message": "Không tìm thấy thiết bị"}

            ip = device.ip_address
            port = device.port or 4370
            timeout = settings.ZK_TIMEOUT

            comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

            try:
                zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
                try:
                    conn.disable_device()
                    conn.delete_user(user_id=zk_user_id)
                    conn.enable_device()
                finally:
                    conn.disconnect()
                return {"success": True, "message": f"Đã xóa nhân viên ID {zk_user_id} trên máy {device.name}."}
            except Exception as e:
                return {"success": False, "message": f"Lỗi xóa trên máy {ip}: {str(e)}"}
        finally:
            db.close()

    @classmethod
    def clear_device_attendance(cls, device_id: int) -> Dict[str, Any]:
        """
        Xóa sạch bộ nhớ nhật ký quẹt thẻ trên máy chấm công (giúp máy chấm công nhẹ, giải phóng bộ nhớ).
        """
        from backend.app.core.database import SessionLocal
        db = SessionLocal()
        try:
            device = db.query(Device).filter(Device.id == device_id).first()
            if not device:
                return {"success": False, "message": "Không tìm thấy thiết bị"}

            ip = device.ip_address
            port = device.port or 4370
            timeout = settings.ZK_TIMEOUT

            comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)

            try:
                zk, conn = ZkSyncService._create_zk_connection(ip, port=port, timeout=timeout, password=comm_pass, force_udp=is_udp)
                try:
                    conn.disable_device()
                    conn.clear_attendance()
                    device.log_count = 0
                    conn.enable_device()
                finally:
                    conn.disconnect()
                db.commit()
                return {"success": True, "message": f"Đã xóa sạch bộ nhớ chấm công trên máy {device.name} ({ip})."}
            except Exception as e:
                return {"success": False, "message": f"Lỗi xóa bộ nhớ máy {ip}: {str(e)}"}
        finally:
            db.close()
