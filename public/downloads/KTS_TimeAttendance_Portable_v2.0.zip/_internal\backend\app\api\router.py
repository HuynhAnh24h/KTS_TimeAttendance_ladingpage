from fastapi import APIRouter
from backend.app.api.devices import router as devices_router
from backend.app.api.employees import router as employees_router
from backend.app.api.shifts import router as shifts_router
from backend.app.api.attendance import router as attendance_router
from backend.app.api.dashboard import router as dashboard_router
from backend.app.api.holidays import router as holidays_router
from backend.app.api.leaves import router as leaves_router
from backend.app.api.auth import router as auth_router
from backend.app.api.users import router as users_router
from backend.app.api.payroll import router as payroll_router
from backend.app.api.license import router as license_router
from backend.app.api.updates import router as updates_router
from backend.app.api.settings import router as settings_router
from backend.app.api.system import router as system_router

api_router = APIRouter()

api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(settings_router)
api_router.include_router(system_router)
api_router.include_router(license_router)
api_router.include_router(updates_router)
api_router.include_router(dashboard_router)
api_router.include_router(attendance_router)
api_router.include_router(payroll_router)
api_router.include_router(employees_router)
api_router.include_router(devices_router)
api_router.include_router(shifts_router)
api_router.include_router(holidays_router)
api_router.include_router(leaves_router)
