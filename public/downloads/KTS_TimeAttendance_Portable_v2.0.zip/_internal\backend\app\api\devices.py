from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from backend.app.core.database import get_db
from backend.app.models.device import Device
from backend.app.schemas.device import DeviceCreate, DeviceUpdate, DeviceOut, DeviceTestResult
from backend.app.schemas.attendance import SyncRequest, SyncResponse
from backend.app.services.zk_sync_service import ZkSyncService

router = APIRouter(prefix="/devices", tags=["Devices"])

@router.get("", response_model=List[DeviceOut])
def get_devices(db: Session = Depends(get_db)):
    return db.query(Device).order_by(Device.id.asc()).all()

@router.post("", response_model=DeviceOut, status_code=status.HTTP_201_CREATED)
def create_device(payload: DeviceCreate, db: Session = Depends(get_db)):
    existing = db.query(Device).filter(Device.ip_address == payload.ip_address).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"IP {payload.ip_address} đã được sử dụng bởi máy khác.")
    
    device = Device(**payload.model_dump())
    db.add(device)
    db.commit()
    db.refresh(device)
    return device

@router.put("/{device_id}", response_model=DeviceOut)
def update_device(device_id: int, payload: DeviceUpdate, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Không tìm thấy thiết bị")
    
    data = payload.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(device, k, v)
        
    db.commit()
    db.refresh(device)
    return device

@router.delete("/{device_id}")
def delete_device(device_id: int, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Không tìm thấy thiết bị")
    
    db.delete(device)
    db.commit()
    return {"message": "Đã xóa thiết bị thành công"}

@router.post("/{device_id}/test", response_model=DeviceTestResult)
def test_device_connection(device_id: int, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Không tìm thấy thiết bị")
    
    comm_pass, is_udp = ZkSyncService._get_device_comm_params(device)
    res = ZkSyncService.test_connection(device.ip_address, device.port, password=comm_pass, force_udp=is_udp)
    if res["success"]:
        device.status = "ONLINE"
        device.serial_number = res.get("serial_number")
        device.device_name_hw = res.get("device_name")
        device.firmware_version = res.get("firmware_version")
        device.user_count = res.get("user_count", 0)
    else:
        device.status = "OFFLINE"
    
    db.commit()
    return res

@router.post("/sync", response_model=SyncResponse)
def sync_attendance_devices(payload: SyncRequest, db: Session = Depends(get_db)):
    """
    Đồng bộ dữ liệu quẹt thẻ từ một hoặc toàn bộ máy chấm công IP.
    """
    query = db.query(Device).filter(Device.is_active == True)
    if payload.device_id:
        query = query.filter(Device.id == payload.device_id)
        
    devices = query.all()
    if not devices:
        raise HTTPException(status_code=404, detail="Không có thiết bị hợp lệ để đồng bộ")

    total_synced = 0
    total_saved = 0
    errors = []

    for dev in devices:
        synced, saved, err = ZkSyncService.sync_device_logs(
            db=db,
            device=dev,
            simulate_if_offline=payload.simulate_mode
        )
        total_synced += synced
        total_saved += saved
        if err:
            errors.append(err)

    return SyncResponse(
        success=(len(errors) == 0),
        total_synced_logs=total_synced,
        new_logs_saved=total_saved,
        devices_contacted=len(devices),
        errors=errors
    )

@router.get("/biometrics/stats")
def get_biometrics_stats(db: Session = Depends(get_db)):
    """
    Thống kê tổng số mẫu vân tay sinh trắc học và tỷ lệ nhân sự đã có vân tay.
    """
    return ZkSyncService.get_biometrics_stats(db)

@router.post("/{device_id}/backup-biometrics")
def backup_device_biometrics(
    device_id: int,
    simulate_mode: bool = False,
    db: Session = Depends(get_db)
):
    """
    Tải toàn bộ Dấu Vân Tay và danh sách nhân viên từ máy chấm công về CSDL.
    """
    res = ZkSyncService.backup_device_biometrics(
        db=db,
        device_id=device_id,
        simulate_if_offline=simulate_mode
    )
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi sao lưu vân tay"))
    return res

@router.post("/{device_id}/restore-biometrics")
def restore_device_biometrics(
    device_id: int,
    simulate_mode: bool = False,
    db: Session = Depends(get_db)
):
    """
    Nạp toàn bộ Nhân viên và Dấu Vân Tay từ CSDL sang máy chấm công mới/đích qua IP.
    """
    res = ZkSyncService.restore_device_biometrics(
        db=db,
        target_device_id=device_id,
        simulate_if_offline=simulate_mode
    )
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi nạp vân tay sang máy"))
    return res

@router.post("/biometrics/export-file")
def export_biometrics_backup_file(db: Session = Depends(get_db)):
    """
    Xuất trọn gói file sao lưu CSDL vân tay và hồ sơ nhân sự dạng file .json
    Lưu trực tiếp vào thư mục Downloads của người dùng.
    """
    return ZkSyncService.export_biometric_backup(db)

@router.post("/biometrics/import-file")
def import_biometrics_backup_file(payload: dict, db: Session = Depends(get_db)):
    """
    Khôi phục CSDL nhân sự và mẫu vân tay từ file sao lưu JSON.
    """
    return ZkSyncService.import_biometric_backup(db, payload)

@router.get("/auto-sync/status")
def get_auto_sync_status():
    """
    Lấy thông tin tiến trình tự động đồng bộ ngầm định kỳ.
    """
    from backend.app.services.scheduler_service import AutoSyncScheduler
    return AutoSyncScheduler.get_instance().get_status()

@router.post("/auto-sync/config")
def update_auto_sync_config(payload: dict):
    """
    Cập nhật cài đặt tự động đồng bộ (bật/tắt, thay đổi chu kỳ quét phút).
    """
    from backend.app.services.scheduler_service import AutoSyncScheduler
    enabled = payload.get("enabled")
    interval = payload.get("interval_minutes")
    return AutoSyncScheduler.get_instance().update_config(enabled=enabled, interval_minutes=interval)

@router.post("/{device_id}/pull-users")
def pull_users_from_device(
    device_id: int,
    default_department: str = "Nhân viên mới",
    db: Session = Depends(get_db)
):
    """
    Kéo danh sách nhân sự (User ID, Tên, Mã thẻ) trực tiếp từ máy chấm công IP về phần mềm.
    """
    res = ZkSyncService.pull_users_from_device(
        db=db,
        device_id=device_id,
        default_department=default_department
    )
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi kéo nhân viên từ máy"))
    return res

@router.post("/{device_id}/clear-logs")
def clear_device_logs(device_id: int):
    """
    Xóa sạch bộ nhớ nhật ký quẹt thẻ trên máy chấm công.
    """
    res = ZkSyncService.clear_device_attendance(device_id=device_id)
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi xóa bộ nhớ máy chấm công"))
    return res

@router.delete("/{device_id}/users/{zk_user_id}")
def delete_user_on_device(device_id: int, zk_user_id: str):
    """
    Xóa một nhân viên trực tiếp trên phần cứng máy chấm công.
    """
    res = ZkSyncService.delete_user_from_device(device_id=device_id, zk_user_id=zk_user_id)
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message", "Lỗi xóa nhân viên trên máy"))
    return res

@router.post("/auto-sync/trigger")
async def trigger_auto_sync_now():
    """
    Kích hoạt chạy ngay một lượt đồng bộ tất cả máy chấm công IP.
    """
    from backend.app.services.scheduler_service import AutoSyncScheduler
    return await AutoSyncScheduler.get_instance().trigger_sync_job()

