import os
import sys
import httpx
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional

from backend.app.core.config import settings

router = APIRouter(prefix="/updates", tags=["Updates"])

# Địa chỉ máy chủ kiểm tra cập nhật trực tuyến (Vercel Serverless / Landing Page)
UPDATE_SERVER_URL = os.getenv(
    "UPDATE_SERVER_URL",
    "https://kts-time-attendance-ladingpage.vercel.app/api/updates/check"
)

class UpdateInfoResponse(BaseModel):
    current_version: str
    latest_version: str
    has_update: bool
    release_date: str
    release_title: str
    release_notes: List[str]
    download_url_setup: str
    download_url_portable: str
    is_critical: bool = False

@router.get("/check", response_model=UpdateInfoResponse)
async def check_updates():
    """
    Kiểm tra phiên bản phần mềm mới từ máy chủ trực tuyến.
    Nếu không có mạng, trả về thông tin phiên bản hiện tại.
    """
    current_ver = settings.VERSION

    # Dự phòng thông tin mặc định
    default_response = UpdateInfoResponse(
        current_version=current_ver,
        latest_version=current_ver,
        has_update=False,
        release_date="2026-11-11",
        release_title=f"KTS TimeAttendance v{current_ver} Commercial Edition",
        release_notes=[
            "Tự động quét và nhận diện máy chấm công qua LAN trong 0.7 giây",
            "Bảo mật bản quyền doanh nghiệp độc quyền theo từng Công Ty & Machine ID",
            "Tự động khóa toàn bộ tính năng khi hết hạn và đếm ngược xóa dữ liệu sau 30 ngày",
            "Xuất Excel ma trận 31 ngày chuẩn Luật Lao Động 2026"
        ],
        download_url_setup="https://github.com/HuynhAnh24h/KTS_TimeAttendance_ladingpage/releases/download/v2.0/KTS_TimeAttendance_Commercial_Setup_v2.0.exe",
        download_url_portable="https://github.com/HuynhAnh24h/KTS_TimeAttendance_ladingpage/releases/download/v2.0/KTS_TimeAttendance_Portable_v2.0.zip",
        is_critical=False
    )

    try:
        async with httpx.AsyncClient(timeout=3.5) as client:
            res = await client.get(
                UPDATE_SERVER_URL,
                params={"version": current_ver}
            )
            if res.status_code == 200:
                data = res.json()
                latest_ver = data.get("latest_version", current_ver)
                has_up = data.get("has_update", False)
                # Tự so sánh phiên bản nếu máy chủ trả về
                if latest_ver != current_ver:
                    has_up = True

                return UpdateInfoResponse(
                    current_version=current_ver,
                    latest_version=latest_ver,
                    has_update=has_up,
                    release_date=data.get("release_date", "2026-11-11"),
                    release_title=data.get("release_title", f"Bản Cập Nhật Mới v{latest_ver}"),
                    release_notes=data.get("release_notes", default_response.release_notes),
                    download_url_setup=data.get("download_url_setup", default_response.download_url_setup),
                    download_url_portable=data.get("download_url_portable", default_response.download_url_portable),
                    is_critical=data.get("is_critical", False)
                )
    except Exception as e:
        # Khi offline hoặc không kết nối được máy chủ, trả về thông tin hiện tại
        pass

    return default_response
