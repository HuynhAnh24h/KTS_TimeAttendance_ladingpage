import os
import sys
import uuid
import json
import zlib
import hmac
import base64
import hashlib
import winreg
from datetime import datetime, date, timedelta
from typing import Dict, Any, Optional

MASTER_SECRET = "KTS-ENTERPRISE-FACTORY-SECURE-KEY-2026-HUYNHANH-KORNBEST-AI"
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))
LICENSE_FILE_PATH = os.path.join(DATA_DIR, "license.lic")
TRIAL_FILE_PATH = os.path.join(DATA_DIR, ".trial_info")
PURGED_MARKER_PATH = os.path.join(DATA_DIR, ".purged_marker")

# Giới hạn số ngày ân hạn trước khi dữ liệu bị xóa vĩnh viễn
GRACE_PERIOD_DAYS = 30

class LicenseService:
    """
    Dịch vụ bảo mật bản quyền phần mềm (Hardware-Locked License Key System).
    - Khóa bản quyền theo mã phần cứng máy tính (Machine ID) + Tên Doanh Nghiệp (Mỗi key cho 1 công ty).
    - Khóa toàn bộ tính năng khi hết hạn.
    - Xóa toàn bộ dữ liệu cơ sở dữ liệu nếu quá 30 ngày không gia hạn/kích hoạt key mới.
    """

    @staticmethod
    def get_machine_id() -> str:
        """
        Tạo mã định danh phần cứng máy tính (Machine ID) duy nhất và ổn định trên Windows.
        Kết hợp Windows Cryptography MachineGuid + MAC Address + Computer Name.
        """
        guid = "DEFAULT-WINDOWS-MACHINE-GUID"
        if sys.platform == "win32":
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
                guid = winreg.QueryValueEx(key, "MachineGuid")[0]
                winreg.CloseKey(key)
            except Exception:
                pass

        try:
            mac = hex(uuid.getnode())
        except Exception:
            mac = "0x000000000000"

        comp_name = os.getenv("COMPUTERNAME", "PC")
        raw = f"{guid}:{mac}:{comp_name}"
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
        return f"KTS-{h[:4]}-{h[4:8]}-{h[8:12]}-{h[12:16]}"

    @classmethod
    def generate_license_key(
        cls,
        company_name: str,
        customer_name: Optional[str] = None,
        machine_id: Optional[str] = None,
        expire_date: Optional[str] = "PERPETUAL",
        max_employees: int = 0,
        max_devices: int = 0,
        edition: str = "Enterprise Edition"
    ) -> str:
        """
        Tạo mã bản quyền ràng buộc chặt chẽ với Tên Công Ty và Machine ID.
        """
        comp = (company_name or customer_name or "Doanh Nghiệp KTS").strip()
        cust = (customer_name or company_name or "Khách hàng KTS").strip()
        mach = (machine_id or cls.get_machine_id()).strip().upper()

        payload = {
            "company_name": comp,
            "customer": cust,
            "machine_id": mach,
            "issue_date": date.today().isoformat(),
            "expire_date": expire_date.strip().upper() if expire_date else "PERPETUAL",
            "max_employees": max_employees,
            "max_devices": max_devices,
            "edition": edition,
            "salt": uuid.uuid4().hex[:8]
        }

        # Nén JSON và Base64
        payload_bytes = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        compressed = zlib.compress(payload_bytes, level=9)
        payload_b64 = base64.urlsafe_b64encode(compressed).decode("utf-8").rstrip("=")

        # Ký HMAC-SHA256
        sig = hmac.new(MASTER_SECRET.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()
        
        return f"KTS-LIC.{payload_b64}.{sig[:32]}"

    @classmethod
    def verify_license_string(cls, license_key: str, current_machine_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Xác thực tính hợp lệ của chuỗi License Key.
        """
        if not license_key or not isinstance(license_key, str):
            return {"valid": False, "message": "Mã bản quyền rỗng hoặc không hợp lệ"}

        key_clean = license_key.strip()
        parts = key_clean.split(".")
        if len(parts) != 3 or parts[0] != "KTS-LIC":
            return {"valid": False, "message": "Định dạng mã bản quyền không đúng (phải bắt đầu bằng KTS-LIC)"}

        payload_b64, provided_sig = parts[1], parts[2]

        # Kiểm tra chữ ký HMAC
        expected_sig = hmac.new(MASTER_SECRET.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).hexdigest()[:32]
        if not hmac.compare_digest(provided_sig, expected_sig):
            return {"valid": False, "message": "Chữ ký mã bản quyền không hợp lệ hoặc đã bị chỉnh sửa!"}

        # Giải mã dữ liệu
        try:
            rem = len(payload_b64) % 4
            if rem > 0:
                payload_b64 += "=" * (4 - rem)
            decompressed = zlib.decompress(base64.urlsafe_b64decode(payload_b64.encode("utf-8")))
            payload = json.loads(decompressed.decode("utf-8"))
        except Exception as e:
            return {"valid": False, "message": f"Không thể giải mã dữ liệu bản quyền: {e}"}

        # Trích xuất thông tin công ty
        company_name = payload.get("company_name") or payload.get("customer", "Doanh Nghiệp KTS")
        customer = payload.get("customer") or company_name

        # Kiểm tra Machine ID
        machine_in_key = payload.get("machine_id", "").upper()
        if not current_machine_id:
            current_machine_id = cls.get_machine_id()

        # Cho phép Master Key dành cho nhà phát triển demo
        is_master = (machine_in_key == "DEVELOPER-MASTER-ALL-MACHINES" or machine_in_key == "*")
        if not is_master and machine_in_key != current_machine_id.upper():
            return {
                "valid": False,
                "message": f"Mã bản quyền này cấp cho máy {machine_in_key} thuộc {company_name}, không khớp với máy này ({current_machine_id})!",
                "company_name": company_name,
                "customer": customer,
                "payload": payload
            }

        # Kiểm tra hạn sử dụng
        expire_str = payload.get("expire_date", "PERPETUAL").upper()
        today = date.today()
        is_perpetual = (expire_str in ["PERPETUAL", "VINH_VIEN", "TRON_DOI"])
        days_left = 99999

        if not is_perpetual:
            try:
                exp_date = datetime.strptime(expire_str, "%Y-%m-%d").date()
                days_left = (exp_date - today).days
                if days_left < 0:
                    overdue_days = abs(days_left)
                    days_until_purge = max(0, GRACE_PERIOD_DAYS - overdue_days)
                    
                    # Nếu quá 30 ngày -> Kích hoạt xóa dữ liệu
                    if overdue_days > GRACE_PERIOD_DAYS:
                        cls.purge_database_if_overdue()
                        return {
                            "valid": False,
                            "status": "EXPIRED_PURGED",
                            "message": f"Bản quyền của {company_name} đã hết hạn quá {GRACE_PERIOD_DAYS} ngày! Toàn bộ cơ sở dữ liệu đã bị xóa hoàn toàn khỏi máy tính.",
                            "company_name": company_name,
                            "customer": customer,
                            "machine_id": machine_in_key,
                            "days_remaining": days_left,
                            "days_until_purge": 0,
                            "is_data_purged": True,
                            "payload": payload
                        }
                    else:
                        return {
                            "valid": False,
                            "status": "EXPIRED_LOCKED",
                            "message": f"Bản quyền của {company_name} đã hết hạn vào ngày {exp_date.strftime('%d/%m/%Y')}. Tất cả tính năng đã bị khóa! Bạn còn {days_until_purge} ngày để nhập key mới trước khi toàn bộ dữ liệu bị xóa vĩnh viễn.",
                            "company_name": company_name,
                            "customer": customer,
                            "machine_id": machine_in_key,
                            "days_remaining": days_left,
                            "days_until_purge": days_until_purge,
                            "is_data_purged": False,
                            "payload": payload
                        }
            except Exception:
                return {"valid": False, "message": f"Định dạng ngày hết hạn {expire_str} không hợp lệ"}

        return {
            "valid": True,
            "status": "ACTIVE",
            "message": "Bản quyền hợp lệ",
            "company_name": company_name,
            "customer": customer,
            "machine_id": machine_in_key,
            "edition": payload.get("edition", "Enterprise Edition"),
            "is_perpetual": is_perpetual,
            "expire_date": "Vĩnh viễn" if is_perpetual else expire_str,
            "days_remaining": days_left,
            "days_until_purge": 99999,
            "is_data_purged": False,
            "payload": payload
        }

    @classmethod
    def get_license_status(cls) -> Dict[str, Any]:
        """
        Kiểm tra trạng thái bản quyền hiện tại của hệ thống.
        Ưu tiên: License Key chính thức -> Nếu chưa có: Tính toán Dùng thử 30 ngày (Trial).
        """
        machine_id = cls.get_machine_id()
        is_already_purged = os.path.exists(PURGED_MARKER_PATH)

        # 1. Kiểm tra file license chính thức
        if os.path.exists(LICENSE_FILE_PATH):
            try:
                with open(LICENSE_FILE_PATH, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                res = cls.verify_license_string(content, machine_id)
                if res.get("valid"):
                    return {
                        "is_activated": True,
                        "is_trial": False,
                        "status": "ACTIVE",
                        "status_badge": "BẢN QUYỀN CHÍNH THỨC",
                        "company_name": res.get("company_name", "Doanh Nghiệp KTS"),
                        "customer": res.get("customer"),
                        "machine_id": machine_id,
                        "edition": res.get("edition"),
                        "is_perpetual": res.get("is_perpetual"),
                        "expire_date": res.get("expire_date"),
                        "days_remaining": res.get("days_remaining"),
                        "days_until_purge": 99999,
                        "is_data_purged": False,
                        "message": f"Bản quyền thuộc về: {res.get('company_name')} ({res.get('expire_date')})"
                    }
                else:
                    return {
                        "is_activated": False,
                        "is_trial": False,
                        "status": res.get("status", "EXPIRED_LOCKED"),
                        "status_badge": "BẢN QUYỀN HẾT HẠN - ĐÃ KHÓA TÍNH NĂNG",
                        "company_name": res.get("company_name", "Chưa kích hoạt"),
                        "customer": res.get("customer", "Chưa kích hoạt"),
                        "machine_id": machine_id,
                        "days_remaining": res.get("days_remaining", 0),
                        "days_until_purge": res.get("days_until_purge", 0),
                        "is_data_purged": res.get("is_data_purged", is_already_purged),
                        "message": res.get("message")
                    }
            except Exception:
                pass

        # 2. Quản lý dùng thử (30 ngày Trial ban đầu)
        os.makedirs(DATA_DIR, exist_ok=True)
        trial_start = None
        if os.path.exists(TRIAL_FILE_PATH):
            try:
                with open(TRIAL_FILE_PATH, "r", encoding="utf-8") as f:
                    trial_start = datetime.strptime(f.read().strip(), "%Y-%m-%d").date()
            except Exception:
                pass

        if not trial_start:
            trial_start = date.today()
            try:
                with open(TRIAL_FILE_PATH, "w", encoding="utf-8") as f:
                    f.write(trial_start.isoformat())
            except Exception:
                pass

        TRIAL_DAYS = 30
        trial_end = trial_start + timedelta(days=TRIAL_DAYS)
        days_left = (trial_end - date.today()).days

        if days_left >= 0:
            return {
                "is_activated": False,
                "is_trial": True,
                "status": "TRIAL",
                "status_badge": f"DÙNG THỬ (CÒN {days_left} NGÀY)",
                "company_name": "Bản Dùng Thử Trải Nghiệm",
                "customer": "Khách hàng dùng thử",
                "machine_id": machine_id,
                "edition": "Enterprise Trial",
                "is_perpetual": False,
                "expire_date": trial_end.strftime("%d/%m/%Y"),
                "days_remaining": days_left,
                "days_until_purge": 99999,
                "is_data_purged": False,
                "message": f"Hệ thống đang chạy bản dùng thử thương mại. Còn lại {days_left} ngày trải nghiệm."
            }
        else:
            # Hết hạn 30 ngày dùng thử
            overdue_days = abs(days_left)
            days_until_purge = max(0, GRACE_PERIOD_DAYS - overdue_days)

            if overdue_days > GRACE_PERIOD_DAYS:
                cls.purge_database_if_overdue()
                return {
                    "is_activated": False,
                    "is_trial": True,
                    "status": "EXPIRED_PURGED",
                    "status_badge": "DỮ LIỆU ĐÃ BỊ XÓA DO QUÁ HẠN 30 NGÀY",
                    "company_name": "Hết hạn dùng thử",
                    "customer": "Hết hạn dùng thử",
                    "machine_id": machine_id,
                    "edition": "Enterprise Trial",
                    "is_perpetual": False,
                    "expire_date": trial_end.strftime("%d/%m/%Y"),
                    "days_remaining": days_left,
                    "days_until_purge": 0,
                    "is_data_purged": True,
                    "message": "Thời hạn 30 ngày dùng thử đã kết thúc và quá 30 ngày ân hạn. Toàn bộ cơ sở dữ liệu đã bị xóa hoàn toàn khỏi máy tính."
                }
            else:
                return {
                    "is_activated": False,
                    "is_trial": True,
                    "status": "EXPIRED_LOCKED",
                    "status_badge": "HẾT HẠN DÙNG THỬ - ĐÃ KHÓA TÍNH NĂNG",
                    "company_name": "Hết hạn dùng thử",
                    "customer": "Hết hạn dùng thử",
                    "machine_id": machine_id,
                    "edition": "Enterprise Trial",
                    "is_perpetual": False,
                    "expire_date": trial_end.strftime("%d/%m/%Y"),
                    "days_remaining": days_left,
                    "days_until_purge": days_until_purge,
                    "is_data_purged": is_already_purged,
                    "message": f"Thời hạn 30 ngày dùng thử đã kết thúc! Tất cả tính năng đã bị khóa. Quý khách còn {days_until_purge} ngày để kích hoạt bản quyền trước khi toàn bộ dữ liệu bị xóa hoàn toàn."
                }

    @classmethod
    def purge_database_if_overdue(cls) -> bool:
        """
        Tự động xóa hoàn toàn dữ liệu trong các bảng chấm công, nhân sự, máy, vân tay
        khi quá hạn 30 ngày không gia hạn/nhập key mới.
        """
        try:
            from backend.app.core.database import SessionLocal
            from backend.app.models.attendance_log import AttendanceLog
            from backend.app.models.daily_attendance import DailyAttendance
            from backend.app.models.employee import Employee
            from backend.app.models.biometric_template import BiometricTemplate
            from backend.app.models.device import Device
            from backend.app.models.payroll import Payroll
            from backend.app.models.leave_request import LeaveRequest
            from backend.app.models.shift import Shift, ShiftAssignment
            from backend.app.models.holiday import Holiday
            
            db = SessionLocal()
            try:
                db.query(DailyAttendance).delete()
                db.query(AttendanceLog).delete()
                db.query(BiometricTemplate).delete()
                db.query(LeaveRequest).delete()
                db.query(Payroll).delete()
                db.query(ShiftAssignment).delete()
                db.query(Employee).delete()
                db.query(Device).delete()
                db.query(Shift).delete()
                db.query(Holiday).delete()
                db.commit()
                print("[SECURITY ALERT] Toàn bộ dữ liệu cơ sở dữ liệu đã bị xóa do quá hạn bản quyền 30 ngày.")
            except Exception as e:
                db.rollback()
                print(f"[SECURITY ERROR] Lỗi khi xóa bảng dữ liệu: {e}")
            finally:
                db.close()

            # Ghi nhận file marker để lưu trạng thái
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(PURGED_MARKER_PATH, "w", encoding="utf-8") as f:
                f.write(f"PURGED_AT={datetime.now().isoformat()}\nREASON=OVERDUE_30_DAYS_WITHOUT_LICENSE\n")

            return True
        except Exception as e:
            print(f"[SECURITY EXCEPTION] Lỗi purge database: {e}")
            return False

    @classmethod
    def activate_key(cls, license_key: str) -> Dict[str, Any]:
        """
        Kích hoạt mã bản quyền và lưu vào file license.lic.
        Nếu kích hoạt thành công, xóa marker đã bị purge (nếu có).
        """
        machine_id = cls.get_machine_id()
        res = cls.verify_license_string(license_key, machine_id)
        if not res.get("valid"):
            return {
                "success": False,
                "message": res.get("message", "Mã kích hoạt không hợp lệ")
            }

        os.makedirs(DATA_DIR, exist_ok=True)
        with open(LICENSE_FILE_PATH, "w", encoding="utf-8") as f:
            f.write(license_key.strip())

        # Xóa marker purge nếu kích hoạt key mới thành công
        if os.path.exists(PURGED_MARKER_PATH):
            try:
                os.remove(PURGED_MARKER_PATH)
            except Exception:
                pass

        company_name = res.get("company_name", res.get("customer", "Doanh Nghiệp KTS"))
        return {
            "success": True,
            "message": f"Kích hoạt thành công bản quyền cho: {company_name}!",
            "details": res
        }
